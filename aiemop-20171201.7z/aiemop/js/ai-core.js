var ai = {};
ai.appLocalVersion='1.5.3';//APP本地版本号,使得支持IOS开发模式的版本验证
ai.appPathObject = {download:'http://218.205.252.12:10029/emop.apk',//最新安装包地址
					emop:'http://218.205.252.12:10029/aiemop/',//政企营销项目地址
					emopPro:'http://218.205.252.12:10029/aiemopPro/',//政企营销PC项目地址
					work:'http://218.205.252.12:10029/aiwork/'};//挂牌攻坚项目地址 
//ai.appPathObject = {download:'http://10.108.226.121:8080/emop.apk',//最新安装包地址
//					emop:'http://10.108.226.121:8080/aiemop/',//政企营销项目地址
//					emopPro:'http://10.108.226.121:8080/aiemopPro/',//政企营销PC项目地址
//					work:'http://10.108.226.121:8080/aiwork/'};//挂牌攻坚项目地址 

/**
 * 传统Ajax数据请求
 */
ai.ajax = function(url, param, onSuccess, onError, onComplete){
	_ai_hejg_ajax_common(url, param, onSuccess, onError, onComplete,"application/x-www-form-urlencoded");
};
/**
 * JsonAjax数据请求
 */
ai.json = function(url, param, onSuccess, onError, onComplete){
	_ai_hejg_ajax_common(url, param, onSuccess, onError, onComplete,"application/json");
};

/**
 * 打开窗口的公用方法
 * @param {Object} param 参数与mui.openWindow一致
 * 此处封装便于对打开窗口事件进行项目整体的优化处理
 */
ai.openWindow = function(param){
	param.show={duration:200};
//	param.styles={scrollIndicator:'none'};
	mui.openWindow(param);
}

/**
 * 数字格式化公共方法
 * @param {Object} s 数值
 * @param {Object} n 保留的精度
 */
ai.numberFormat = function(s,n){//s:数值,n:精度
	n = ai.defaultValue(n,2);
	if(typeof(s) != "undefined"){
		if(parseInt(s)==s){
			return ai.decimalFormat(s,0);
		}else{
			return ai.decimalFormat(s,n);
		}
	}else{
		return '-';
   	}
}

/**
 * 简化处理默认值的方法
 * @param {Object} v
 * @param {Object} d
 */
ai.defaultValue = function(v, d){
	return v ? v : d;
}

/**
 * 简化大数值的显示(通常用于Echarts值维度)
 * @param {Object} s
 */
ai.echartsAxisFormat = function(s){
	if(typeof(s) != "undefined"){
		var base = 10000;
		var dw = "";
		if(s >= (base * 10000)){
			s = s/(base*10000);
			dw = '亿';
		}else if(s >= base * 1000){
			s = s/(base*1000);
			dw = '千万';
		}else if(s >= base * 100){
			s = s/(base*100);
			dw = '00万';
		}else if(s >= base * 10){//10万
			s = s/(base*10);
			dw = '0万';
		}else if(s > base){//万
			s = s/base;
			dw = '万';
		}
//	    return parseInt(s)+dw;
	    return s+dw;
   	}else{
		return '-';
   	}
}

ai.decimalFormat = function(s, n){//s:数值,n:精度
	if(typeof(s) != "undefined"){
		var bw = false;
		if(s > 1000000){//百万
			s = s/10000;
			bw = true;
		}
		n = n >= 0 && n <= 20 ? n : 2;
		s = parseFloat((s + "").replace(/[^\d\.-]/g, "")).toFixed(n) + "";//四舍五入
	    var l = s.split(".")[0].split("").reverse(), r = s.split(".")[1];
	    t = "";
	    for (i = 0; i < l.length; i++) {
	        t += l[i] + ((i + 1) % 3 == 0 && (i + 1) != l.length ? "," : "");
	    }
	    return t.split("").reverse().join("") + (n > 0 ?("." + r):"")+(bw ? '万':'');
   	}else{
		return '-';
   	}
}

/**
 * 初始化ai.user对象方便页面调用
 */
mui.plusReady(function(){
	if(plus.storage.getItem("USER-BASE-INFO")){
		ai.user = JSON.parse(Base64.decode(plus.storage.getItem("USER-BASE-INFO")));
	}
});

/**
 * 通用Ajax方法,请勿直接调用,推荐使用ai.ajax或ai.json简化使用
 */
function _ai_hejg_ajax_common(url, param, onSuccess, onError, onComplete, contentType){
	var onSuccess = arguments[2]?arguments[2]:function(){};//成功时
	var onError = arguments[3]?arguments[3]:function(){};//异常时
	var onComplete = arguments[4]?arguments[4]:function(){};//完成时
	var contentType = arguments[5]?arguments[5]:"application/x-www-form-urlencoded";//请求数据类型
	
	if(url.indexOf("http") < 0){//存在包含http地址时直接使用,保证开发者可自行提供完整url
		url = ai.appPathObject.emop + url;//默认未包含http的请求均使用政企营销项目地址
	}
	var workToken = ai.user ? ai.user.lastLoginToken:'';
	mui.ajax(url, {
        data:param,
        dataType:'json',
        type:'post',
        timeout:10000,//超时时间设置为5秒
        contentType: contentType,
        headers:{'AI-Requested-Way':'APP','AI-Login-Token':workToken},//plus.storage.getItem('USER-LOGIN-TOKEN')
        success:function(data,textStatus,xhr){
            if(!data.state && data.code == "JAVA_EXCEPTION"){
            	mui.toast('服务端请求处理发生问题,请联系系统管理员.');
            	onError();
			}else if(!data.state && data.code == "SHOW_MSG"){
				mui.alert(data.info);
				onError();
			}else if(!data.state && data.code == "CHARACTER_WRONGFUL"){
				mui.toast('您提交的数据中含有非法字符,请调整后继续.');
				onError();
			}else if(!data.state && data.code == "NOT_LOGINED"){
				mui.toast('您尚未登陆或账号在其他终端上登陆导致本设备踢出.');
//				plus.nativeUI.closeWaiting();
				plus.runtime.restart();
			}else{
				onSuccess(data);
			}
        },
        error:function(xhr,type,errorThrown){
            var msg = type;
            switch (type){
            	case "timeout":
            		msg = "请求过程超时,请确认当前网络环境是否良好.";
            		break;
            	case "abort":
            		msg = "请检查网络状态.";
            		break;
            	case "error":
            		msg = "服务端请求处理发生问题,请联系系统管理员.";
            		break;
            	case "parsererror":
            		msg = "服务器回传的数据类型异常.";
            		break;
            	case "null":
            		msg = "发生未知问题,请联系系统管理员.";
            		break;
            	default:
            		break;
            }
            mui.toast(msg);
            onError();
        },
        complete:function(xhr, status){
        	onComplete();
        }
    });
}

//Base64加解密函数
(function(global){"use strict";var _Base64=global.Base64;var version="2.1.9";var buffer;if(typeof module!=="undefined"&&module.exports){try{buffer=require("buffer").Buffer}catch(err){}}var b64chars="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";var b64tab=function(bin){var t={};for(var i=0,l=bin.length;i<l;i++)t[bin.charAt(i)]=i;return t}(b64chars);var fromCharCode=String.fromCharCode;var cb_utob=function(c){if(c.length<2){var cc=c.charCodeAt(0);return cc<128?c:cc<2048?fromCharCode(192|cc>>>6)+fromCharCode(128|cc&63):fromCharCode(224|cc>>>12&15)+fromCharCode(128|cc>>>6&63)+fromCharCode(128|cc&63)}else{var cc=65536+(c.charCodeAt(0)-55296)*1024+(c.charCodeAt(1)-56320);return fromCharCode(240|cc>>>18&7)+fromCharCode(128|cc>>>12&63)+fromCharCode(128|cc>>>6&63)+fromCharCode(128|cc&63)}};var re_utob=/[\uD800-\uDBFF][\uDC00-\uDFFFF]|[^\x00-\x7F]/g;var utob=function(u){return u.replace(re_utob,cb_utob)};var cb_encode=function(ccc){var padlen=[0,2,1][ccc.length%3],ord=ccc.charCodeAt(0)<<16|(ccc.length>1?ccc.charCodeAt(1):0)<<8|(ccc.length>2?ccc.charCodeAt(2):0),chars=[b64chars.charAt(ord>>>18),b64chars.charAt(ord>>>12&63),padlen>=2?"=":b64chars.charAt(ord>>>6&63),padlen>=1?"=":b64chars.charAt(ord&63)];return chars.join("")};var btoa=global.btoa?function(b){return global.btoa(b)}:function(b){return b.replace(/[\s\S]{1,3}/g,cb_encode)};var _encode=buffer?function(u){return(u.constructor===buffer.constructor?u:new buffer(u)).toString("base64")}:function(u){return btoa(utob(u))};var encode=function(u,urisafe){return!urisafe?_encode(String(u)):_encode(String(u)).replace(/[+\/]/g,function(m0){return m0=="+"?"-":"_"}).replace(/=/g,"")};var encodeURI=function(u){return encode(u,true)};var re_btou=new RegExp(["[À-ß][-¿]","[à-ï][-¿]{2}","[ð-÷][-¿]{3}"].join("|"),"g");var cb_btou=function(cccc){switch(cccc.length){case 4:var cp=(7&cccc.charCodeAt(0))<<18|(63&cccc.charCodeAt(1))<<12|(63&cccc.charCodeAt(2))<<6|63&cccc.charCodeAt(3),offset=cp-65536;return fromCharCode((offset>>>10)+55296)+fromCharCode((offset&1023)+56320);case 3:return fromCharCode((15&cccc.charCodeAt(0))<<12|(63&cccc.charCodeAt(1))<<6|63&cccc.charCodeAt(2));default:return fromCharCode((31&cccc.charCodeAt(0))<<6|63&cccc.charCodeAt(1))}};var btou=function(b){return b.replace(re_btou,cb_btou)};var cb_decode=function(cccc){var len=cccc.length,padlen=len%4,n=(len>0?b64tab[cccc.charAt(0)]<<18:0)|(len>1?b64tab[cccc.charAt(1)]<<12:0)|(len>2?b64tab[cccc.charAt(2)]<<6:0)|(len>3?b64tab[cccc.charAt(3)]:0),chars=[fromCharCode(n>>>16),fromCharCode(n>>>8&255),fromCharCode(n&255)];chars.length-=[0,0,2,1][padlen];return chars.join("")};var atob=global.atob?function(a){return global.atob(a)}:function(a){return a.replace(/[\s\S]{1,4}/g,cb_decode)};var _decode=buffer?function(a){return(a.constructor===buffer.constructor?a:new buffer(a,"base64")).toString()}:function(a){return btou(atob(a))};var decode=function(a){return _decode(String(a).replace(/[-_]/g,function(m0){return m0=="-"?"+":"/"}).replace(/[^A-Za-z0-9\+\/]/g,""))};var noConflict=function(){var Base64=global.Base64;global.Base64=_Base64;return Base64};global.Base64={VERSION:version,atob:atob,btoa:btoa,fromBase64:decode,toBase64:encode,utob:utob,encode:encode,encodeURI:encodeURI,btou:btou,decode:decode,noConflict:noConflict};if(typeof Object.defineProperty==="function"){var noEnum=function(v){return{value:v,enumerable:false,writable:true,configurable:true}};global.Base64.extendString=function(){Object.defineProperty(String.prototype,"fromBase64",noEnum(function(){return decode(this)}));Object.defineProperty(String.prototype,"toBase64",noEnum(function(urisafe){return encode(this,urisafe)}));Object.defineProperty(String.prototype,"toBase64URI",noEnum(function(){return encode(this,true)}))}}if(global["Meteor"]){Base64=global.Base64}})(this);