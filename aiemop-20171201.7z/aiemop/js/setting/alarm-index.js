mui.init({
	beforeback: function() {
		//更新数据预警阈值
		var param = "";
		var inputDoms = document.body.querySelectorAll("table input[type='number']");
		for (var i = 0; i < inputDoms.length; i++) {
			if (inputDoms[i].value) {
				param += "&indexId=" + inputDoms[i].dataset.indexId + "&thresholdValue=" + inputDoms[i].value;
			}
		}
		if (param) {
			ai.ajax("setting/alarm/mergeAlarmIndex", param.substring(1), function(data) {
				if (data.state) {					
				}
			},function(){
				
			},function(){
				
			});
			mui.toast("设置完成！");
		}
		return true;
	}
});

mui.plusReady(function() {
	//传值给详情页面，通知加载新数据
	ai.ajax("setting/alarm/getAlarmIndex", {}, function(data) {
		//mui.toast(JSON.stringify(data));
		if (data.state) {
			var table = document.body.querySelector('.mui-content>table');
			table.innerHTML = '';
			mui.each(data.info, function(index, item) {
				var curr_value=item.THRESHOLD_VALUE ;
				if(!curr_value){
					curr_value=0;
				}
				var tr = document.createElement('tr');
				tr.innerHTML = '<td>' + item.SETTING_NAME + '</td><td>' + item.INDEX_RULE + '<input type="number" value="' + curr_value + '" data-index-id="' + item.INDEX_ID + '" id="range-' + item.INDEX_ID + '-value"/></td>' +
					'<td><div class="mui-input-range"><input type="range" id="range-' + item.INDEX_ID + '" value="' + curr_value + '" style="background-color:#01C3E0;height:3px;"></div></td>';
				table.appendChild(tr);
			});
			//监听input事件，获取range的value值，也可以直接element.value获取该range的值
			var rangeList = document.querySelectorAll('input[type="range"]');
			for (var i = 0, len = rangeList.length; i < len; i++) {
				rangeList[i].addEventListener('input', function() {
					document.getElementById(this.id + '-value').value = Math.abs(this.value);
				});
			}
		}
	});
});