mui.init({
	swipeBack: false,
	beforeback: function() {
			var param = "";
			var h6list = document.querySelectorAll("#change h6");
			//mui.toast(h6list.length);
			if(h6list.length > 0) {
				mui.each(h6list, function(index, item) {
					param += "&grpIndex=" + item.getAttribute('grpIndex');
				});
				ai.ajax("setting/grpIndex/modify", param.substring(1), function(data) {
					if(data.state) {
						mui.toast('指标关注成功！');
						return true;
					} else {
						mui.toast('操作失败！');
						return false;
					}
				}, function() {
					return false;
				},function(){
					return true;
				});
			} else {
				mui.toast("操作失败！请至少定制一个指标");
				return true;
			}
		}
		//,statusBarBackground: '#3BAEE7'
});

mui.plusReady(function() {
	//计算高度
	var item_height = (plus.display.resolutionHeight - 44)-150;
	var checked = document.getElementById('change');
	var unchecked = document.getElementById('Uchange');
	checked.style.height = item_height + "px";
	unchecked.style.height = item_height + "px";
	
	//加载分类
	ai.ajax("setting/grpIndex/getGrpIndexD", {}, function(data) {
		//mui.toast("aaa00="+data.state);
		if(data.state) {
			//类别筛选区域
			var tcb = document.getElementById('type_count_box');
			var tcb_html = '';
			var INDEX_NUM = 0;
			mui.each(data.info.TypeCount, function(index, item) {
				tcb_html += '<div class="mui-col-xs-6"><h4><a icType="' + item.INDEX_CATEGORY + '">' + item.INDEX_CATEGORY_NAME + '： <label>' + item.INDEX_NUM + '</label></a></h4></div>';
				INDEX_NUM += item.INDEX_NUM
			});
			tcb.innerHTML = tcb_html;
			document.getElementById('all_count_box').innerText = INDEX_NUM;
			//已选区
			var tchb = document.getElementById('change');
			var tchb_html = '';
			mui.each(data.info.DoneIndex, function(index, item) {
				tchb_html += '<div style="width:80%;margin:0 auto;"><h6 grpIndex="' + item.INDEX_ID + '" class="mui-text-center">' + item.INDEX_NAME + '</h6></div>';
			});
			tchb.innerHTML = tchb_html;
			//待选区
			undoit(data.info.UnDoneIndex);
		}
	}, function() {

	}, function() {

	});

	//产品分类
	/*mui('#all_label').on('tap', 'a', function(e) {
		ai.ajax("setting/grpIndex/getGrpIndexD", {}, function(data) {
			if (data.state) {
				//待选区
				undoit(data.info.UnDoneIndex);
			}
		});
	});*/
	//保存按钮点击事件
	mui('#save_button')[0].addEventListener('tap', function() {
		var param = "";
		var h6list = document.querySelectorAll("#change h6");
		//mui.toast(h6list.length);
		if(h6list.length > 0) {
			mui.each(h6list, function(index, item) {
				param += "&grpIndex=" + item.getAttribute('grpIndex');
			});
			ai.ajax("setting/grpIndex/modify", param.substring(1), function(data) {
				if(data.state) {
					mui.toast('指标关注成功！');
					return true;
				} else {
					mui.toast('操作失败！');
					return false;
				}
			}, function() {
				return false;
			}, function() {
				mui.back();
			});
		} else {
			mui.toast("操作失败！请至少定制一个指标");
		}
	});

	//分类按钮点击事件
	mui('#type_list').on('tap', 'a', function(e) {
		ai.ajax("setting/grpIndex/typeselect", {
			"indexCategory": this.getAttribute('icType')
		}, function(data) {
			if(data.state) {
				//待选区
				undoit(data.info);
			}
		}, function() {}, function() {});
	});

	var change = document.getElementById("change");
	new Sortable(change, {
		group: "omega"
	});

	var Uchange = document.getElementById("Uchange");
	new Sortable(Uchange, {
		group: "omega"
	});
});

function undoit(indexList) {
	var tuchb = document.getElementById('Uchange');
	var tuchb_html = '';
	//获取已选择列表
	var choose_groupindex = "";
	var h6list = document.querySelectorAll("#change h6");
	if(h6list.length > 0) {
		mui.each(h6list, function(index, item) {
			choose_groupindex += item.getAttribute('grpIndex') + ",";
		});
	}
	mui.each(indexList, function(index, item) {
		if(choose_groupindex.indexOf(item.INDEX_ID) < 0) {
			tuchb_html += '<div style="width:80%;margin:0 auto;"><h6 grpIndex="' + item.INDEX_ID + '" class="mui-text-center">' + item.INDEX_NAME + '</h6></div>';
		}
	});
	tuchb.innerHTML = tuchb_html;
}