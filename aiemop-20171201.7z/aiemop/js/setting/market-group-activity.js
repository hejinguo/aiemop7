mui.init({
	subpages: [{
		url: 'market-group-activity-pull.html',
		id: 'page-market-group-activity-pull',
		styles: {
			top: '45px',
			bottom: '0px',
		}
	}]
});

var app = null;

mui.plusReady(function() {
	var self = plus.webview.currentWebview();
	app = new Vue({
		el: '#page-body-vid',
		data: {
			title : self.groupName,
			handle : {type:'normal',title:'编辑'}
		},
		mounted: function(){//el 被新创建的 vm.$el 替换，并挂载到实例上去之后调用该钩子。
			setTimeout(function(){
				mui.fire(plus.webview.getWebviewById('page-market-group-activity-pull'),'initPageParamId',{groupId:self.groupId});
			},500);
		},
		methods: {
			switchHandle: function(){
				var _this = this;
				switch (_this.handle.type){
					case "normal"://点击进行入编辑过程
						_this.handle = {type:"editing",title:"保存"};
						mui.fire(plus.webview.getWebviewById('page-market-group-activity-pull'),'changeSwitchHandle',_this.handle);
						break;
					case "editing"://点击进入保存过程
						_this.handle = {type:"normal",title:"编辑"};
						mui.fire(plus.webview.getWebviewById('page-market-group-activity-pull'),'changeSwitchHandle',_this.handle);
						break;
					default:
						break;
				}
			}
		}
	});
});