mui.init({
	pullRefresh: {
		container: '#pullrefresh',
		up: {
			callback: pullupRefresh
		}
	},
	gestureConfig: {
		tap: true, //默认为true
		longtap: true//默认为false
	}
});
var groupId = -1;
var groupName='';
var mktArray = new Array();
var para = {
		'pageNo': 1,
		'pageSize': 12
	}
	//获取营销活动名称
mui.plusReady(function() {
	//接收父页传过来的参数
	window.addEventListener('initGroupId', function(event) {
		para.groupId = event.detail.groupId;
		groupId=event.detail.groupId;
		groupName=event.detail.groupName;
	});
	//加载该组的活动
	initDiyAct();
	//搜索事件
	searchDiyAct() ;
	
	mui('#act_list').on('longtap', '.mui-table-view-cell', function(e) {
		var mktId = this.dataset.mktId;
		if(groupName!='默认组'){
			if(mktArray.toString().indexOf(mktId)<0){
			mktArray.unshift(mktId);
			document.getElementById("act_li_"+mktId).style.backgroundColor="#8Fc31f";
			mui.toast('已选择为预取消！');
			}else{
				mktArray.shift(mktId);
				document.getElementById("act_li_"+mktId).style.backgroundColor="#FFFFFF";
				mui.toast('已取消选择！');
			}
		}

	});
});

function searchDiyAct() {
	document.querySelector('form').addEventListener('submit', function(e) {
		e.preventDefault(); // 阻止默认事件
		var searchInputBox = mui('.mui-input-clear')[0];
		searchInputBox.blur();
		para.marketName = searchInputBox.value;
		mui('#pullrefresh').pullRefresh().refresh(true); //重置上拉加载
		initDiyAct();
	});
}

function initDiyAct() {
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	//mui('#act_list')[0].innerHTML = "";
	para.pageNo = 1;
	pullupRefresh();
}

function pullupRefresh() {
	setTimeout(function() {
		if (para.groupId) {
			ai.ajax("setting/diymkt/getGroupActivity", para, function(data) {
				if (data.state) {
					var table = mui('#act_list')[0];
					mui.each(data.info.rows, function(index, item) {
						var li = document.createElement('li');
						li.id="act_li_"+item.MKT_ID;
						li.dataset.mktId = item.MKT_ID;
						li.className = 'mui-table-view-cell';
						li.innerHTML = '<h4 class="mui-ellipsis">' + item.MKT_NAME + '</h4>'
						table.appendChild(li);
					});
					mui.toast('共' + data.info.total + '条记录,已加载' + (para.pageNo * para.pageSize > data.info.total ? '完毕' : para.pageNo * para.pageSize + '条'));
					if (++para.pageNo > Math.ceil(data.info.total / para.pageSize)) {
						mui('#pullrefresh').pullRefresh().endPullupToRefresh(true); //加载完毕
					} else {
						mui('#pullrefresh').pullRefresh().endPullupToRefresh(false); //还有更多数据
					}
				}

			}, function() {

			}, function() {
				plus.nativeUI.closeWaiting();
			});
		}else{
			plus.nativeUI.closeWaiting();
			mui.toast("请重新打开页面");
		}

	}, 1500);
}

/**
 * 保存更改
 */
function saveChange(){
	if(mktArray.length>0){
		//var para_del={'groupId':groupId,'mktId':mktArray};
		var para_del = "groupId="+groupId;
		//plus.nativeUI.showWaiting("正在为您保存设置,请稍等.");
		mui.each(mktArray,function(index,item){
			para_del += "&mktId="+item;
		});
		ai.ajax("setting/diymkt/diyMktDelete", para_del, function(data) {
			mui.toast("配置成功！");
		},function(){
			
		},function(){
			
		});	
	}
	
}
