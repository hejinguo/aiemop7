mui.init({
	
});

mui.plusReady(function(){
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
//	加载产品自定义分组列表
	loadProductGroupItem();
//	加载产品自定义分类列表
	loadProductClassifyItem();
	
	initAddProductGroupEvent();
	initAddProductClassifyEvent();
	initRemoveProductGroupEvent();
	initRemoveProductClassifyEvent();
	initUpdateProductGroupEvent();
	initUpdateProductClassifyEvent();
	
	window.addEventListener('reloadProductGCItem',function(event){
		plus.nativeUI.showWaiting("正在加载数据,请稍等.");
		if(event.detail.updateType == 'GROUP'){
			loadProductGroupItem();
		}else{
			loadProductClassifyItem();
		}
	});
});

//加载产品自定义分组列表
function loadProductGroupItem(){
	ai.ajax('setting/coreIndex/getProductGroupByUser',{},function(data){
		if(data.state){
			var tableGroup = document.body.querySelector('#product-group-box');
			tableGroup.innerHTML='';
			mui.each(data.info,function(index,item){
			  	var li = document.createElement('li');
				li.className = 'mui-table-view-cell';
				li.dataset.groupId=item.GROUP_ID;
				li.dataset.groupName=item.GROUP_NAME;
				li.innerHTML = '<div class="mui-row"><div class="mui-col-xs-8 mui-ellipsis">'+item.GROUP_NAME+'</div>'+
				'<div class="mui-col-xs-4 mui-text-right"><button type="button" class="mui-btn mui-btn-success" data-group-name="'+item.GROUP_NAME+'" data-group-id="'+item.GROUP_ID+'">管理</button><button type="button" class="mui-btn mui-btn-danger" data-group-id="'+item.GROUP_ID+'">删除</button></div></div>';
				tableGroup.appendChild(li);
			});
		}
	},function(){
		
	},function(){
		plus.nativeUI.closeWaiting();
	});
}

//加载产品自定义分类列表
function loadProductClassifyItem(){
	ai.ajax('setting/coreIndex/getProductClassifyByUser',{},function(data){
		if(data.state){
			var tableClassify = document.body.querySelector('#product-classify-box');
			tableClassify.innerHTML='';
			mui.each(data.info,function(index,item){
			  	var li = document.createElement('li');
				li.className = 'mui-table-view-cell';
				li.dataset.classifyId=item.CLASSIFY_ID;
				li.dataset.classifyName=item.CLASSIFY_NAME;
				li.innerHTML = '<div class="mui-row"><div class="mui-col-xs-8 mui-ellipsis">'+item.CLASSIFY_NAME+'</div>'+
				'<div class="mui-col-xs-4 mui-text-right"><button type="button" class="mui-btn mui-btn-success" data-classify-name="'+item.CLASSIFY_NAME+'" data-classify-id="'+item.CLASSIFY_ID+'">管理</button><button type="button" class="mui-btn mui-btn-danger" data-classify-id="'+item.CLASSIFY_ID+'">删除</button></div></div>';
				tableClassify.appendChild(li);
			});
		}
	},function(){
		
	},function(){
		plus.nativeUI.closeWaiting();
	});
}

//初始化删除产品分组事件
function initRemoveProductGroupEvent(){
	mui('#product-group-box').on('tap','.mui-btn-danger',function(e){
		removeProductGroupOrClassify({content:'产品分组',removeId:this.dataset.groupId,removeType:'GROUP'});
	});
}

//初始化删除产品分类事件
function initRemoveProductClassifyEvent(){
	mui('#product-classify-box').on('tap','.mui-btn-danger',function(e){
		removeProductGroupOrClassify({content:'产品分类',removeId:this.dataset.classifyId,removeType:'CLASSIFY'});
	});
}

function removeProductGroupOrClassify(param){
	mui.confirm('您确定要删除'+param.content+'吗?', '操作确认', ['否', '是'], function(e) {
		if (e.index == 1) {
			plus.nativeUI.showWaiting("正在加载数据,请稍等.");
			var paramChar = param.removeType == 'GROUP' ? ('groupId='+param.removeId) : ('classifyId='+param.removeId);
			var urlEndChar = param.removeType == 'GROUP' ? 'removeProductGroupById' : 'removeProductClassifyById';
			ai.ajax('setting/coreIndex/'+urlEndChar,paramChar,function(data){
				if(data.state){
					if(param.removeType == 'GROUP'){
						loadProductGroupItem();
					}else{
						loadProductClassifyItem();
					}
				}else{
					plus.nativeUI.closeWaiting();
				}
			},function(){
				plus.nativeUI.closeWaiting();
			},function(){
				
			});
		}
	});
}

//初始化添加产品分组事件
function initAddProductGroupEvent(){
	mui('#add-product-group')[0].addEventListener('tap',function(e){
		addProductGroupOrClassify({content:'产品分组',addType:'GROUP'});
	});
}

//初始化添加产品分类事件
function initAddProductClassifyEvent(){
	mui('#add-product-classify')[0].addEventListener('tap',function(e){
		addProductGroupOrClassify({content:'产品分类',addType:'CLASSIFY'});
	});
}

function addProductGroupOrClassify(param){
	mui.prompt('请输入您要创建的'+param.content+'名称：', '', '创建'+param.content, ['取消', '确定'], function(e) {
		if(e.index == 1){
			plus.nativeUI.showWaiting("正在加载数据,请稍等.");
			var paramChar = param.addType == 'GROUP' ? ('groupName='+e.value) : ('classifyName='+e.value);
			var urlEndChar = param.addType == 'GROUP' ? 'saveProductGroupByUser' : 'saveProdcutClassifyByUser';
			ai.ajax('setting/coreIndex/'+urlEndChar,paramChar,function(data){
				if(data.state){
					plus.nativeUI.showWaiting("正在加载数据,请稍等.");
					if(param.addType == 'GROUP'){
						loadProductGroupItem();
					}else{
						loadProductClassifyItem();
					}
				}
			},function(){
				
			},function(){
				plus.nativeUI.closeWaiting();
			});
		}
	});
}

//初始化管理产品分组事件
function initUpdateProductGroupEvent(){
	mui('#product-group-box').on('tap','.mui-btn-success',function(e){
		updateProductGroupOrClassify({updateName:this.dataset.groupName,updateId:this.dataset.groupId,updateType:'GROUP'});
	});
}

//初始化管理产品分类事件
function initUpdateProductClassifyEvent(){
	mui('#product-classify-box').on('tap','.mui-btn-success',function(e){
		updateProductGroupOrClassify({updateName:this.dataset.classifyName,updateId:this.dataset.classifyId,updateType:'CLASSIFY'});
	});
}

function updateProductGroupOrClassify(param){
	ai.openWindow({
		url:"check-classify-product.html",
		id:"page-check-classify-product",
		extras:param
	});
}
