var param = {groupId:0,groupName:''};
var sortable = null;
var coreData = {info:[],operateType:'normal'};

mui.plusReady(function(){
	var self = plus.webview.currentWebview();
	param.groupId = self.groupId;
	param.groupName = self.groupName;
	mui(".mui-title")[0].innerHTML = param.groupName;
	
	initCheckBoxEvent();
	initBtnTapEvent();
	loadAllProductClassify();
});


function loadAllProductClassify(){
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	ai.ajax("setting/coreIndex/getProductClassifyByGroup",{groupId:param.groupId},function(data){
		if(data.state){
			coreData.info = data.info;
			mui('.mui-input-group')[0].innerHTML = template("main-product-classify-template",coreData)
		}
	},function(){
		
	},function(){
		plus.nativeUI.closeWaiting();
	});
}

//初始化页面按钮的Tap事件
function initBtnTapEvent(){
	mui('#core-index-scroll-btn')[0].addEventListener('tap',function(e){
		var _this = this;
		switch (_this.dataset.operateType){
			case "normal"://点击进行入编辑过程
				_this.innerHTML = "保存";
				_this.dataset.operateType = "editing";
				sortable = new Sortable(mui("form")[0], {handle:'.core-index-item'});
				coreData.operateType=_this.dataset.operateType;
				mui('.mui-input-group')[0].innerHTML = template("main-product-classify-template",coreData);
				break;
			case "editing"://点击进入保存过程
				if(mui('.mui-input-group .mui-checkbox').length > 0){
					var checkedBoxArray = mui(".mui-input-group input[checked]");
					if(checkedBoxArray.length > 2){
						mui.alert('您最多只能选择两项');
						return false;
					}
					if(checkedBoxArray.length < 1){
						mui.alert('您至少需要选择一项');
						return false;
					}else{
						var paramChar = "groupId="+param.groupId+"&groupName="+param.groupName;
						checkedBoxArray.each(function(){
							paramChar += "&classifyId="+this.dataset.classifyId;
						});
						plus.nativeUI.showWaiting("正在为您保存设置,请稍等.");
						ai.ajax('setting/coreIndex/saveProductGroupMoreByUser',paramChar,function(data){
							if(data.state){
								_this.innerHTML = "编辑";
								_this.dataset.operateType = "normal";
								sortable && sortable.destroy();
								coreData.operateType=_this.dataset.operateType;
								loadAllProductClassify();
							}else{
								plus.nativeUI.closeWaiting();
							}
						},function(){
							plus.nativeUI.closeWaiting();
						},function(){
							
						});
					}
				}else{
					mui.toast('没有可供保存的产品分类.');
				}
				break;
			default:
				break;
		}
	});
	
	mui('#product-classify-button')[0].addEventListener('tap',function(e){
		mui.prompt('请输入新的自定义产品分类名称：', '', '创建分类', ['取消', '确定'], function(e) {
			if(e.index == 1){
				plus.nativeUI.showWaiting("正在加载数据,请稍等.");
				ai.ajax('setting/coreIndex/saveProdcutClassifyByUser',{classifyName:e.value},function(data){
					if(data.state){
						loadAllProductClassify();
					}else{
						plus.nativeUI.closeWaiting();
					}
				},function(){
					plus.nativeUI.closeWaiting();
				},function(){
					
				});
			}
		});
	});
	
	mui(".mui-input-group").on('tap','.mui-icon-info',function(){
		event.stopPropagation();
		var _this = this;
		ai.openWindow({
			url:"core-diy-classify.html",
			id:"page-core-diy-classify",
			extras:{
				classifyName:_this.dataset.classifyName,
				classifyId:_this.dataset.classifyId
			}
		});
	});
	
	mui(".mui-input-group").on('tap','.mui-icon-trash',function(){
		var _this = this;
		event.stopPropagation();
		mui.confirm('您确定要删除| '+_this.dataset.classifyName+' |吗?', '操作确认', ['取消', '确定'], function(e) {
			if (e.index == 1) {
				plus.nativeUI.showWaiting("正在加载数据,请稍等.");
				ai.ajax('setting/coreIndex/removeProductClassifyById',{classifyId:_this.dataset.classifyId},function(data){
					if(data.state){
						loadAllProductClassify();
					}else{
						plus.nativeUI.closeWaiting();
					}
				},function(){
					plus.nativeUI.closeWaiting();
				},function(){
					
				});
			}
		});
	});
}

//初始化CheckedBox的Check事件
function initCheckBoxEvent(){
	mui('.mui-input-group').on('change', 'input', function() {
		if(this.checked){
			this.setAttribute('checked','checked');
		}else{
			this.removeAttribute('checked');
		}
	});
}