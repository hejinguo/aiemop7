mui.init({
	beforeback:beforeBackSaveSet
});

var param = {};

mui.plusReady(function(){
	var self = plus.webview.currentWebview();
	param.updateName = self.updateName;
	param.updateId = self.updateId;
	param.updateType = self.updateType;

	new Sortable(mui("form")[0]);
	mui(".mui-title")[0].innerHTML = param.updateName;
//	加载待选的初始化数据
	loadWaitCheckClassifyProduct();
//	修改产品分组或分类的名称
	updateClassifyGroupName();
	initCheckBoxEvent();
});

//加载待选的初始化数据
function loadWaitCheckClassifyProduct(){
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	var paramChar = param.updateType == 'GROUP' ? ('groupId='+param.updateId) : ('classifyId='+param.updateId);
	var urlEndChar = param.updateType == 'GROUP' ? 'getProductClassifyByGroup' : 'getProductByClassify';
	ai.ajax('setting/coreIndex/'+urlEndChar,paramChar,function(data){
		if(data.state){
			var table = document.body.querySelector('.mui-input-group');
			mui.each(data.info,function(index,item){
				var checked = "";
			  	var div = document.createElement('div');
				div.className = 'mui-input-row mui-checkbox mui-left';
				if(param.updateType == 'GROUP'){
					div.dataset.classifyId=item.CLASSIFY_ID;
					div.dataset.classifyName=item.CLASSIFY_NAME;//A.CLASSIFY_ID,A.CLASSIFY_NAME,B.GROUP_ID,B.SHOW_ORDER
					div.innerHTML = '<label>'+item.CLASSIFY_NAME+'</label><input type="checkbox" data-classify-id="'+item.CLASSIFY_ID+'" '+(item.GROUP_ID ? 'checked' :'')+'/>';
				}else{
					div.dataset.productId2=item.PRODUCT_ID2;
					div.dataset.productId2Name=item.PRODUCT_ID2_NAME;//A.PRODUCT_ID1,A.PRODUCT_ID1_NAME,A.PRODUCT_ID2,A.PRODUCT_ID2_NAME,B.CLASSIFY_ID
					div.innerHTML = '<label>'+item.PRODUCT_ID2_NAME+'</label><input type="checkbox" data-product-id2="'+item.PRODUCT_ID2+'" '+(item.CLASSIFY_ID ? 'checked' :'')+'/>';
				}
				table.appendChild(div);
			});
		}
	},function(){
		
	},function(){
		plus.nativeUI.closeWaiting();
	});
}

//初始化CheckedBox的Check事件
function initCheckBoxEvent(){
	mui('.mui-input-group').on('change', 'input', function() {
		if(this.checked){
			this.setAttribute('checked','checked');
		}else{
			this.removeAttribute('checked');
		}
	});
}

//返回时保存用户选择的项目
function beforeBackSaveSet(){
	if(mui('.mui-input-group .mui-checkbox').length > 0){
		var checkedBoxArray = mui(".mui-input-group input[checked]");
		if(checkedBoxArray.length > 2 && param.updateType == 'GROUP'){
			mui.alert('您最多只能选择两项');
			return false;
		}
		if(checkedBoxArray.length < 1){
			mui.alert('您至少需要选择一项');
			return false;
		}else{
			var paramChar = "";
			if(param.updateType == 'GROUP'){
				paramChar += "groupId="+param.updateId+"&groupName="+param.updateName;
			}else{
				paramChar += "classifyId="+param.updateId+"&classifyName="+param.updateName;
			}
			checkedBoxArray.each(function(){
				if(param.updateType == 'GROUP'){
					paramChar += "&classifyId="+this.dataset.classifyId;
				}else{
					paramChar += "&productId2="+this.dataset.productId2;
				}
			});
			plus.nativeUI.showWaiting("正在为您保存设置,请稍等.");
			var urlEndChar = param.updateType == 'GROUP' ? 'saveProductGroupMoreByUser' : 'saveProdcutClassifyMoreByUser';
			ai.ajax('setting/coreIndex/'+urlEndChar,paramChar,function(data){
				if(data.state){
					mui.fire(plus.webview.getWebviewById('page-product-group-classify'),'reloadProductGCItem',{updateType:param.updateType});//刷新
				}
			},function(){
				
			},function(){
				plus.nativeUI.closeWaiting();
				return true;
			});
		}
	}
}

//修改产品分组或分类的名称
function updateClassifyGroupName(){
	mui('#update-name-button')[0].addEventListener('tap',function(e){
		mui.prompt('请输入新的'+(param.updateType == 'GROUP' ? '分组' : '分类')+'名称：', '', '修改名称', ['取消', '确定'], function(e) {
			if(e.index == 1){
				if(e.value){
					param.updateName = e.value;
					mui(".mui-title")[0].innerHTML = param.updateName;
				}
			}
		});
	});
}
