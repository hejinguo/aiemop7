mui.init({
	subpages: [{
		url: 'grp-activity-pull.html',
		id: 'page-grp-activity-pull',
		styles: {
			top: '44px',
			bottom: '0px',
		}
	}],
	beforeback: function(){
		var diy_pull= plus.webview.getWebviewById("page-grp-activity-pull");
		if (diy_pull){
			diy_pull.evalJS("saveChange()");
		}
	}
});

mui.plusReady(function(){
	var self = plus.webview.currentWebview();
	var group_id=self.groupId;
	var group_name=self.groupName;
	var txt_title="营销活动定制";
	if(self.groupName){
		txt_title=self.groupName+" 活动定制";
	}
	document.body.querySelector('.mui-title').innerText=txt_title;
	setTimeout(function() {
		mui.fire(plus.webview.getWebviewById('page-grp-activity-pull'), 'initGroupId', {
			groupId:group_id,
			groupName:group_name
		});
	}, 1500);
});
