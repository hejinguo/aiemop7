mui.init({
	beforeback: function(){
		/*if(mktGroupArray.length > 0){
			var param = "";
			plus.nativeUI.showWaiting("正在为您保存设置,请稍等.");
			mui.each(mktGroupArray,function(index,item){
				param += "&mktId="+item.mktId+"&groupId="+item.groupId;
			});
			ai.ajax("setting/diymkt/diyMktInsert",param.substring(1),function(data){
				if(data.state){
					mui.alert('保存设置操作成功。');
					return true;
				}else{
					return false;
				}
			},function(){
				plus.nativeUI.closeWaiting();
				return false;
			},function(){
				plus.nativeUI.closeWaiting();
			});
		}*/
		var diy_pull= plus.webview.getWebviewById("page-market-diy-pull");
		if (diy_pull){
			diy_pull.evalJS("saveSetting()");
		}
	},
	subpages: [{
		url: 'market-diy-pull.html',
		id: 'page-market-diy-pull',
		styles: {
			top: '44px',
			bottom: '0px',
		}
	}]
});

//对营销活动的拖动
mui.plusReady(function(){
		
});
