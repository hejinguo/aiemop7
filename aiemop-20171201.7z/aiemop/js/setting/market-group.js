var app = null;
var defaultSelect = {};

mui.plusReady(function() {
	app = new Vue({
		el: '#page-body-vid',
		data: {
			title: '关注营销活动',
			handle : {type:'normal',title:'编辑'},
			groups: []
			
		},
		methods: {
			loadMarketGroup: function() {//加载营销活动分组
				var _this = this;
				plus.nativeUI.showWaiting("正在加载数据,请稍等.");
				ai.ajax("setting/diymkt/diyMktGroup", {}, function(data) {
					if (data.state && data.info) {
						_this.groups = data.info;
						var de = data.info.filter(function(item){
							return item.DEFAULT_FLAG == 1;
						});
						defaultSelect = de && de[0];
					}
				},function(){
					
				},function(){
					plus.nativeUI.closeWaiting();
				});
			},
			switchHandle: function(){//切换编辑和浏览的状态
				var _this = this;
				switch (_this.handle.type){
					case "normal"://点击进行入编辑过程
						this.handle = {type:"editing",title:"保存"};
						break;
					case "editing"://点击进入保存过程
						var checkGroupId = null;
						var checkedRadio = mui(".mui-input-group input[checked]")[0];
						if(checkedRadio){
							checkGroupId = checkedRadio.value;
						}else{
							checkGroupId = defaultSelect.GROUP_ID;
						}
						if(checkGroupId){
							plus.nativeUI.showWaiting("正在保存设置,请稍等.");
							ai.ajax('setting/diymkt/updateDefaultMktGroup',{groupId:checkGroupId},function(data){
								if(data.state){
									_this.handle = {type:"normal",title:"编辑"};
									_this.groups = [];
									_this.loadMarketGroup();
								}else{
									plus.nativeUI.closeWaiting();
								}
							},function(){
								plus.nativeUI.closeWaiting();
							},function(){
								
							});
						}else{
							mui.alert('请选择默认的营销活动分组','提示');
						}
						break;
					default:
						break;
				}
			},
			addMarketGroup: function() {//创建营销活动分组
				var _this = this;
				mui.prompt('请输入新的营销活动分组名称：', '', '创建分组', ['取消', '确定'], function(e) {
					if(e.index == 1){
						plus.nativeUI.showWaiting("正在保存设置,请稍等.");
						ai.ajax('setting/diymkt/createMktGroup',{groupName:e.value,showOrder:1},function(data){
							if(data.state){
								_this.loadMarketGroup();
							}else{
								plus.nativeUI.closeWaiting();
							}
						},function(){
							plus.nativeUI.closeWaiting();
						},function(){
							
						});
					}
				});
			},
			showMarketGroup: function(groupId,groupName) {//打开新窗口查看营销活动分组信息
				ai.openWindow({
					url:"market-group-activity.html",
					id:"page-market-group-activity",
					extras:{
						groupId:groupId,
						groupName:groupName
					}
				});
			},
			deleteMarketGroup: function(groupId,groupName) {//删除营销活动分组记录
				var _this = this;
				mui.confirm('您确定要删除| '+groupName+' |吗?', '操作确认', ['取消', '确定'], function(e) {
					if (e.index == 1) {
						plus.nativeUI.showWaiting("正在保存设置,请稍等.");
						ai.ajax('setting/diymkt/deleteMktGroup',{groupId:groupId},function(data){
							if(data.state){
								_this.loadMarketGroup();
							}else{
								plus.nativeUI.closeWaiting();
							}
						},function(){
							plus.nativeUI.closeWaiting();
						},function(){
							
						});
					}
				});
			}
		}
	});
	
	initRadioBoxEvent();
	app.loadMarketGroup();//加载默认展示的营销活动分组数据
});

//初始化RadioBox的Check事件
function initRadioBoxEvent(){
	mui('.mui-input-group').on('change', 'input', function() {
		mui.each(mui('.mui-input-group input'),function(i,n){
			n.removeAttribute('checked');
		});
		this.setAttribute('checked','checked');
	});
}
