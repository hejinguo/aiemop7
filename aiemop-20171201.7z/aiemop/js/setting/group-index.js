var groupIndexTypeColor = ["#525865","#60B389","#F45B53","#68BBF4","#292B31"];
var sortable = new Array();
var coreData = {info:[],operateType:'normal'};

mui.plusReady(function() {
	initBtnTapEvent();
	loadAllGroupIndexItem();
	
	mui('#group-index-selected')[0].style.height = (plus.display.resolutionHeight-44-76)+"px";
	mui('#group-index-unselect')[0].style.height = (plus.display.resolutionHeight-44-76)+"px";
});


function loadAllGroupIndexItem(){
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	ai.ajax("setting/grpIndex/getGrpIndexD", {}, function(data) {
		if(data.state) {
			coreData.info = data.info;
			mui("#goup-index-type")[0].innerHTML = template("group-index-type-template",{typeCount:coreData.info.TypeCount,operateType:coreData.operateType,typeColor:groupIndexTypeColor});
			mui("#group-index-selected")[0].innerHTML = template("group-index-select-template",{groupIndex:coreData.info.DoneIndex,operateType:coreData.operateType,typeColor:groupIndexTypeColor});
			mui("#group-index-unselect")[0].innerHTML = template("group-index-select-template",{groupIndex:coreData.info.UnDoneIndex,operateType:coreData.operateType,typeColor:groupIndexTypeColor});
		}
	}, function() {
		
	}, function() {
		plus.nativeUI.closeWaiting();
	});
}

function initBtnTapEvent(){
	mui('#core-index-scroll-btn')[0].addEventListener('tap',function(e){
		var _this = this;
		switch (_this.dataset.operateType){
			case "normal"://点击进行入编辑过程
				_this.innerHTML = "保存";
				_this.dataset.operateType = "editing";
				sortable[0] = new Sortable(mui("#group-index-selected")[0], {handle:'.core-index-item',group: "omega"});
				sortable[1] = new Sortable(mui("#group-index-unselect")[0], {handle:'.core-index-item',group: "omega"});
				coreData.operateType=_this.dataset.operateType;
				mui("#group-index-selected")[0].innerHTML = template("group-index-select-template",{groupIndex:coreData.info.DoneIndex,operateType:coreData.operateType,typeColor:groupIndexTypeColor});
			mui("#group-index-unselect")[0].innerHTML = template("group-index-select-template",{groupIndex:coreData.info.UnDoneIndex,operateType:coreData.operateType,typeColor:groupIndexTypeColor});
				break;
			case "editing"://点击进入保存过程
				if(mui('#group-index-selected').length > 0){
					var checkedBoxArray = mui("#group-index-selected div");
					if(checkedBoxArray.length < 1){
						mui.alert('您至少需要关注1个集团指标');
						break;
					}else{
						var param = "";
						checkedBoxArray.each(function(){
							param += "&grpIndex="+this.dataset.indexId;
						});
						plus.nativeUI.showWaiting("正在为您保存设置,请稍等.");
						ai.ajax('setting/grpIndex/modify',param.substring(1),function(data){
							if(data.state){
								_this.innerHTML = "编辑";
								_this.dataset.operateType = "normal";
								sortable[0] && sortable[0].destroy();
								sortable[1] && sortable[1].destroy();
								coreData.operateType=_this.dataset.operateType;
								loadAllGroupIndexItem();
							}else{
								plus.nativeUI.closeWaiting();
							}
						},function(){
							plus.nativeUI.closeWaiting();
						},function(){
							
						});
					}
				}
				break;
			default:
				break;
		}
	});
}
