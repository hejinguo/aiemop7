mui.init({
	pullRefresh: {
		container: '#pullup-container',
		up: {
			contentrefresh: '正在加载...',
			callback: pullupRefresh
		}
	}
});

var app = null;
var delMktId = [];//需要从分组中删除的营销活动
var addMktId = [];//需要往分组中添加的营销活动
var param = {groupId:-1,marketName:'',pageNo:1,pageSize:20};

mui.plusReady(function() {
	app = new Vue({
		el: '#mui-input-group-vid',
		data: {
			handle : {type:'normal',title:'编辑'},
			activitys: []
		},
		methods: {
			
		}
	});

	window.addEventListener('initPageParamId',function(event){
		param.groupId = event.detail.groupId;
		loadMarketGroupActivity();
	});
	window.addEventListener('changeSwitchHandle',function(event){
		switch (event.detail.type){
			case "normal"://点击进行保存操作后切换到编辑状态
				plus.nativeUI.showWaiting("正在保存设置,请稍等.");
				var paramStr = "groupId="+param.groupId;
				if(delMktId.length == 0){
					paramStr += "&delMtkId=";
				}
				mui.each(delMktId,function(i,n){
					paramStr += "&delMtkId="+n;
				});
				if(addMktId.length == 0){
					paramStr += "&addMktId=";
				}
				mui.each(addMktId,function(i,n){
					paramStr += "&addMktId="+n;
				});
//				console.log(paramStr);
				ai.ajax('setting/diymkt/diyMktBathDelAndInsert',paramStr,function(data){
					if(data.state){
						app.handle = event.detail;
						loadMarketGroupActivity();
					}else{
						plus.nativeUI.closeWaiting();
					}
				},function(){
					plus.nativeUI.closeWaiting();
				},function(){
					
				});
				break;
			case "editing"://点击进入等待用户操作后保存的状态过程
				app.handle = event.detail;
				break;
			default:
				break;
		}
	});
//	初始化搜索框事件
	initSearchBoxEvent();
	initCheckBoxEvent();
});

//初始化搜索框事件
function initSearchBoxEvent(){
	mui('span.mui-placeholder')[0].addEventListener('tap',function(e){
		mui('.mui-input-clear')[0].focus();
	});
	document.querySelector('form').addEventListener('submit', function(e){
	    e.preventDefault(); // 阻止默认事件
	    var searchInputBox = mui('.mui-input-clear')[0];
	    searchInputBox.blur();
	    param.marketName = searchInputBox.value;
	    mui('#pullup-container').pullRefresh().refresh(true);//重置上拉加载
	    loadMarketGroupActivity();
	});
}

function loadMarketGroupActivity(){
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	app.activitys = [];
	delMktId = [];
	addMktId = [];
	param.pageNo = 1;
	pullupRefresh();
	if(mui.os.ios){
		plus.webview.currentWebview().evalJS("mui('#pullup-container').pullRefresh().scrollTo(0,0,100)");
	}else{
		plus.webview.currentWebview().evalJS('mui.scrollTo(0, 100)');
	}
}

function pullupRefresh() {
	setTimeout(function() {
		ai.ajax('setting/diymkt/getActivityByGroup',param,function(data){
			if(data.state){
				app.activitys = app.activitys.concat(data.info.rows)
				mui.toast('共'+data.info.total+'条记录,已加载'+(param.pageNo*param.pageSize > data.info.total ? '完毕':param.pageNo*param.pageSize+'条'));
				if(++param.pageNo > Math.ceil(data.info.total/param.pageSize)){
					mui('#pullup-container').pullRefresh().endPullupToRefresh(true);//加载完毕
				}else{
					mui('#pullup-container').pullRefresh().endPullupToRefresh(false);//还有更多数据
				}
			}
		},function(){
			mui('#pullup-container').pullRefresh().endPullupToRefresh(false);//还有更多数据
		},function(){
			plus.nativeUI.closeWaiting();
		});
	}, 1500);
}

//初始化CheckedBox的Check事件
function initCheckBoxEvent(){
	mui('.mui-input-group').on('change', 'input', function() {
		var _this = this;
		if(_this.checked){
			addMktId = addMktId.filter(function(item) {
				return item != _this.value;
			});
			if(delMktId.indexOf(_this.value) < 0){//未找到
				addMktId.push(_this.value);
			}
			delMktId = delMktId.filter(function(item) {
			    return item != _this.value;
			});
			_this.setAttribute('checked','checked');
		}else{
			delMktId = delMktId.filter(function(item) {
			    return item != _this.value;
			});
			if(addMktId.indexOf(_this.value) < 0){//未找到
				delMktId.push(_this.value);
			}
			addMktId = addMktId.filter(function(item) {
			    return item != _this.value;
			});
			_this.removeAttribute('checked');
		}
//		console.log(JSON.stringify(addMktId)+"    "+JSON.stringify(delMktId));
	});
}