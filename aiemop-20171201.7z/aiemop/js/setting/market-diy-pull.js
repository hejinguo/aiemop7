mui.init({
	pullRefresh: {
		container: '#pullrefresh',
		up: {
			callback: pullupRefresh
		}
	},
	gestureConfig: {
		tap: true, //默认为true
		doubletap: true, //默认为false
		longtap: true, //默认为false
		swipe: true, //默认为true
		drag: true, //默认为true
		hold: false, //默认为false，不监听
		release: false //默认为false，不监听
	}
});
var mktGroupArray = new Array(); //用于缓存用户的设置
var para = {
	'pageNo': 1,
	'pageSize': 10
}

mui.plusReady(function() {
	//计算中间高度
	var item_height = plus.display.resolutionHeight - 44 -63;
	//mui.alert(item_height);
	var foo = document.getElementById('pullrefresh');
	foo.style.height = item_height + "px";
	var mui_con = document.getElementById('mui_con');
	mui_con.style.height = (item_height+60) + "px";
	/*
	 * 加载可以关注的营销活动
	 */
	initDiyMkt();

	searchDiyMkt();
	/**
	 * 营销活动分组
	 */
	loadGroupData();
	//单击按钮事件
	mui('#bar').on("tap", ".mui-table-view-cell", function(e) {
		var groupId = this.dataset.groupId;
		var groupName = this.dataset.groupName;
		//mui.alert(mktGroupArray.toString());
		if (groupId) {
			ai.openWindow({
				url: "grp-activity.html",
				id: "page-grp-activity",
				extras: {
					groupId: groupId,
					groupName: groupName
				}
			});
		} else {
			var tobj = this;
			createGroup(-1, '');
		}
	});
	//分组长按事件，弹出分组名称编辑对话框
	//如果返回的值为空将直接删除该组
	mui('#bar').on("longtap", ".mui-table-view-cell", function(e) {
		var groupId = this.dataset.groupId;
		var groupName = this.dataset.groupName;
		if (groupId && groupName && groupName!='默认组') {
			createGroup(groupId, groupName);
		}
	});

	//获取营销活动的ID
	var foo = document.getElementById("foo"); //活动
	new Sortable(foo, {
		group: {
			name: "omega",
			put: false
		},
		sort: false,
		onMove: function(evt) {
			var flag = false;
			var mktId = evt.dragged.dataset.mktId;
			var groupId = evt.related.dataset.groupId;
			if (groupId && groupId != "") {
				mui.each(mktGroupArray, function(index, item) {
					if (item.mktId == mktId && item.groupId == groupId) {
						flag = true;
					}
				});
				if (!flag) {
					mktGroupArray.push({
						mktId: mktId,
						groupId: groupId
					});
				}
				mui.toast('添加成功，返回后统一保存！');
				//evt.related.innerHTML=evt.related.innerHTML;
			} else {
				mui.toast('请先创建分组！');
				///createGroup();
			}
			return false;
		}
	});
	//获取活动分组的ID
	var bar = document.getElementById("bar"); //分组
	new Sortable(bar, {
		group: {
			name: "omega",
			pull: false
		},
		sort: true
	});

});

function searchDiyMkt() {
	document.querySelector('form').addEventListener('submit', function(e) {
		e.preventDefault(); // 阻止默认事件
		var searchInputBox = mui('.mui-input-clear')[0];
		searchInputBox.blur();
		para.marketName = searchInputBox.value;
		mui('#pullrefresh').pullRefresh().refresh(true); //重置上拉加载
		initDiyMkt();
	});
}

function initDiyMkt() {
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	mui('#foo')[0].innerHTML = "";
	para.pageNo = 1;
	pullupRefresh();
}

function pullupRefresh() {
	setTimeout(function() {
		ai.ajax("setting/diymkt/diyMktActivity", para, function(data) {
			//mui.toast(JSON.stringify(data));
			if (data.state) {
				var table = mui('#foo')[0]; //活动
				mui.each(data.info.rows, function(index, item) {
					var li = document.createElement('li');
					if (!item.MKT_CONTENT) {
						item.MKT_CONTENT = "无";
					}
					li.className = 'mui-table-view-cell';
					li.dataset.mktId = item.MKT_ID;
					li.innerHTML = '<h4 class="mui-ellipsis">' + item.MKT_NAME + '</h4>' +
						'<h5 class="mui-ellipsis">活动时间：' + item.MKT_BEGIN_TIME + '~' + item.MKT_END_TIME + '</h5>' +
						'<h5 class="mui-ellipsis">活动地域：' + item.ORG_NAME + '</h5>' +
						'<h5 class="mui-ellipsis-2">活动描述：' + item.MKT_CONTENT + '</h5>';
					table.appendChild(li);
				});
				mui.toast('共' + data.info.total + '条记录,已加载' + (para.pageNo * para.pageSize > data.info.total ? '完毕' : para.pageNo * para.pageSize + '条'));
				if (++para.pageNo > Math.ceil(data.info.total / para.pageSize)) {
					mui('#pullrefresh').pullRefresh().endPullupToRefresh(true); //加载完毕
				} else {
					mui('#pullrefresh').pullRefresh().endPullupToRefresh(false); //还有更多数据
				}
			}
		}, function() {

		}, function() {
			plus.nativeUI.closeWaiting();
		});
	}, 1500);
}
/**
 * 创建分组数据
 */
function createGroup(groupId, groupName) {
	var curr_name = "";
	if (groupId != -1 && groupName != '') {
		curr_name = groupName;
	}
	mui.prompt("请输入新的分组名称：", curr_name, "提示", ['确定', '取消'], function(e) {
		if (e.index == 0) {
			if (e.value && e.value != "") {
				plus.nativeUI.showWaiting("正在为您保存设置,请稍等.");
				var param = {
					groupName: e.value,
					showOrder: 1
				};
				var con_url = 'setting/diymkt/createMktGroup';
				if (groupId != -1) {
					con_url = 'setting/diymkt/updateMktGroup';
					param.groupId = groupId;
				}
				ai.ajax(con_url, param, function(data) {
					if (data.state) {
						//tobj.dataset.groupId = data.info;
						//tobj.innerHTML = '<h4 class="mui-ellipsis">' + param.groupName + '</h4>';
						loadGroupData();
					}
				}, function() {
					plus.nativeUI.closeWaiting();
				}, function() {
					plus.nativeUI.closeWaiting();
				});
			} else {
				//删除群组
				if (groupId != -1) {
					ai.ajax("setting/diymkt/deleteMktGroup", {
						groupId: groupId
					}, function(data) {
						if (data.state) {
							loadGroupData();
						}
					}, function() {

					}, function() {

					});
				} else {
					mui.toast('请重新输入分组名称！');
				}
			}
		}
	}, 'div');
	document.querySelector('.mui-popup-input input').value = curr_name;
}
/**
 * 加载分组
 */
function loadGroupData() {
	ai.ajax("setting/diymkt/diyMktGroup", {}, function(data) {
		if (data.state && data.info) {
			var table = mui('#bar')[0]; //分组
			table.innerHTML = "";
			var li_length = data.info.length
			mui.each(data.info, function(index, item) {
				if (item.GROUP_NAME != "") {
					var li = document.createElement('li');
					li.dataset.groupId = item.GROUP_ID;
					li.dataset.groupName = item.GROUP_NAME;
					li.setAttribute("group_id",item.GROUP_ID);
					li.className = 'mui-table-view-cell mui-media mui-col-xs-4';
					li.innerHTML = '<h4 class="mui-ellipsis"><span class="mui-icon iconfont icon-wenjianjia"></span>' + item.GROUP_NAME + '</h4>';
					table.appendChild(li);
				} else {
					li_length = li_length - 1;
				}
			});
			if (li_length < 3) {
				for (var i = 0; i < 3 - li_length; i++) {
					var li = document.createElement('li');
					li.setAttribute("group_id",0);
					li.className = 'mui-table-view-cell mui-media mui-col-xs-4';
					li.innerHTML = '<h4 class="mui-ellipsis"><span class="mui-icon mui-icon-plusempty"></span></h4>';
					table.appendChild(li);
				}
			}
		}
	});
}

/**
 * 保存关注的活动；
 * 保存分组排序；
 */
function saveSetting() {
	//分组排序设置
	var group_list = document.querySelectorAll("#bar li");
	var str_group="";
	mui.each(group_list, function(index, item) {
		str_group+=item.getAttribute("group_id")+",";
	});
	ai.ajax("setting/diymkt/updateGroupOrder",{'groupId':str_group},function(data){
		
	},function(){
		
	},function(){
		
	});
	//mui.alert(str_group);
	if (mktGroupArray.length > 0) {
		var param = "";
		//plus.nativeUI.showWaiting("正在为您保存设置,请稍等.");
		mui.each(mktGroupArray, function(index, item) {
			param += "&mktId=" + item.mktId + "&groupId=" + item.groupId;
		});
		ai.ajax("setting/diymkt/diyMktInsert", param.substring(1), function(data) {
			if (data.state) {
				mui.toast('保存设置操作成功。');
				return true;
			} else {
				return false;
			}
		}, function() {
			//plus.nativeUI.closeWaiting();
			return false;
		}, function() {
			//plus.nativeUI.closeWaiting();
		});
	}
	
}