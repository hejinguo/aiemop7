//mui.init({
//	statusBarBackground: '#0085d0',
//	subpages:[{
//		url:'home-pull.html',
//		id:'page-home-pull',
//		styles:{
//			top:'0px',
//			bottom:'0px'
////			scrollIndicator:'none'
//		}
//	}]
//});

//mui.plusReady(function(){
	//plus.navigator.closeSplashscreen();
	/*
	var noticew=plus.webview.create("../base/notice.html","page_notice.html",{width:'260px',height:'330px',margin:"auto",background:"rgba(0,0,0,0.6)",scrollIndicator:'none',scalable:false,popGesture:'none'});
	noticew.addEventListener("loaded",function(){
		noticew.show('fade-in',300);
	},false);
	*/
//	mui.alert('ai.user.organize.orgType='+ai.user.organize.orgType);
//});

