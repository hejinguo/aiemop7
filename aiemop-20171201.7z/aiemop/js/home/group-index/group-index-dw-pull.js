mui.init({
	pullRefresh: {
		container: '#pullup-container',
		up: {
			callback: pullupRefresh
		}
	}
});

var param = {pageNo:1,pageSize:10,indexId:-1,orgId:0,unitNameCode:''};
template.helper("_decimalFormat", ai.decimalFormat);

mui.plusReady(function(){
//	初始化由主窗口触发的函数
	initParamIndexId();
//	初始化搜索框事件
	initSearchBoxEvent();

	/*
    window.addEventListener('showOrganizePopover',function(event){
		mui('#organize-popover').popover('show');
	});
	
	mui("#organize-popover").on("tap",".mui-table-view-cell",function(e){
     	param.orgId = this.dataset.orgId;
		mui.fire(plus.webview.getWebviewById('page-group-index-dw'),'changeOrgName',{orgName:this.dataset.orgName});
		plus.nativeUI.showWaiting("正在加载数据,请稍等.");
		loadIndexUnitValueItem();
     });
	
	mui('#organize-popover>.mui-scroll-wrapper').scroll();
	*/
});

//初始化搜索框事件
function initSearchBoxEvent(){
	mui('span.mui-placeholder')[0].addEventListener('tap',function(e){
		mui('.mui-input-clear')[0].focus();
	});
	document.querySelector('form').addEventListener('submit', function(e){
	    e.preventDefault(); // 阻止默认事件
	    var searchInputBox = mui('.mui-input-clear')[0];
	    searchInputBox.blur();
	    param.unitNameCode = searchInputBox.value;
	    mui('#pullup-container').pullRefresh().refresh(true);//重置上拉加载
	    plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	    loadIndexUnitValueItem();
	});
}

//初始化由主窗口触发的函数
function initParamIndexId(){
	window.addEventListener('initParamIndexId',function(event){
		plus.nativeUI.showWaiting("正在加载数据,请稍等.");
		param.indexId=event.detail.indexId;
		var poId = event.detail.poId;//parentOrgId
		var ogId = event.detail.ogId;//currentOrgId
		var ogName = event.detail.ogName;//currentOrgName
		if(poId){
			param.orgId = ogId;
			mui.fire(plus.webview.getWebviewById('page-group-index-dw'),'changeOrgName',{orgName:ogName});
			loadIndexUnitValueItem();
			/*
//			ai.ajax("base/organize/getOrganizeByParent",{parentOrgId:poId},function(data){
			ai.ajax("index/group/orgIndexValueById",{orgId:poId,indexId:param.indexId},function(data){//过度时期按指标值来的机构排序
				if(data.state){
					var table = mui('#organize-popover ul')[0];//document.body.querySelector('#organize-popover ul');
					table.innerHTML='';
					mui.each(data.info,function(index,item){
						var li = document.createElement('li');
						li.className = 'mui-table-view-cell';
						li.dataset.orgId=item.ORG_ID;
						li.dataset.orgName=item.ORG_NAME;
						li.innerHTML = item.ORG_NAME;
						table.appendChild(li);
						if(index == 0){
							param.orgId = item.ORG_ID;
							mui.fire(plus.webview.getWebviewById('page-group-index-dw'),'changeOrgName',{orgName:item.ORG_NAME});
						}
					});
					loadIndexUnitValueItem();
				}else{
					plus.nativeUI.closeWaiting();
				}
			},function(){
				
			},function(){
				
			});
			*/
		}else{
			mui.fire(plus.webview.getWebviewById('page-group-index-dw'),'changeOrgName',{orgName:ai.user.organize.orgName});
			loadIndexUnitValueItem();
		}
	});
}

//加载集团指标集团明细值记录
function loadIndexUnitValueItem(){
	document.body.querySelector('.mui-scroll>.mui-table-view').innerHTML='';
	mui('#pullup-container').pullRefresh().refresh(true);//重置上拉加载  
	param.pageNo = 1;
    pullupRefresh();
    if(mui.os.ios){
		plus.webview.currentWebview().evalJS("mui('#pullup-container').pullRefresh().scrollTo(0,0,100)");
	}else{
		plus.webview.currentWebview().evalJS('mui.scrollTo(0, 100)');
	}
}

function pullupRefresh(){
	setTimeout(function() {
		ai.ajax("index/group/indexUnitValueByOrg",param,function(data){
			if(data.state){
				var table = document.body.querySelector('.mui-scroll>.mui-table-view');
				mui.each(data.info.rows,function(index,item){
				  	var li = document.createElement('li');
					li.className = 'mui-table-view-cell';
					li.dataset.unitId=item.UNIT_ID;
					var acc = (item.INDEX_VALUE_TYPE == 1 ? 0 : item.INDEX_VALUE_TYPE == 2 ? 2 : 4);
					li.innerHTML = template('group-index-item-template', {acc:acc,item:item});
					table.appendChild(li);
				});
				
				mui.toast('共'+data.info.total+'条记录,已加载'+(param.pageNo*param.pageSize > data.info.total ? '完毕':param.pageNo*param.pageSize+'条'));
				if(++param.pageNo > Math.ceil(data.info.total/param.pageSize)){
					mui('#pullup-container').pullRefresh().endPullupToRefresh(true);//加载完毕
				}else{
					mui('#pullup-container').pullRefresh().endPullupToRefresh(false);//还有更多数据
				}
			}
		},function(){
			mui('#pullup-container').pullRefresh().endPullupToRefresh(false);//还有更多数据
		},function(){
			plus.nativeUI.closeWaiting();
		});
	}, 1500);
}
