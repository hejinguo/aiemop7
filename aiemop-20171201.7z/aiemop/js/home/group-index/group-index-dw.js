mui.init({
	gestureConfig:{
		doubletap: true
	},
	subpages:[{
		url:'group-index-dw-pull.html',
		id:'page-group-index-dw-pull',
		styles:{
			top: '44px',
			bottom: '0px'
		}
	}]
});

mui.plusReady(function(){
	var self = plus.webview.currentWebview();
	mui('#group-index-title')[0].innerText=self.indexName;
	mui('.mui-title a')[0].innerText=self.currentOrgName ? self.currentOrgName : ai.user.organize.orgName;
	
	setTimeout(function(){
		mui.fire(plus.webview.getWebviewById('page-group-index-dw-pull'),'initParamIndexId',{
			indexId:self.indexId,
			poId:self.parentOrgId,
			ogId:self.currentOrgId,
			ogName:self.currentOrgName
		});
	},500);
	
	/*
	var orgType = ai.user.organize.orgType;
	if(orgType < 5){
		mui('#organize-popover-button')[0].addEventListener('tap', function(e){
			mui.fire(plus.webview.getWebviewById('page-group-index-dw-pull'),'showOrganizePopover');
		});
	}
	*/
	
	window.addEventListener('changeOrgName',function(event){
		mui('.mui-title a')[0].innerText=event.detail.orgName;
	});

	var contentWebview = null;
	mui('header')[0].addEventListener('doubletap',function () {
		if(contentWebview==null){
			contentWebview = plus.webview.currentWebview().children()[0];
		}
		contentWebview.evalJS("mui('#pullup-container').pullRefresh().scrollTo(0,0,100)");
	});
});