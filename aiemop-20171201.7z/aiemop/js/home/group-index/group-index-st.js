mui.init({
	gestureConfig:{
		hold:true,//按住屏幕
		release:true//离开屏幕
	},
	beforeback:function() {
		if(indexLevel.length > 1){
//			返回上一层指标数据
			plus.nativeUI.showWaiting("正在加载数据,请稍等.");
			indexLevel.pop();
			param.orgId = indexLevel[indexLevel.length-1].orgId;
			mui('.mui-title a')[0].innerText=indexLevel[indexLevel.length-1].orgName;
			loadGroupIndexChart();
			return false;
		}else{
			return true;
		}
	}
});

var myChart = null;
var param = {indexId:-1,orgId:-1};
var chartType = "bar-chart";//默认显示柱状图
var indexLevel = new Array();
template.helper("_decimalFormat", ai.decimalFormat);

mui.plusReady(function(){
    mui('#group-index-title')[0].innerText=plus.webview.currentWebview().indexName;
    mui('.mui-title a')[0].innerText=ai.user.organize.orgName;

// 	初始化页面的下钻操作
    clickNextLevelEvent();
//  初始化变更页面数据展示方式
//  changeShowTypeEvent();
//  初始化点击机构名称打开选择操作列表事件
//  organizeNameTapEvent();
// 	初始化同等级机构变更操作事件
//	changeShowOrganizeEvent();
    
    mui('#organize-popover>.mui-scroll-wrapper').scroll();
    indexLevel.push({orgId:ai.user.organize.orgId,orgName:ai.user.organize.orgName,orgType:ai.user.organize.orgType});//默认使用当前机构ID
    param.indexId = plus.webview.currentWebview().indexId;
    param.orgId = indexLevel[indexLevel.length-1].orgId;
    plus.nativeUI.showWaiting("正在加载数据,请稍等.");
    loadGroupIndexChart();
//  直接关闭窗口事件
    mui('#close-page-button')[0].addEventListener('tap',function(e){
		plus.webview.currentWebview().close();
	});
	
	mui('.mui-slider-group').on('release','.echarts-div-box',function(e){
		var myChart = echarts.getInstanceByDom(document.getElementById(this.getAttribute('id')));
	  	myChart.dispatchAction({type:'hideTip'});
	});
});

//初始化页面数据展示方式事件
//function changeShowTypeEvent(){
//	mui("#more-popover").on("tap",".mui-table-view-cell",function(e){
//  	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
//		chartType = this.dataset.itemType;
//		loadGroupIndexChart();
//  });
//}

//初始化页面的下钻操作事件
function clickNextLevelEvent(){
	mui("#group-index-item").on("tap",".mui-table-view-cell",function(e){
	    if(indexLevel[indexLevel.length-1].orgType >= 4){//4:当前层级为片区查看经理级别
	    	var currentOrgId = this.dataset.orgId;
	    	var currentOrgName = this.dataset.orgName;
			ai.openWindow({
				url:"group-index-dw.html",
	    		id:"page-group-index-dw",
	    		extras:{
	    			indexId:plus.webview.currentWebview().indexId,
	    			indexName:plus.webview.currentWebview().indexName,
	    			parentOrgId:indexLevel[indexLevel.length-1].orgId,
	    			currentOrgId:currentOrgId,
	    			currentOrgName:currentOrgName
	    		}
			});
		}else{
			plus.nativeUI.showWaiting("正在加载数据,请稍等.");
			indexLevel.push({orgId:this.dataset.orgId,orgName:this.dataset.orgName,orgType:this.dataset.orgType});
			param.orgId = this.dataset.orgId;
			mui('.mui-title a')[0].innerText=this.dataset.orgName;
			loadGroupIndexChart();
		}
	});
}

//立即刷新当前层级Charts
function loadGroupIndexChart(){
	setTimeout('initBarCharts()',1500);
	setTimeout('initLineCharts()',1500);
	setTimeout('initDetailItem()',1500);
//	if(chartType == "bar-chart"){
//		setTimeout('initBarCharts()',1500);
//		setTimeout('initDetailItem()',1500);
//	}else if(chartType == "line-chart"){
//		setTimeout('initLineCharts()',1500);
//		setTimeout('initDetailItem()',1500);
//	}else if(chartType == "detail-item"){
//		
//	}
}

/*
//初始化点击机构名称打开选择操作列表事件
function organizeNameTapEvent(){
	mui('#organize-popover-button')[0].addEventListener("tap",function(){
    	if(indexLevel[indexLevel.length-1].orgId != ai.user.organize.orgId){
    		mui('.mui-scroll-wrapper').scroll().scrollTo(0,0,100);
    		mui('#organize-popover').popover('show');
    	}
    });
}

//初始化同等级机构变更操作事件
function changeShowOrganizeEvent(){
	mui("#organize-popover").on("tap",".mui-table-view-cell",function(e){
    	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
     	indexLevel[indexLevel.length-1].orgId = this.dataset.orgId;
     	indexLevel[indexLevel.length-1].orgName = this.dataset.orgName;
     	param.orgId = indexLevel[indexLevel.length-1].orgId;
		mui('.mui-title a')[0].innerText=indexLevel[indexLevel.length-1].orgName;
		loadGroupIndexChart();
    });
}

//加载机构列表和指标数据Charts
function loadOrganizeAndIndex(levelType){
	var poid = -1;
	if(levelType > 0){
		poid = indexLevel[indexLevel.length-1].orgId;
	}else if(levelType < 0 && indexLevel.length-3 >=0){
		poid = indexLevel[indexLevel.length-3].orgId;
	}
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
//	ai.ajax("base/organize/getOrganizeByParent",{parentOrgId:poid},function(data){
	ai.ajax("index/group/orgIndexValueById",{orgId:poid,indexId:param.indexId},function(data){//过度时期按指标值来的机构排序
		if(data.state){
			var table = mui('#organize-popover ul')[0];
			table.innerHTML='';
			mui.each(data.info,function(index,item){
				var li = document.createElement('li');
				li.className = 'mui-table-view-cell';
				li.dataset.orgId=item.ORG_ID;
				li.dataset.orgName=item.ORG_NAME;
				li.innerHTML = item.ORG_NAME;
				table.appendChild(li);
			});
		}else{
			plus.nativeUI.closeWaiting();
		}
	},function(){
		plus.nativeUI.closeWaiting();
	},function(){
		
	});
}
*/

function initBarCharts(){
	ai.ajax("index/group/barIndexValueById",param,function(data){
		if(data.state){
			var mainDiv = document.getElementById('main-echarts-1');
			myChart = echarts.init(mainDiv);
			var option = {
			    tooltip : {
			        trigger: 'axis',
			        position:['20%',1],
			        formatter: '{b} : {c}',
			        axisPointer : {            // 坐标轴指示器，坐标轴触发有效
			            type : 'line'        // 默认为直线，可选为：'line' | 'shadow'
			        }
			    },
			    grid:{top:10,bottom:40,left:40,right:10},
			    backgroundColor:'#0085D0',
				color:['#78CDE1', '#CBE07B','#FE967D', '#DF7CFA', '#FDE47F'],
			    xAxis : [
			        {
			            type:'category',
			            axisLine:{lineStyle:{color:'#FFF'}},
			            axisTick:{lineStyle:{color:'#FFF'}},
			            axisLabel:{textStyle:{color:'#FFF'}},
		//	            axisLabel:{interval:0,rotate:60,textStyle:{color:'#FFF'}},
					    splitLine:{show:false},
			            data : data.info.xAxisData
			        }
			    ],
			    yAxis : [
			        {
			            type : 'value',
			            axisLine:{lineStyle:{color:'#FFF'}},
			            axisTick:{lineStyle:{color:'#FFF'}},
			            axisLabel:{textStyle:{color:'#FFF'},formatter:function(value, index){
			            	return ai.echartsAxisFormat(value);
			            }},
//			            position: 'left',
			            splitLine:{show:true,lineStyle:{color:'#498FD0'}}
			        }
			    ],
			    series : [
			        {
			            name:'机构分布',
			            type:'bar',
			            data:data.info.barData
			        },
			         {
			            name:'价值分布',
			            type:'pie',
			            tooltip : {
			                trigger: 'item',
			                formatter: '{b} : {c}'
			                //formatter: '{a} <br/>{b} : {c} ({d}%)'
			            },
			            hoverAnimation:false,
			            center: ['75%',70],
			            radius : [0, 40],
			            data:data.info.pieData
			        }
			    ]
			};
			myChart.setOption(option);
		}
	},function(){
		
	},function(){
		plus.nativeUI.closeWaiting();
	});
}

function initLineCharts(){
	ai.ajax("index/group/lineIndexValueById",param,function(data){
		if(data.state){
			var mainDiv = document.getElementById('main-echarts-2');
			myChart = echarts.init(mainDiv);
			var option = {
			    tooltip : {
	                trigger: 'axis',
	                position:['20%',1],
	                formatter: '{b} : {c}'
	                //formatter: '{a} <br/>{b} : {c} ({d}%)'
	            },
	            grid:{top:10,bottom:40,left:40,right:10},
			    backgroundColor:'#0085D0',
	            color:['#78CDE1', '#CBE07B','#FE967D', '#DF7CFA', '#FDE47F'],
			    xAxis:[
			        {
			            type:'category',
			            axisLine:{lineStyle:{color:'#FFF'}},
			            axisTick:{lineStyle:{color:'#FFF'}},
			            axisLabel:{textStyle:{color:'#FFF'}},
		//	            axisLabel:{interval:0,rotate:60,textStyle:{color:'#FFF'}},
					    splitLine:{show:false},
					    data:data.info.xAxisData
			        }
			    ],
			    yAxis:[
			        {
			            type : 'value',
			            axisLine:{lineStyle:{color:'#FFF'}},
			            axisTick:{lineStyle:{color:'#FFF'}},
			            axisLabel:{textStyle:{color:'#FFF'},formatter:function(value, index){
			            	return ai.echartsAxisFormat(value);
			            }},
//			            position: 'left',
			            splitLine:{show:true,lineStyle:{color:'#498FD0'}}
			        }
			    ],
			    series:[
			        {
			            name:'指标趋势',
			            type:'line',
			            data:data.info.barData
			        }
			    ]
			};
			myChart.setOption(option);
		}
	},function(){
		
	},function(){
		plus.nativeUI.closeWaiting();
	});
}

function initDetailItem(){
	if(myChart && !myChart.isDisposed()){
		myChart.dispose();
	}
	ai.ajax("index/group/orgIndexValueById",param,function(data){
		if(data.state){
			var table = document.body.querySelector('#group-index-item>.mui-table-view');
			table.innerHTML = template('group-index-item-template', {rows:data.info});
		}
	},function(){
		
	},function(){
		plus.nativeUI.closeWaiting();
	});
}