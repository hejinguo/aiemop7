mui.init({
	pullRefresh: {
		container: '#pullup-container',
		up: {
			callback: pullupRefresh
		}
	}
});

var param = {pageNo:1,pageSize:10,unitNameCode:'',sortField:'UNIT_NAME',sortType:'ASC'};

mui.plusReady(function(){
	window.addEventListener('showSortPopover',function(event){
		mui('#sort-popover').popover('show');
	});
	
//	初始化搜索框事件
	initSearchBoxEvent();
//	初始化列表排序事件
	initSortItemEvent();
//	初始化加载集团明细记录
	loadUnitDetailItem();
//	初始化集团条目点击事件
	initUnitItemTapEvent();
//	初始化展开收起事件
	initExpandCollapseEvent();
});

//初始化搜索框事件
function initSearchBoxEvent(){
	mui('span.mui-placeholder')[0].addEventListener('tap',function(e){
		mui('.mui-input-clear')[0].focus();
	});
	document.querySelector('form').addEventListener('submit', function(e){
	    e.preventDefault(); // 阻止默认事件
	    var searchInputBox = mui('.mui-input-clear')[0];
	    searchInputBox.blur();
	    param.unitNameCode = searchInputBox.value;
	    mui('#pullup-container').pullRefresh().refresh(true);//重置上拉加载
	    loadUnitDetailItem();
	});
}

//初始化列表排序事件
function initSortItemEvent(){
	mui('.mui-popover>.mui-table-view').on('tap', '.mui-table-view-cell', function(e) {
		mui('.mui-popover .mui-table-view-cell[data-sort-field="'+param.sortField+'"] span')[0].className='';
		var sortField = this.dataset.sortField;
		var sortType = this.dataset.sortType;
		if(param.sortField == sortField){
			param.sortType = (param.sortType == 'DESC' ? 'ASC' : 'DESC');
		}else{
			param.sortField = sortField;
			param.sortType = sortType;
		}
		mui('.mui-popover .mui-table-view-cell[data-sort-field="'+param.sortField+'"] span')[0].className = 
			'mui-icon mui-pull-right '+(param.sortType == 'ASC' ? 'mui-icon-arrowup' : 'mui-icon-arrowdown');
		mui('#pullup-container').pullRefresh().refresh(true);//重置上拉加载
	    loadUnitDetailItem();
	});
}

//加载活动明细记录
function loadUnitDetailItem(){
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	document.body.querySelector('.mui-scroll>.mui-table-view').innerHTML='';
//	mui('#pullup-container').pullRefresh().refresh(true);//重置上拉加载
	param.pageNo = 1;
    pullupRefresh();
    if(mui.os.ios){
		plus.webview.currentWebview().evalJS("mui('#pullup-container').pullRefresh().scrollTo(0,0,100)");
	}else{
		plus.webview.currentWebview().evalJS('mui.scrollTo(0, 100)');
	}
}

function pullupRefresh(){
	setTimeout(function() {
		ai.ajax("market/view/unitDetailByUser",param,function(data){
			if(data.state){
				var table = document.body.querySelector('.mui-scroll>.mui-table-view');
				mui.each(data.info.rows,function(index,item){
					var li = document.createElement('li');
					li.className = 'mui-table-view-cell';
					li.dataset.unitId=item.UNIT_ID;
					li.dataset.unitName=item.UNIT_NAME;
					li.innerHTML = '<div class="mui-row"><div class="mui-col-xs-9"><h4 class="mui-ellipsis"><a>'+item.UNIT_NAME+'</a></h4></div>'+
									'<div class="mui-col-xs-3 mui-text-right"><h5 class="mui-ellipsis">'+item.UNIT_TRADE+'</h5></div></div>'+
									'<div class="mui-row"><div class="mui-col-xs-6"><h5>活动参与量：'+item.MARKET_NUM+'个</h5><h5>成员参与量：'+item.MBR_NUM+'人</h5></div>'+
									'<div class="mui-col-xs-6"><h5>成员渗透率：'+item.PERMEATE_RATE+'%</h5><h5>集团编码：'+item.UNIT_ID+'</h5></div></div>'+
									'<div id="charts-box-'+item.UNIT_ID+'" class="charts-box-hide"><div class="charts-box-head mui-row" id="charts-box-head-'+item.UNIT_ID+'"></div>'+
									'<div class="charts-box-content" id="charts-box-content-'+item.UNIT_ID+'"></div></div>'+
									'<h5 id="charts-button-'+item.UNIT_ID+'" data-unit-id="'+item.UNIT_ID+'" class="mui-text-center"><a>展开<span class="mui-icon mui-icon-arrowdown"></span></a></h5>';
					table.appendChild(li);
				});
				
				mui.toast('共'+data.info.total+'条记录,已加载'+(param.pageNo*param.pageSize > data.info.total ? '完毕':param.pageNo*param.pageSize+'条'));
				if(++param.pageNo > Math.ceil(data.info.total/param.pageSize)){
					mui('#pullup-container').pullRefresh().endPullupToRefresh(true);//加载完毕
				}else{
					mui('#pullup-container').pullRefresh().endPullupToRefresh(false);//还有更多数据
				}
			}
		},function(){
			mui('#pullup-container').pullRefresh().endPullupToRefresh(false);//还有更多数据
		},function(){
			plus.nativeUI.closeWaiting();
		});
	}, 1500);
}

/**
 * 初始化集团条目点击事件
 */
function initUnitItemTapEvent(){
	mui('.mui-scroll>.mui-table-view').on('tap', '.mui-table-view-cell', function(e) {
		ai.openWindow({
			url:"unit-market-list.html",
    		id:"page-unit-market-list",
    		extras:{
    			unitId:this.dataset.unitId,
    			unitName:this.dataset.unitName
    		}
		});
	});
}

/**
 * 初始化展开收起事件
 */
function initExpandCollapseEvent(){
	mui('.mui-scroll>.mui-table-view').on('tap', '.mui-text-center', function(e) {
		var chartsDiv = document.getElementById('charts-box-'+this.dataset.unitId);
		var chartsBtn = document.getElementById('charts-button-'+this.dataset.unitId);
		if(chartsDiv.className == 'charts-box-show'){
			chartsDiv.className='charts-box-hide';
			chartsBtn.innerHTML = '<a>展开<span class="mui-icon mui-icon-arrowdown"></span></a>';
		}else{
			chartsDiv.className = 'charts-box-show'
			chartsBtn.innerHTML = '<a>收起<span class="mui-icon mui-icon-arrowup"></span></a>';
			if(!chartsDiv.dataset.loaded){
				generateUnitChart(this.dataset.unitId);
			}
		}
		e.stopPropagation();//阻止事件冒泡
	});
}

function generateUnitChart(unitId){
	var chartsHeader = document.getElementById('charts-box-head-'+unitId);
	var chartsContent = document.getElementById('charts-box-content-'+unitId);
	
	ai.ajax("market/view/unitPieData",{'unitId':unitId},function(data){
		if(data.state){
			chartsHeader.parentNode.dataset.loaded = true;
			chartsHeader.innerHTML='<div class="mui-col-xs-6 mui-h5 mui-text-center">'+data.info.unitPieTitle+'</div><div class="mui-col-xs-6 mui-h5 mui-text-center">'+data.info.mbrPieTitle+'</div>';
			var myChart = echarts.init(chartsContent);
			var option = {
			    calculable : true,
			    color:['#0ECBEF','#9EDB18', '#02C0F0', '#1CD0F5', '#7EE4FB','#9ED221', '#B2E834'],
			    series : [
			        {
			            name:'集团指标',
			            type:'pie',
			            hoverAnimation:false,
			            radius : [0, 60],
			            center : ['25%',60],
			            data:data.info.unitPie,
			            label: {
			                normal: {
			                    position: (data.info.unitPie.length > 1 ?'inner':'center'),
			                    textStyle:{color:'#FFF'}
			                }
			            }
			        },
			        {
			            name:'参与指标',
			            type:'pie',
			            hoverAnimation:false,
			            radius : [0, 60],
			            center : ['75%',60],
			            data:data.info.mbrPie,
			            label: {
			                normal: {
			                    position: (data.info.mbrPie.length > 1 ?'inner':'center'),
			                    textStyle:{color:'#FFF'}
			                }
			            }
			        }
			    ]
			};
			myChart.setOption(option);
		}
	},function(){
		
	},function(){
		
	});
}