mui.init({
	gestureConfig:{
		doubletap: true
	},
	subpages:[{
		url:'unit-market-list-pull.html',
		id:'page-unit-market-list-pull',
		styles:{
			top: '44px',
			bottom: '0px',
		}
	}]
});

mui.plusReady(function(){
	document.body.querySelector('.mui-title').innerText=plus.webview.currentWebview().unitName;
	
	mui('#sort-popover-button')[0].addEventListener('tap', function(e){
		mui.fire(plus.webview.getWebviewById('page-unit-market-list-pull'),'showSortPopover');
	});
	
	setTimeout(function(){
		mui.fire(plus.webview.getWebviewById('page-unit-market-list-pull'),'initParamUnitId',{unitId:plus.webview.currentWebview().unitId});
	},1500);
	
	var contentWebview = null;
	mui('header')[0].addEventListener('doubletap',function () {
		if(contentWebview==null){
			contentWebview = plus.webview.currentWebview().children()[0];
		}
		contentWebview.evalJS("mui('#pullup-container').pullRefresh().scrollTo(0,0,100)");
	});
});