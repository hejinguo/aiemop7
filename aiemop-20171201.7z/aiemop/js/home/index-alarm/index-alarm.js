mui.init({
	gestureConfig:{
		doubletap: true
	},
	subpages:[{
		url:'index-alarm-pull.html',
		id:'page-index-alarm-pull',
		styles:{
			top: '44px',
			bottom: '0px',
		}
	}]
});

//var alarmType = 3;//默认加载营销预警

mui.plusReady(function(){
	mui("#setting-alarm-index-button")[0].addEventListener('tap', function() {
		ai.openWindow({
			url:'../../setting/alarm-index.html',
    		id:'page-alarm-index'
		});
	});
	
//	初始化点击预警大类别生成Charts
	mui('.mui-segmented-control').on('tap', 'a', function(e) {
		mui.fire(plus.webview.getWebviewById('page-index-alarm-pull'),'clickSegmentedControlItem',{alarmType:this.dataset.alarmType});
	});
	
	var contentWebview = null;
	mui('header')[0].addEventListener('doubletap',function () {
		if(contentWebview==null){
			contentWebview = plus.webview.currentWebview().children()[0];
		}
		contentWebview.evalJS("mui('#pullup-container').pullRefresh().scrollTo(0,0,100)");
	});
});