mui.init({
	pullRefresh: {
		container: '#pullup-container',
		up: {
			callback: pullupRefresh
		}
	}
});

var myChart = null;
var alarmType = 3;//默认加载营销预警
var param = {pageNo:1,pageSize:10,indexId:-1};

mui.plusReady(function(){
	mui('#selected-alarm-item')[0].innerText=mui('#selected-alarm-item')[0].dataset.titleText;

	window.addEventListener('clickSegmentedControlItem',function(event){
		alarmType = event.detail.alarmType;
		mui('.mui-table-view')[0].innerHTML='';
		mui('#selected-alarm-item')[0].innerText=mui('#selected-alarm-item')[0].dataset.titleText;
		if(myChart && !myChart.isDisposed()){
			myChart.dispose();
		}
		loadAlarmCharts();
	});
	
//	初始化点击营销预警活动名称着色功能
	initClickSetAlarmTypeColor();
//	加载当前选择预警类型的Charts
	loadAlarmCharts();
});

//初始化点击营销预警活动名称着色功能
function initClickSetAlarmTypeColor(){
	mui('.mui-table-view').on('tap', 'a', function(e) {
		var li = this.parentNode;
		if(alarmType == 3 && !eval(li.dataset.setAlarmType)){//营销预警着色
			//mui.alert('首次加载预警着色标记');
			ai.ajax('index/alarm/alarmCodeBymktId',{mktId:li.dataset.mktId},function(data){
				if(data.state){
					li.dataset.setAlarmType=true;//已着预警色
					mui.each(data.info,function(index,item){
						var temp = mui("#"+item.INDEX_CODE+"_"+li.dataset.mktId)[0];
						if(temp){
							temp.style.color = 'red';
						}
					});
				}
			});
		}
	});
}

//加载当前选择预警类型的Charts
function loadAlarmCharts(){
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	var url = (alarmType == 3 ? 'index/alarm/marketAlarmCount' : 'index/alarm/unitAlarmCount');
	ai.ajax(url,{},function(data){
		//mui.toast(JSON.stringify(data));
		if(data.state){
			// 基于准备好的dom，初始化echarts实例
		    myChart = echarts.init(document.getElementById('main-echarts'));
		    // 指定图表的配置项和数据
		    var option = {
			    backgroundColor:'#FFFFFF',
			    color:['#F04A39','#F0B701','#18B0EF','#7DCCD9','#FDE47D'],
			   	//animation:false,
			    series: [
			        {
			            name:'营销活动',
			            type:'pie',
			            hoverAnimation:false,
			            radius: ['40%', '65%'],
			            data:data.info
			        }
			    ]
			};
		    // 使用刚指定的配置项和数据显示图表。
		    myChart.setOption(option);
			myChart.on('click',clickAlarmItem);
			mui('#pullup-container').scroll().scrollTo(0,0,100);
//			if(mui.os.ios){
//				plus.webview.currentWebview().evalJS("mui('#pullup-container').pullRefresh().scrollTo(0,0,100)");
//			}else{
//				plus.webview.currentWebview().evalJS('mui.scrollTo(0, 100)');
//			}
		}
	},function(){},function(){
		plus.nativeUI.closeWaiting();
	});
}

//单击预警Charts上的某个扇区
function clickAlarmItem(item){
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	mui('.mui-table-view')[0].innerHTML='';
	mui('#selected-alarm-item')[0].innerText=item.data.name;
	mui('#pullup-container').pullRefresh().refresh(true);//重置上拉加载
	param.indexId = item.data.id;
	param.pageNo=1;
	pullupRefresh();
}

function pullupRefresh(){
	if(param.indexId > 0){
		var url = (alarmType == 3 ? 'index/alarm/marketAlarmDetail' : 'index/alarm/unitAlarmDetail');
		ai.ajax(url,param,function(data){
			if(data.state){
				var table = mui('.mui-table-view')[0];
				mui.each(data.info.rows,function(index,item){
				  	var li = document.createElement('li');
					li.className = 'mui-table-view-cell mui-collapse';
					li.dataset.mktId=item.MKT_ID;
					li.dataset.mktName=item.MKT_NAME;
					li.dataset.setAlarmType=false;//未着预警色
					if(alarmType == 3){
						li.innerHTML = '<a class="mui-navigate-right mui-h4" href="#">'+item.MKT_NAME+'</a><div class="mui-collapse-content">'+
										'<div class="mui-row"><div class="mui-col-xs-6 mui-h5" id="UNIT_NUM_'+item.MKT_ID+'">集团参与量：'+item.UNIT_NUM+'个</div><div class="mui-col-xs-6 mui-h5">成员渗透率：'+item.PERMEATE_RATE+'%</div>'+
										'<div class="mui-col-xs-6 mui-h5" id="MBR_NUM_'+item.MKT_ID+'">成员参与量：'+item.MBR_NUM+'人</div><div class="mui-col-xs-6 mui-h5" id="EXPIRE_DAYS_'+item.MKT_ID+'">到期倒计时：'+item.EXPIRE_DAYS+'天</div><div class="mui-col-xs-6 mui-h5" id="CONSUME_COST_'+item.MKT_ID+'">消耗成本：'+ai.decimalFormat(item.CONSUME_COST,2)+'元</div></div></div>';
					}else{
						li.innerHTML = '<a class="mui-navigate-right mui-h4" href="#">'+item.UNIT_NAME+'</a><div class="mui-collapse-content">'+
										'<div class="mui-row"><div class="mui-col-xs-6 mui-h5">集团编码：'+item.UNIT_ID+'</div><div class="mui-col-xs-6 mui-h5">集团价值：'+item.DYNAMIC_TYPE+'</div>'+
										'<div class="mui-col-xs-6 mui-h5">集团行业：'+item.UNIT_TRADE+'</div><div class="mui-col-xs-6 mui-h5">阈值：'+item.THRESHOLD_VALUE+'</div><div class="mui-col-xs-6 mui-h5" style="color:red;">预警值：'+item.ALARM_VALUE+'</div></div></div>';
					}
					table.appendChild(li);
				});
				
				mui.toast('共'+data.info.total+'条记录,已加载'+(param.pageNo*param.pageSize > data.info.total ? '完毕':param.pageNo*param.pageSize+'条'));
				if(++param.pageNo > Math.ceil(data.info.total/param.pageSize)){
					mui('#pullup-container').pullRefresh().endPullupToRefresh(true);//加载完毕
				}else{
					mui('#pullup-container').pullRefresh().endPullupToRefresh(false);//还有更多数据
				}
			}
		},function(){
			mui('#pullup-container').pullRefresh().endPullupToRefresh(false);//还有更多数据
		},function(){
			plus.nativeUI.closeWaiting();
		});
	}else{
		mui('#pullup-container').pullRefresh().endPullupToRefresh(false);
	}
}