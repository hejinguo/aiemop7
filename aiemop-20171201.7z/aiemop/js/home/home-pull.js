mui.init({
	gestureConfig:{
		hold:true,//按住屏幕
		release:true//离开屏幕
	},
	pullRefresh:{
		container:'#pullup-container',
		up:{
			callback:pullupRefresh
		},
		down:{
//	    	contentdown : "下拉可以刷新",//可选，在下拉可刷新状态时，下拉刷新控件上显示的标题内容
//	    	contentover : "释放立即刷新",//可选，在释放可刷新状态时，下拉刷新控件上显示的标题内容
//	    	contentrefresh : "正在刷新...",//可选，正在刷新状态时，下拉刷新控件上显示的标题内容
	    	callback :pulldownRefresh //必选，刷新函数，根据具体业务来编写，比如通过ajax从服务器获取新数据；
	    }
	}
});

var param = {pageNo:1,pageSize:8};
var selectedViewType = 'market-view-item';//默认展示活动视图
var userBaseInfo = {};
template.helper("_decimalFormat", ai.decimalFormat);
template.helper("_defaultValue", ai.defaultValue);
template.helper('Math', Math);

mui.plusReady(function(){
//	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
//	加载用户关注的大盘指标数据
	loadCoreIndexEcharts();
//	加载营销视图指标数据
	loadMarketViewIndex();
//	加载用户关注的集团指标与值
	loadGroupIndexValue();
//	加载产品视图指标数据
	loadProductViewIndex();
//	初始化营销视图指标Tap事件
	initMarketIndexTapEvent();
//	初始化产品视图指标Tap事件
	initProductIndexTapEvent();
//	初始化集团指标Tap事件
	initGroupIndexTapEvent();
//	初始化功能图标Tap事件
	initCommonIconTapEvent();
//	初始化第二栏营销视图切换事件
	initViewSwitchEvent();
	
	mui('.mui-slider-group').on('release','.echarts-div-box',function(e){
		var myChart = echarts.getInstanceByDom(document.getElementById(this.getAttribute('id')));
	  	myChart.dispatchAction({type:'hideTip'});
	});
});

//初始化第二栏营销视图切换事件
function initViewSwitchEvent(){
	mui('.mui-segmented-control').on('tap', 'a', function(e) {
		//mui.alert(this.innerText+" "+this.dataset.targetView);
		mui('#'+selectedViewType)[0].style.display='none';
		selectedViewType= this.dataset.targetView;
		mui('#'+selectedViewType)[0].style.display='block';
	});
}

//初始化功能图标Tap事件
function initCommonIconTapEvent(){
	document.getElementById("group-index-setting").addEventListener('tap', function() {
		ai.openWindow({
			url:"../setting/group-index.html",
    		id:"page-group-index"
		});
	});
}

//下拉刷新时的处理过程
function pulldownRefresh(){
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	mui('#pullup-container').pullRefresh().refresh(true);//重置上拉加载
	loadCoreIndexEcharts();
	loadMarketViewIndex();
	loadGroupIndexValue();
	loadProductViewIndex();
	mui('#pullup-container').pullRefresh().endPulldownToRefresh();
}

//加载营销视图主指标数据
function loadMarketViewIndex(){
	ai.ajax("market/view/defaultMarketIndex",{},function(data){
		if(data.state && data.info){
			mui('#mkt-market-num')[0].innerText=ai.decimalFormat(data.info.MARKET_NUM,0);
			mui('#mkt-unit-num')[0].innerText=ai.decimalFormat(data.info.UNIT_NUM,0);
			mui('#mkt-mbr-num')[0].innerText=ai.decimalFormat(data.info.MBR_NUM,0);
			mui('#mkt-permeate-rate')[0].innerText=ai.decimalFormat(data.info.PERMEATE_RATE,2);
		}else{
			mui('#mkt-market-num')[0].innerText='-';
			mui('#mkt-unit-num')[0].innerText='-';
			mui('#mkt-mbr-num')[0].innerText='-';
			mui('#mkt-permeate-rate')[0].innerText='-';
//			mui.toast('未获取到您关注的活动数据!');
		}
	},function(){
		
	},function(){
		
	});
}

//加载产品视图指标数据
function loadProductViewIndex(){
	ai.ajax("product/view/productCover",{},function(data){
		if(data.state && data.info){
			mui('#all-cover-num')[0].innerText=ai.decimalFormat(data.info.ALL_COVER_NUM,0);
			mui('#part-cover-num')[0].innerText=ai.decimalFormat(data.info.PART_COVER_NUM,0);
			mui('#un-cover-num')[0].innerText=ai.decimalFormat(data.info.UN_COVER_NUM,0);
		}
	},function(){
		
	},function(){
		
	});
}

//加载用户关注的集团指标与值
function loadGroupIndexValue(){
	//plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	document.body.querySelector('#group-index-item').innerHTML='';
	param.pageNo = 1;
	pullupRefresh();
    if(mui.os.ios){
		plus.webview.currentWebview().evalJS("mui('#pullup-container').pullRefresh().scrollTo(0,0,100)");
	}else{
		plus.webview.currentWebview().evalJS('mui.scrollTo(0, 100)');
	}
}

function pullupRefresh(){
	setTimeout(function() {
		var scolor = ['#18B0EF','#F36468','#82CF34','#F0C301','#18B0EF','#F36468','#82CF34','#F0C301'];
		ai.ajax("/index/group/groupIndexValueByUser",param,function(data){
			if(data.state){
				var table = document.body.querySelector('#group-index-item');
				mui.each(data.info.rows,function(index,item){
					var li = document.createElement('li');
					li.className = "mui-table-view-cell";
					li.dataset.indexId = item.INDEX_ID;
					li.dataset.indexName = item.INDEX_NAME;
					li.style.background=scolor[index];
					var acc = (item.INDEX_VALUE_TYPE == 1 ? 0 : 2);//百分比在服务端已经*100，所以也只需保留2位小数
					li.innerHTML = template('main-group-index-item', {acc:acc,item:item});
					table.appendChild(li);
				});
				//mui.toast('共'+data.info.total+'条记录,已加载'+(param.pageNo*param.pageSize > data.info.total ? '完毕':param.pageNo*param.pageSize+'条'));
				if(++param.pageNo > Math.ceil(data.info.total/param.pageSize)){
					mui('#pullup-container').pullRefresh().endPullupToRefresh(true);//加载完毕
				}else{
					mui('#pullup-container').pullRefresh().endPullupToRefresh(false);//还有更多数据
				}
			}
		},function(){
			mui('#pullup-container').pullRefresh().endPullupToRefresh(false);
		},function(){
			plus.nativeUI.closeWaiting();
		});
	}, 1500);
}

//初始化产品视图指标Tap事件
function initProductIndexTapEvent(){
	mui('#product-view-item').on('tap', '.mui-table-view-cell', function(e) {
		var targetPage = this.dataset.targetPage;
		var orgType = ai.user.organize.orgType;
		if(orgType >= 5){//5:当前层级为客户经理级别
			if("un-cover" == targetPage){//未覆盖
				ai.openWindow({
					url:"product-view/un-cover-st.html",
		    		id:"page-un-cover-st"
				});
			}else{//全覆盖或部分覆盖
				ai.openWindow({
					url:"product-view/all-cover-dw.html",
		    		id:"page-all-cover-dw",
		    		extras:{
		    			rangeType:("part-cover" == targetPage ? 1 : 2)
		    		}
				});
			}
		}else{//管理者
			ai.openWindow({
				url:"product-view/"+targetPage+"-st.html",
	    		id:"page-"+targetPage+"-st"
			});
		}
		//mui.alert(this.dataset.targetPage);
	});
}

//初始化营销视图指标Tap事件
function initMarketIndexTapEvent(){
	mui('#market-view-item').on('tap', '.mui-table-view-cell', function(e) {
		var targetPage = this.dataset.targetPage;
		var orgType = ai.user.organize.orgType;
		if(orgType >= 5){//5:当前层级为客户经理级别
			ai.openWindow({
				url:"market-view/"+targetPage+".html",
	    		id:"page-"+targetPage,
	    		styles:{popGesture:'close'}
			});
		}else{
			var indexId = '';
			var indexName = '';
			if("market-list" == targetPage){
				indexId = '30200001';
				indexName = '活动参与量';
			}else if("unit-list" == targetPage){
				indexId = '30200002';
				indexName = '集团参与量';
			}else if("member-list" == targetPage){
				indexId = '30200003';
				indexName = '成员参与量';
			}else if("permeation-list" == targetPage){
				indexId = '30200004';
				indexName = '成员渗透率';
			}
			ai.openWindow({
				url:"group-index/group-index-st.html",
	    		id:"page-group-index-st",
	    		extras:{
	    			indexId:indexId,
	    			indexName:indexName
	    		}
			});
		}
	});
}

//初始化集团指标Tap事件
function initGroupIndexTapEvent(){
	mui('#group-index-item').on('tap', '.mui-table-view-cell', function(e) {
		var orgType = ai.user.organize.orgType;
		if(orgType >= 5){//5:当前层级为客户经理查看集团级别
			ai.openWindow({
				url:"group-index/group-index-dw.html",
	    		id:"page-group-index-dw",
	    		extras:{
	    			indexId:this.dataset.indexId,
	    			indexName:this.dataset.indexName
	    		}
			});
		}else{
			ai.openWindow({
				url:"group-index/group-index-st.html",
	    		id:"page-group-index-st",
	    		extras:{
	    			indexId:this.dataset.indexId,
	    			indexName:this.dataset.indexName
	    		}
			});
		}
	});
}

//加载用户关注的大盘指标数据
function loadCoreIndexEcharts(){
	ai.ajax('/index/core/getCoreIndexValue',{},function(data){
		if(data.state){
			var sliderGroup = mui('.mui-slider-group')[0];
			var sliderIndicator = mui('.mui-slider-indicator')[0];
			sliderGroup.innerHTML='';
			sliderIndicator.innerHTML='';
			var div = null;
			//额外增加的一个节点(循环轮播：第一个节点是最后一张轮播)
			if(data.info.length > 0){
				var item = data.info[data.info.length-1];
				div = document.createElement('div');
				div.className = 'mui-slider-item mui-slider-item-duplicate';
				div.innerHTML = template('main-echarts-slider-item', {index:'last',item:item});
				sliderGroup.appendChild(div);
				if('DOUBLE-PIE' == item.showType){
					generatePieCharts('main-echarts-last',item.pieData);
				}else{
					generateBarLineCharts('main-echarts-last',item.pieData);
				}
			}
			mui.each(data.info,function(index,item){
				div = document.createElement('div');
				div.className = 'mui-slider-item';
				div.innerHTML = template('main-echarts-slider-item', {index:index,item:item});
				sliderGroup.appendChild(div);
				div = document.createElement('div');
				div.className = index == 0 ? 'mui-indicator mui-active' : 'mui-indicator';
				sliderIndicator.appendChild(div);
				if('DOUBLE-PIE' == item.showType){
					generatePieCharts('main-echarts-'+index,item.pieData);
				}else{
					generateBarLineCharts('main-echarts-'+index,item.pieData);
				}
			});
			if(data.info.length > 0){
				//额外增加的一个节点(循环轮播：最后一个节点是第一张轮播)
				var item = data.info[0];
				div = document.createElement('div');
				div.className = 'mui-slider-item mui-slider-item-duplicate';
				div.innerHTML = template('main-echarts-slider-item', {index:'first',item:item});
				sliderGroup.appendChild(div);
				if('DOUBLE-PIE' == item.showType){
					generatePieCharts('main-echarts-first',item.pieData);
				}else{
					generateBarLineCharts('main-echarts-first',item.pieData);
				}
				//循环轮播节点结束
				mui('.mui-slider').slider().gotoItem(0);
			}else{
				mui.toast('您尚未关注大盘指标,请前往设置中关注.');
			}
		}
	},function(){
		
	},function(){
		
	});
}

function generatePieCharts(divTarget,pieData){
    var myChart = echarts.init(document.getElementById(divTarget));
    var option = {
	    color:['#0ECBEF','#9EDB18', '#02C0F0', '#1CD0F5', '#7EE4FB','#9ED221', '#B2E834'],
//	   	animation:false,
	    series: [
	        {
	            type:'pie',
	            hoverAnimation:false,
	            radius: pieData.length == 1 ? ['0%','65%']:['0%', '45%'],
	            label: {
	                normal: {
	                    position: pieData.length == 1 ? 'outside':'inner',
	                	formatter:"{b}\n{c}"
	                }
	            },
	            data:pieData[0]
	        },
	        {
	            type:'pie',
	            hoverAnimation:false,
	            radius: ['60%', '75%'],
	            label: {
	                normal: {
	                	formatter:"{b}\n{c}"
	                }
	            },
	            data:pieData[1]
	        }
	    ]
	};
    myChart.setOption(option);
}

function generateBarLineCharts(divTarget,pieData){
	var myChart = echarts.init(document.getElementById(divTarget));
	var option = {
    	tooltip:{
	        trigger:'axis',
	        position:['20%',1],
	        axisPointer:{// 坐标轴指示器，坐标轴触发有效
	            type:'line'// 默认为直线，可选为：'line' | 'shadow' | 'cross'
	        }
	    },
	    //grid:{top:10,right:0,left:0,bottom:0},
	    grid:{top:10,bottom:35,left:40},
	    color:['#0ECBEF','#CBE07B','#FE967D', '#DF7CFA', '#78CDE1', '#FDE47F'],
	    xAxis:[
	        {
	            type:'category',
	            axisLine:{lineStyle:{color:'#FFF'}},
	            axisTick:{lineStyle:{color:'#FFF'}},
	            axisLabel:{textStyle:{color:'#FFF'}},
//	            axisLabel:{interval:0,rotate:60,textStyle:{color:'#FFF'}},
			    splitLine:{show:false},
	            data:pieData.xAxis
	        }
	    ],
	    yAxis:[
	        {
	            type:'value',
	            axisLine:{lineStyle:{color:'#FFF'}},
	            axisTick:{lineStyle:{color:'#FFF'}},
	            axisLabel:{textStyle:{color:'#FFF'},formatter:function(value, index){
	            	return ai.echartsAxisFormat(value);
	            }},
	            splitLine:{show:true,lineStyle:{color:'#498FD0'}}
	        },
	        {
	            type:'value',
	            axisLine:{lineStyle:{color:'#FFF'}},
	            axisTick:{lineStyle:{color:'#FFF'}},
	            axisLabel:{textStyle:{color:'#FFF'},formatter:'{value}%'},
	            splitLine:{show:false,lineStyle:{color:'#498FD0'}}
	        }
	    ],
	    series:pieData.series
	};
    myChart.setOption(option);
}