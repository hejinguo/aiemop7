mui.init({
	pullRefresh: {
		container: '#pullup-container',
		up: {
			callback: pullupRefresh
		}
	}
});

var rangeType = 0;
var parentOrgId = null;
var param = {pageNo:1,pageSize:10,orgId:-1,productId2Name:''};
template.helper("_decimalFormat", ai.decimalFormat);

mui.plusReady(function(){
	window.addEventListener('initPageParamId',function(event){
		rangeType = event.detail.rangeType;
		parentOrgId = event.detail.parentOrgId;
		if(parentOrgId){//从上级下钻而来的页面
			/*
			mui('#organize-popover>.mui-scroll-wrapper').scroll();
			mui("#organize-popover").on("tap",".mui-table-view-cell",function(e){
		     	mui.fire(plus.webview.getWebviewById('page-all-cover-dw'),'updateTitleOrganize',{orgName:this.dataset.orgName});
		     	param.orgId = this.dataset.orgId;
				loadCoverProduct();
		    });
			loadOrganizeByParent(parentOrgId);
			*/
			param.orgId = event.detail.orgId;
			loadCoverProduct();
		}else{
			param.orgId = event.detail.orgId;
			loadCoverProduct();
		}
	});
	/*
	window.addEventListener('tapOrganizeName',function(event){
    	if(parentOrgId){
    		mui('#organize-popover>.mui-scroll-wrapper').scroll().scrollTo(0,0,100);
    		mui('#organize-popover').popover('show');
    	}
	});
	*/
	
//	初始化搜索框事件
	initSearchBoxEvent();
    initCoverProductTapEvent();
});

//初始化搜索框事件
function initSearchBoxEvent(){
	mui('span.mui-placeholder')[0].addEventListener('tap',function(e){
		mui('.mui-input-clear')[0].focus();
	});
	document.querySelector('form').addEventListener('submit', function(e){
	    e.preventDefault(); // 阻止默认事件
	    var searchInputBox = mui('.mui-input-clear')[0];
	    searchInputBox.blur();
	    param.productId2Name = searchInputBox.value;
	    mui('#pullup-container').pullRefresh().refresh(true);//重置上拉加载
	    loadCoverProduct();
	});
}

function loadCoverProduct(){
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	document.body.querySelector('#pullup-container .mui-table-view').innerHTML = '';
	param.pageNo = 1;
	pullupRefresh();
	if(mui.os.ios){
		plus.webview.currentWebview().evalJS("mui('#pullup-container').pullRefresh().scrollTo(0,0,100)");
	}else{
		plus.webview.currentWebview().evalJS('mui.scrollTo(0, 100)');
	}
}

function pullupRefresh(){
	setTimeout(function() {
//		param.orgId = -45692;
		ai.ajax('product/view/'+(rangeType==1?"partCoverProduct":"allCoverProduct"),param,function(data){
			if(data.state){
				var table = document.body.querySelector('#pullup-container .mui-table-view');
				mui.each(data.info.rows,function(index,item){
					var li = document.createElement('li');
					li.className = 'mui-table-view-cell';
					li.dataset.productId2 = item.PRODUCT_ID2;
					li.dataset.productId2Name = item.PRODUCT_ID2_NAME;
					li.innerHTML = template('all-cover-item-template', {item:item});
//					li.innerHTML = '<div class="mui-row"><div class="mui-col-xs-9"><h4 class="mui-ellipsis"><a>'+item.PRODUCT_ID2_NAME+'</a></h4></div>'+
//									'<div class="mui-col-xs-3 mui-text-right"><h5 class="mui-ellipsis">'+item.PRODUCT_ID1_NAME+'</h5></div></div>'+
//									'<div class="mui-row"><div class="mui-col-xs-6 mui-h5">集团数量：'+item.ORG_SUB_NUM+'家</div><div class="mui-col-xs-6 mui-h5">覆盖集团：'+item.ORG_COVER_NUM+'家</div></div>'+
//									'<div class="mui-row"><div class="mui-col-xs-6 mui-h5">产品应收：'+ai.decimalFormat(item.RECEIVANLE,2)+'元</div><div class="mui-col-xs-6 mui-h5">产品实收：'+ai.decimalFormat(item.PAID_IN,2)+'元</div></div>'+
//									'<div class="mui-row"><div class="mui-col-xs-6 mui-h5">累计应收：'+ai.decimalFormat(item.ADD_RECE,2)+'元</div><div class="mui-col-xs-6 mui-h5">累计实收：'+ai.decimalFormat(item.ADD_PAID_IN,2)+'元</div></div>';
					table.appendChild(li);
				});
				
				mui.toast('共'+data.info.total+'条记录,已加载'+(param.pageNo*param.pageSize > data.info.total ? '完毕':param.pageNo*param.pageSize+'条'));
				if(++param.pageNo > Math.ceil(data.info.total/param.pageSize)){
					mui('#pullup-container').pullRefresh().endPullupToRefresh(true);//加载完毕
				}else{
					mui('#pullup-container').pullRefresh().endPullupToRefresh(false);//还有更多数据
				}
			}
		},function(){
			mui('#pullup-container').pullRefresh().endPullupToRefresh(false);//还有更多数据
		},function(){
			plus.nativeUI.closeWaiting();
		});
	}, 1500);
}

function initCoverProductTapEvent(){
	mui("#pullup-container .mui-table-view").on("tap",".mui-table-view-cell",function(e){
     	ai.openWindow({
			url:"all-cover-unit-dw.html",
    		id:"page-all-cover-unit-dw",
    		extras:{
    			orgId:param.orgId,
    			productId2:this.dataset.productId2,
    			productId2Name:this.dataset.productId2Name
    		}
		});
    });
}

/*
function loadOrganizeByParent(poId){
	var _url = rangeType==1?"base/organize/getOrganizeByParent":"product/view/organizePValueOrderByOrg";
	var _param = rangeType==1?{parentOrgId:poId}:{orgId:poId};
	ai.ajax(_url,_param,function(data){
		if(data.state){
			var table = mui('#organize-popover ul')[0];
			table.innerHTML='';
			mui.each(data.info,function(index,item){
				var li = document.createElement('li');
				li.className = 'mui-table-view-cell';
				li.dataset.orgId=rangeType==1?item.orgId:item.ORG_ID;
				li.dataset.orgName=rangeType==1?item.orgName:item.ORG_NAME;
				li.innerHTML = rangeType==1?item.orgName:item.ORG_NAME;
				table.appendChild(li);
				if(index == 0){
					mui.fire(plus.webview.getWebviewById('page-all-cover-dw'),'updateTitleOrganize',{orgName:rangeType==1?item.orgName:item.ORG_NAME});
					param.orgId = rangeType==1?item.orgId:item.ORG_ID;
				}
			});
			loadCoverProduct();
		}else{
			plus.nativeUI.closeWaiting();
		}
	},function(){
		
	},function(){
		
	});
}
*/