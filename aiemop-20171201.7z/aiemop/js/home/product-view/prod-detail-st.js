mui.init({
	gestureConfig:{
		hold:true,//按住屏幕
		release:true//离开屏幕
	},
	beforeback:function() {
//		var self = plus.webview.currentWebview();
//		if(self.rangeType == 2){
//			plus.screen.lockOrientation('landscape-primary');
//		}
		return true;
	}
});

var param = {orgId:-1,productId2:-1};

mui.plusReady(function(){
//	plus.screen.lockOrientation('portrait-primary');
	var self = plus.webview.currentWebview();
	param.orgId = self.orgId;
	param.productId2 = self.productId2;
	mui('.mui-title')[0].innerHTML = self.productId2Name;
	
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
//	加载产品收入趋势
	loadIncomeLineCharts();
//	价值产品明细指标数据
	loadProductDetailValue();
//	加载集团产品分布情况
	loadProductProfileValue();
	
	mui('#main-echarts')[0].addEventListener("release",function (e) {
		var myChart = echarts.getInstanceByDom(document.getElementById(this.getAttribute('id')));
	  	myChart.dispatchAction({type:'hideTip'});
	});
});

//加载产品收入趋势
function loadIncomeLineCharts(){
	ai.ajax("product/view/lineValueByProd",param,function(data){
		if(data.state){
			var mainDiv = document.getElementById('main-echarts');
			myChart = echarts.init(mainDiv);
			var option = {
			    tooltip : {
	                trigger: 'axis',
	                position:['20%',1]
	            },
	            grid:{top:10,right:0,left:0,bottom:0},
	            backgroundColor:'#0085D0',
	            color:['#CBE07B','#FE967D', '#DF7CFA', '#78CDE1', '#FDE47F'],
			    xAxis:[
			        {
			            type:'category',
			            axisLabel:{interval:0,rotate:60},
			            splitLine:{show:false},
			            data:data.info.xAxis
			        }
			    ],
			    yAxis:[
			        {
			            type:'value',
			            splitLine:{show:true,lineStyle:{color:'#498FD0'}},
			            position: 'left'
			        }
			    ],
			    series:data.info.series
			};
			myChart.setOption(option);
		}
	},function(){
		plus.nativeUI.closeWaiting();
	},function(){
		
	});
}

//价值产品明细指标数据
function loadProductDetailValue(){
	ai.ajax('product/view/productValueByProd',param,function(data){
		if(data.state && data.info){
			mui('#UNIT_NUM')[0].innerText=data.info.UNIT_NUM;
			mui('#RECEIVANLE')[0].innerText=ai.decimalFormat(data.info.RECEIVANLE,2);
			mui('#PAID_IN')[0].innerText=ai.decimalFormat(data.info.PAID_IN,2);
			mui('#OWE_FEE')[0].innerText=ai.decimalFormat(data.info.OWE_FEE,2);
			mui('#ADD_RECE')[0].innerText=ai.decimalFormat(data.info.ADD_RECE,2);
			mui('#ADD_PAID_IN')[0].innerText=ai.decimalFormat(data.info.ADD_PAID_IN,2);
		}
	},function(){
		plus.nativeUI.closeWaiting();
	},function(){
		
	});
}

//加载集团产品分布情况
function loadProductProfileValue(){
	ai.ajax('product/view/productProfileValueByProd',param,function(data){
		if(data.state){
			mui('#trade-profile-title')[0].innerHTML=data.info.unitPieTitle;
			mui('#dynamic-profile-title')[0].innerHTML=data.info.mbrPieTitle;
			var unitPieTop5 = new Array();
			var tradeTable = mui('#trade-profile-item')[0];
			mui.each(data.info.unitPie,function(index,item){
				var div = document.createElement("div");
				div.className='mui-ellipsis mui-text-center';
				div.innerHTML = item.name+':'+item.value;
				tradeTable.appendChild(div);
				if(unitPieTop5.length < 5){
					unitPieTop5.push(item);
				}
			});
			var dynamicTable = mui('#dynamic-profile-item')[0];
			mui.each(data.info.mbrPie,function(index,item){
				var div = document.createElement("div");
				div.className='mui-ellipsis mui-text-center';
				div.innerHTML = item.name+':'+item.value;
				dynamicTable.appendChild(div);
			});
			
			var myChart = echarts.init(mui('#profile-echarts')[0]);
			var option = {
			    calculable : true,
				color:['#CBE07B','#FE967D', '#DF7CFA', '#78CDE1', '#FDE47F','#0ECBEF'],
				backgroundColor:'#FFFFFF',
			    series : [
			        {
			            name:'集团指标',
			            type:'pie',
			            hoverAnimation:false,
			            radius : [0, 70],
			            center : ['25%',80],
			            //data:data.info.unitPie,
			            data:unitPieTop5,
			            label: {
			                normal: {
			                    position: 'inner',
			                    textStyle:{color:'#FFF'}
			                }
			            }
			        },
			        {
			            name:'参与指标',
			            type:'pie',
			            hoverAnimation:false,
			            radius : [0, 70],
			            center : ['75%',80],
			            data:data.info.mbrPie,
			            label: {
			                normal: {
			                    position: 'inner',
			                    textStyle:{color:'#FFF'}
			                }
			            }
			        }
			    ]
			};
			myChart.setOption(option);
		}
	},function(){
		plus.nativeUI.closeWaiting();
	},function(){
		plus.nativeUI.closeWaiting();
	});
}
