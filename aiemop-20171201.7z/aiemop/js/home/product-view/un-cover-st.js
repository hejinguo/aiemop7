mui.init({
	gestureConfig:{
		doubletap: true
	},
	subpages:[{
		url:'un-cover-st-pull.html',
		id:'page-un-cover-st-pull',
		styles:{
			top: '44px',
			bottom: '0px',
		}
	}]
});

mui.plusReady(function(){
	mui('.mui-title a')[0].innerText=ai.user.organize.orgName;
	
	var contentWebview = null;
	mui('header')[0].addEventListener('doubletap',function () {
		if(contentWebview==null){
			contentWebview = plus.webview.currentWebview().children()[0];
		}
		contentWebview.evalJS("mui('#pullup-container').pullRefresh().scrollTo(0,0,100)");
	});
});