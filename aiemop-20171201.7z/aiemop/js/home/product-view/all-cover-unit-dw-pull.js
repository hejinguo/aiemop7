mui.init({
	pullRefresh: {
		container: '#pullup-container',
		up: {
			callback: pullupRefresh
		}
	}
});

var param = {pageNo:1,pageSize:10,orgId:-1,productId2:-1,unitNameCode:''};

mui.plusReady(function(){
	window.addEventListener('initPageParamId',function(event){
		param.orgId = event.detail.orgId;
		param.productId2 = event.detail.productId2;
	});
	
//	初始化搜索框事件
	initSearchBoxEvent();
	loadProductCoverUnit();
});

//初始化搜索框事件
function initSearchBoxEvent(){
	mui('span.mui-placeholder')[0].addEventListener('tap',function(e){
		mui('.mui-input-clear')[0].focus();
	});
	document.querySelector('form').addEventListener('submit', function(e){
	    e.preventDefault(); // 阻止默认事件
	    var searchInputBox = mui('.mui-input-clear')[0];
	    searchInputBox.blur();
	    param.unitNameCode = searchInputBox.value;
	    mui('#pullup-container').pullRefresh().refresh(true);//重置上拉加载
	    loadProductCoverUnit();
	});
}

function loadProductCoverUnit(){
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	var table = document.body.querySelector('.mui-scroll>.mui-table-view');
	table.innerHTML = '';
	param.pageNo = 1;
	pullupRefresh();
	if(mui.os.ios){
		plus.webview.currentWebview().evalJS("mui('#pullup-container').pullRefresh().scrollTo(0,0,100)");
	}else{
		plus.webview.currentWebview().evalJS('mui.scrollTo(0, 100)');
	}
}

function pullupRefresh(){
	setTimeout(function() {
		ai.ajax('product/view/coverUnitByProduct',param,function(data){
			if(data.state){
				var table = document.body.querySelector('.mui-scroll>.mui-table-view');
				mui.each(data.info.rows,function(index,item){
					var li = document.createElement('li');
					li.className = 'mui-table-view-cell';
					li.dataset.unitId = item.UNIT_ID;
					li.innerHTML = '<div class="mui-row"><div class="mui-col-xs-9"><h4 class="mui-ellipsis">'+item.UNIT_NAME+'</h4></div>'+
									'<div class="mui-col-xs-3 mui-text-right"><h5 class="mui-ellipsis">'+item.UNIT_ID+'</h5></div></div>'+
									'<div class="mui-row"><div class="mui-col-xs-6 mui-h5">产品应收：'+ai.decimalFormat(item.RECEIVANLE,2)+'元</div><div class="mui-col-xs-6 mui-h5">产品实收：'+ai.decimalFormat(item.PAID_IN,2)+'元</div></div>'+
									'<div class="mui-row"><div class="mui-col-xs-6 mui-h5">累计应收：'+ai.decimalFormat(item.ADD_RECE,2)+'元</div><div class="mui-col-xs-6 mui-h5">累计实收：'+ai.decimalFormat(item.ADD_PAID_IN,2)+'元</div></div>';
					table.appendChild(li);
				});
				mui.toast('共'+data.info.total+'条记录,已加载'+(param.pageNo*param.pageSize > data.info.total ? '完毕':param.pageNo*param.pageSize+'条'));
				if(++param.pageNo > Math.ceil(data.info.total/param.pageSize)){
					mui('#pullup-container').pullRefresh().endPullupToRefresh(true);//加载完毕
				}else{
					mui('#pullup-container').pullRefresh().endPullupToRefresh(false);//还有更多数据
				}
			}
		},function(){
			mui('#pullup-container').pullRefresh().endPullupToRefresh(false);//还有更多数据
		},function(){
			plus.nativeUI.closeWaiting();
		});
	}, 1500);
}