mui.init({
	gestureConfig:{
		doubletap: true
	},
	subpages:[{
		url:'all-cover-dw-pull.html',
		id:'page-all-cover-dw-pull',
		styles:{
			top: '44px',
			bottom: '0px',
		}
	}],
	beforeback:function() {
		return true;
	}
});

mui.plusReady(function(){
	var self = plus.webview.currentWebview();
	var rangeType = self.rangeType;
	mui('.mui-title label')[0].innerText = (rangeType==1 ? "部分覆盖产品" : "全覆盖产品");
	var parentOrgId = self.parentOrgId;
	var orgId = 0;
	if(parentOrgId){//从上级下钻而来的页面
		/*
		mui('#organize-popover-button')[0].addEventListener("tap",function(){
			mui.fire(plus.webview.getWebviewById('page-all-cover-dw-pull'),'tapOrganizeName');
		});
		*/
		orgId = self.orgId;
		mui('.mui-title a')[0].innerText=self.orgName;
	}else{
		orgId = ai.user.organize.orgId;
		mui('.mui-title a')[0].innerText=ai.user.organize.orgName;
	}
	setTimeout(function(){
		mui.fire(plus.webview.getWebviewById('page-all-cover-dw-pull'),'initPageParamId',{orgId:orgId,rangeType:rangeType,parentOrgId:parentOrgId});
	},500);
	/*
	window.addEventListener('updateTitleOrganize',function(event){
		mui('.mui-title a')[0].innerText=event.detail.orgName;
	});
	*/
	var contentWebview = null;
	mui('header')[0].addEventListener('doubletap',function () {
		if(contentWebview==null){
			contentWebview = plus.webview.currentWebview().children()[0];
		}
		contentWebview.evalJS("mui('#pullup-container').pullRefresh().scrollTo(0,0,100)");
	});
});