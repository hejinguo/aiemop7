mui.init({
	
});

var selectedDynamicType = 'ALL';

mui.plusReady(function(){
//	初始化点击打开选择价值类别列表事件
	dynamicTypeButtonTapEvent();
//	初始化价值类别变更操作事件
	changeDynamicTypeEvent();
	
	loadDynamicCodeType();
});

function loadDynamicCodeType(){
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	ai.ajax('product/view/dynamicCodeSet',{},function(data){
		if(data.state){
			var table = mui('#dynamic-type-popover ul')[0];
			table.innerHTML='';
			mui.each(data.info,function(index,item){
				var li = document.createElement('li');
				li.className = 'mui-table-view-cell';
				li.dataset.codeKey=item.value;
				li.dataset.codeName=item.name;
				li.innerHTML = item.name;
				table.appendChild(li);
				if(index == 0){
					selectedDynamicType = item.value;
				}
//				console.log(item.value+' : '+item.name);
			});
			loadProductCoverVSData();
		}
	},function(){
		plus.nativeUI.closeWaiting();
	},function(){
		
	});
}

function loadProductCoverVSData(){
	var self = plus.webview.currentWebview();
//	mui.alert(self.dkey1 +' vs '+self.dkey2);
	var param = "orgId="+self.dkey1.split(':')[0]+"&orgId="+self.dkey2.split(':')[0];
	param += "&productId2="+self.dkey1.split(':')[1]+"&productId2="+self.dkey2.split(':')[1];
	param += "&dynamicTypeCode="+Base64.encode(selectedDynamicType);
	ai.ajax('product/view/productCoverVSByOrg',param,function(data){
//		mui.alert(JSON.stringify(data)+'   :');
		if(data.state){
			var table = document.body.querySelector('#cover-st-div');
			table.innerHTML = '';
			var item = data.info;
			item[0] = item[0] ? item[0] : {};
			item[1] = item[1] ? item[1] : {};
			var li = document.createElement('div');
			li.className = 'mui-row';
			li.innerHTML = '<div class="mui-col-xs-6"><h5 class="mui-ellipsis mui-text-left">'+ai.defaultValue(item[0].ORG_NAME,'机构A')+'</h5><h4 class="mui-ellipsis mui-text-center">'+ai.defaultValue(item[0].PRODUCT_ID2_NAME,'产品A')+'</h4></div>'+
							'<div class="mui-col-xs-6"><h5 class="mui-ellipsis mui-text-left">'+ai.defaultValue(item[1].ORG_NAME,'机构B')+'</h5><h4 class="mui-ellipsis mui-text-center">'+ai.defaultValue(item[1].PRODUCT_ID2_NAME,'产品B')+'</h4></div>'+
							'<div class="mui-col-xs-6 mui-h5">客户经理规模：'+ai.decimalFormat(item[0].XZ_SERVICE_NUM,0)+'</div><div class="mui-col-xs-6 mui-h5">客户经理规模：'+ai.decimalFormat(item[1].XZ_SERVICE_NUM,0)+'</div>'+
							'<div class="mui-col-xs-6 mui-h5">集团规模：'+ai.decimalFormat(item[0].XZ_UNIT_NUM,0)+'</div><div class="mui-col-xs-6 mui-h5">集团规模：'+ai.decimalFormat(item[1].XZ_UNIT_NUM,0)+'</div>'+
							'<div class="mui-col-xs-6 mui-h5">成员规模：'+ai.decimalFormat(item[0].XZ_MBR_NUM,0)+'</div><div class="mui-col-xs-6 mui-h5">成员规模：'+ai.decimalFormat(item[1].XZ_MBR_NUM,0)+'</div>'+
							'<div class="mui-col-xs-6 mui-h5">集团总收入：'+ai.decimalFormat(item[0].XZ_UNIT_PAID_IN,2)+'</div><div class="mui-col-xs-6 mui-h5">集团总收入：'+ai.decimalFormat(item[1].XZ_UNIT_PAID_IN,2)+'</div>'+
							'<div class="mui-col-xs-6 mui-h5">产品应收：'+ai.decimalFormat(item[0].RECEIVANLE,2)+'</div><div class="mui-col-xs-6 mui-h5">产品应收：'+ai.decimalFormat(item[1].RECEIVANLE,2)+'</div>'+
							'<div class="mui-col-xs-6 mui-h5">产品实收：'+ai.decimalFormat(item[0].PAID_IN,2)+'</div><div class="mui-col-xs-6 mui-h5">产品实收：'+ai.decimalFormat(item[1].PAID_IN,2)+'</div>'+
							'<div class="mui-col-xs-6 mui-h5">年累计应收：'+ai.decimalFormat(item[0].ADD_RECE,2)+'</div><div class="mui-col-xs-6 mui-h5">年累计应收：'+ai.decimalFormat(item[1].ADD_RECE,2)+'</div>'+
							'<div class="mui-col-xs-6 mui-h5">年累计实收：'+ai.decimalFormat(item[0].ADD_PAID_IN,2)+'</div><div class="mui-col-xs-6 mui-h5">年累计实收：'+ai.decimalFormat(item[1].ADD_PAID_IN,2)+'</div>'+
							'<div class="mui-col-xs-6 mui-h5">全累计实收：'+ai.decimalFormat(item[0].ALL_PAID_IN,2)+'</div><div class="mui-col-xs-6 mui-h5">全累计实收：'+ai.decimalFormat(item[1].ALL_PAID_IN,2)+'</div>';
			table.appendChild(li);
		}
	},function(){
		
	},function(){
		plus.nativeUI.closeWaiting();
	});
}

//初始化点击打开选择价值类别列表事件
function dynamicTypeButtonTapEvent(){
	mui('#dynamic-popover-button')[0].addEventListener("tap",function(){
    	mui('.mui-scroll-wrapper').scroll().scrollTo(0,0,100);
    	mui('#dynamic-type-popover').popover('show');
    });
}

//初始化价值类别变更操作事件
function changeDynamicTypeEvent(){
	mui("#dynamic-type-popover").on("tap",".mui-table-view-cell",function(e){
    	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
    	selectedDynamicType = this.dataset.codeKey;
		loadProductCoverVSData();
    });
}