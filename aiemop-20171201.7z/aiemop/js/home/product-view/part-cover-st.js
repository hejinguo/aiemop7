mui.init({
	gestureConfig:{
		doubletap: true
	},
	subpages:[{
		url:'part-cover-st-pull.html',
		id:'page-part-cover-st-pull',
		styles:{
			top: '44px',
			bottom: '0px'
		}
	}],
	beforeback:function() {
		if(indexLevelLength > 1){
			mui.fire(plus.webview.getWebviewById('page-part-cover-st-pull'),'backIndexLevel');
			return false;
		}else{
			return true;
		}
	}
});

var indexLevelLength = 1;

mui.plusReady(function(){
	mui('.mui-title a')[0].innerText=ai.user.organize.orgName;
// 	初始化点击机构名称打开选择操作列表事件
    organizeNameTapEvent();
//	初始化选择对比或查看产品详情
	initSelectVSTapEvent();
	
	window.addEventListener('updateTitleOrganize',function(event){
		mui('.mui-title a')[0].innerText=event.detail.orgName;
		indexLevelLength = event.detail.indexLevelLength;
	});
	window.addEventListener('selectOrganizeVS',function(event){
		var selectedDomLength = event.detail.selectedDomLength;
		var svb = mui('#select-vs-button')[0];
		if(selectedDomLength == 1){
			svb.classList.remove('mui-hidden');svb.innerHTML='详情';
		}else if(selectedDomLength == 2){
			svb.classList.remove('mui-hidden');svb.innerHTML='对比';
		}else{
			svb.classList.add('mui-hidden');
		}
	});
	
//  直接关闭窗口事件
	mui('#close-page-button')[0].addEventListener('tap',function(e){
		plus.screen.lockOrientation('portrait-primary');
		plus.webview.currentWebview().close();
	});
	
	var contentWebview = null;
	mui('header')[0].addEventListener('doubletap',function () {
		if(contentWebview==null){
			contentWebview = plus.webview.currentWebview().children()[0];
		}
		contentWebview.evalJS("mui('#pullup-container').pullRefresh().scrollTo(0,0,100)");
	});
});

//初始化选择对比或查看产品详情
function initSelectVSTapEvent(){
	mui('#select-vs-button')[0].addEventListener('tap',function(e){
		mui.fire(plus.webview.getWebviewById('page-part-cover-st-pull'),'selectVSTapEvent');
	});
}

//初始化点击机构名称打开选择操作列表事件
function organizeNameTapEvent(){
	mui('#organize-popover-button')[0].addEventListener("tap",function(){
		mui.fire(plus.webview.getWebviewById('page-part-cover-st-pull'),'tapOrganizeName');
	});
}