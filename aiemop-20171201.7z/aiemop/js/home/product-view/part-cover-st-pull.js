mui.init({
	pullRefresh: {
		container: '#pullup-container',
		up: {
			callback: pullupRefresh
		}
	}
});

var param = {pageNo:1,pageSize:10,orgId:-1,productId2:-1,productId2Name:''};
var indexLevel = new Array();
var selectedDomArray = new Array();

mui.plusReady(function(){
//	返回上一层指标数据
	window.addEventListener('backIndexLevel',function(event){
		plus.nativeUI.showWaiting("正在加载数据,请稍等.");
		indexLevel.pop();
		param.orgId = indexLevel[indexLevel.length-1].orgId;
		mui.fire(plus.webview.getWebviewById('page-part-cover-st'),'updateTitleOrganize',{orgName:indexLevel[indexLevel.length-1].orgName,indexLevelLength:indexLevel.length});
		loadOrganizeByParent(param.orgId);
		loadProductCoverRate();
	});
	
	window.addEventListener('selectVSTapEvent',function(event){
		if(selectedDomArray.length == 1){//详情
			var dkeys = selectedDomArray[0].dkey.split(':');
			ai.openWindow({
				url:"prod-detail-st.html",
				id:"page-prod-detail-st",
				extras:{
					orgId:dkeys[0],
					productId2:dkeys[1],
					productId2Name:selectedDomArray[0].dvalue.parentNode.parentNode.dataset.productId2Name,
					rangeType:1//部分覆盖
				},
				styles:{popGesture:'close'}
			});
		}else if(selectedDomArray.length == 2){//对比
			ai.openWindow({
				url:"part-cover-st-vs.html",
	    		id:"page-part-cover-st-vs",
	    		extras:{
	    			dkey1:selectedDomArray[0].dkey,
	    			dkey2:selectedDomArray[1].dkey
	    		},
	    		styles:{popGesture:'close'}
			});
		}else{
			mui.alert('请先选择用于对比的两个条目对象.');
		}
	});
	
	window.addEventListener('tapOrganizeName',function(event){
		mui('#organize-popover .mui-scroll-wrapper').scroll().scrollTo(0,0,100);
		mui('#organize-popover').popover('show');
	});
	
//	初始化搜索框事件
	initSearchBoxEvent();
//	初始化展开收起事件
	initExpandCollapseEvent();
//	初始化选择对比的行政机构条目
	initSelectOrganizeVS();
//	 初始化同等级机构变更操作事件
	changeShowOrganizeEvent();
	
	mui('#organize-popover .mui-scroll-wrapper').scroll();
	indexLevel.push({orgId:ai.user.organize.orgId,orgName:ai.user.organize.orgName,orgType:ai.user.organize.orgType});//默认使用当前机构ID
    param.orgId = indexLevel[indexLevel.length-1].orgId;
//	获取下级机构列表条目
	loadOrganizeByParent(param.orgId);
	loadProductCoverRate();
});

//初始化搜索框事件
function initSearchBoxEvent(){
	mui('span.mui-placeholder')[0].addEventListener('tap',function(e){
		mui('.mui-input-clear')[0].focus();
	});
	document.querySelector('form').addEventListener('submit', function(e){
	    e.preventDefault(); // 阻止默认事件
	    var searchInputBox = mui('.mui-input-clear')[0];
	    searchInputBox.blur();
	    param.productId2Name = searchInputBox.value;
	    loadProductCoverRate();
	});
}

//加载半覆盖集团产品记录
function loadProductCoverRate(){
	selectedDomArray = new Array();
	mui.fire(plus.webview.getWebviewById('page-part-cover-st'),'selectOrganizeVS',{selectedDomLength:selectedDomArray.length});
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	document.body.querySelector('#pullup-container .mui-table-view').innerHTML='';
	mui('#pullup-container').pullRefresh().refresh(true);//重置上拉加载
	param.pageNo = 1;
    pullupRefresh();
    if(mui.os.ios){
		plus.webview.currentWebview().evalJS("mui('#pullup-container').pullRefresh().scrollTo(0,0,100)");
	}else{
		plus.webview.currentWebview().evalJS('mui.scrollTo(0, 100)');
	}
}

function pullupRefresh(){
	setTimeout(function() {
		ai.ajax('product/view/partCoverProductRateByOrg',param,function(data){
			if(data.state){
				var colors = ['#f66369','#f66369','#f66369','#f66369','#f66369','#f66369','#f66369','#f66369','#f66369','#f66369','#f66369','#f66369','#f66369'];
				var table = document.body.querySelector('#pullup-container .mui-table-view');
				mui.each(data.info.rows,function(index,item){
					var li = document.createElement('li');
					li.className = 'mui-table-view-cell';
					li.dataset.productId2 = item.PRODUCT_ID2;
					
					var per = parseInt(item.COVER_RATE*10000)/100.0;
					li.innerHTML = '<div class="mui-row"><div class="mui-col-xs-8"><h4 class="mui-ellipsis">'+item.PRODUCT_ID2_NAME+'</h4></div>'+
									'<div class="mui-col-xs-4 mui-text-right"><h5 class="mui-ellipsis">覆盖率:'+per+'%</h5></div></div>'+
									'<div class="profile-progressbar"><div style="width:'+per+'%;background:'+colors[parseInt(Math.round(per)/10)]+'"></div></div>'+
									'<div class="profile-box-content mui-row mui-hidden" data-product-id2-name="'+item.PRODUCT_ID2_NAME+'" id="profile-box-'+item.PRODUCT_ID2+'"></div>'+
									'<h5 class="mui-text-center" id="profile-button-'+item.PRODUCT_ID2+'" data-product-id2="'+item.PRODUCT_ID2+'"><a>展开<span class="mui-icon mui-icon-arrowdown"></span></a></h5>';
					table.appendChild(li);
				});
			
				mui.toast('共'+data.info.total+'条记录,已加载'+(param.pageNo*param.pageSize > data.info.total ? '完毕':param.pageNo*param.pageSize+'条'));
				if(++param.pageNo > Math.ceil(data.info.total/param.pageSize)){
					mui('#pullup-container').pullRefresh().endPullupToRefresh(true);//加载完毕
				}else{
					mui('#pullup-container').pullRefresh().endPullupToRefresh(false);//还有更多数据
				}
			}
		},function(){
			mui('#pullup-container').pullRefresh().endPullupToRefresh(false);//还有更多数据
		},function(){
			plus.nativeUI.closeWaiting();
		});
	}, 1500);
}


//初始化选择对比的行政机构条目
function initSelectOrganizeVS(){
	mui(".mui-table-view").on("tap",".profile-box-content  .mui-text-center",function(e){//.profile-box-content .mui-col-xs-4 .mui-text-center
//		console.log(this.dataset.orgId+"  "+this.dataset.orgName);
		var cancel_flag = false;//取消选择操作
		var this_dkey = this.dataset.orgId+':'+this.dataset.productId2;
		mui.each(selectedDomArray,function(index,item){
			if(this_dkey == item.dkey){
				selectedDomArray.splice(index,1)[0].dvalue.classList.remove('selected-organize');;
				cancel_flag = true;
			}
		});
		if(!cancel_flag){
			if(selectedDomArray.length == 2){
				selectedDomArray.shift().dvalue.classList.remove('selected-organize');
			}
			selectedDomArray.push({dkey:this_dkey,dvalue:this});
			this.classList.add('selected-organize');
		}
		mui.fire(plus.webview.getWebviewById('page-part-cover-st'),'selectOrganizeVS',{selectedDomLength:selectedDomArray.length});
	});
}

/**
 * 初始化展开收起事件
 */
function initExpandCollapseEvent(){
	mui('#pullup-container .mui-table-view').on('tap', 'h5.mui-text-center', function(e) {
		var profileDiv = document.getElementById('profile-box-'+this.dataset.productId2);
		var profileBtn = document.getElementById('profile-button-'+this.dataset.productId2);
		if(profileDiv.className.indexOf('mui-hidden') > -1){
			profileDiv.classList.remove('mui-hidden');
			profileBtn.innerHTML = '<a>收起<span class="mui-icon mui-icon-arrowup"></span></a>';
			param.productId2 = this.dataset.productId2;
			if(!(profileDiv.querySelectorAll('div.mui-col-xs-4').length > 0)){//已经加载过的数据,不再请求新的数据
				profileDiv.innerHTML = '';
				generateProductCoverData();
			}
		}else{
			profileDiv.classList.add('mui-hidden');
			profileBtn.innerHTML = '<a>展开<span class="mui-icon mui-icon-arrowdown"></span></a>';
		}
		e.stopPropagation();//阻止事件冒泡
	});
}

//生成下级机构覆盖情况记录
function generateProductCoverData(){
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	ai.ajax('product/view/productCoverByOrg',param,function(data){
		if(data.state){
			var table = document.getElementById('profile-box-'+param.productId2);
			mui.each(data.info,function(index,item){
				var div = document.createElement('div');
				div.className = 'mui-col-xs-4';
				div.innerHTML = '<div class="mui-text-center mui-ellipsis range-type-'+item.RANGE_TYPE+'" data-product-id2="'+param.productId2+
				'" data-org-id="'+item.ORG_ID+'" data-org-name="'+item.ORG_NAME+'" data-org-type="'+item.ORG_TYPE+'">'+item.ORG_NAME+'</div>';
				table.appendChild(div);
			});
		}
	},function(){
		
	},function(){
		plus.nativeUI.closeWaiting();
	});
}

//获取下级机构列表条目
function loadOrganizeByParent(poid){
	ai.ajax("base/organize/getOrganizeByParent",{parentOrgId:poid},function(data){
		if(data.state){
			var table = mui('#organize-popover ul')[0];
			table.innerHTML='';
			mui.each(data.info,function(index,item){
				var li = document.createElement('li');
				li.className = 'mui-table-view-cell';
				li.dataset.orgId=item.orgId;
				li.dataset.orgName=item.orgName;
				li.dataset.orgType=item.orgType;
				li.innerHTML = item.orgName;
				table.appendChild(li);
			});
			mui('#organize-popover .mui-scroll-wrapper').scroll().scrollTo(0,0,100);
		}else{
			plus.nativeUI.closeWaiting();
		}
	},function(){
		plus.nativeUI.closeWaiting();
	},function(){
		
	});
}

//初始化同等级机构变更操作事件
function changeShowOrganizeEvent(){
	mui("#organize-popover").on("tap",".mui-table-view-cell",function(e){
		var _this = this;
		if(indexLevel[indexLevel.length-1].orgType >= 4){//4:当前层级为片区查看经理级别
			ai.openWindow({
				url:"all-cover-dw.html",
	    		id:"page-all-cover-dw",
	    		extras:{
	    			rangeType:1,
	    			parentOrgId:indexLevel[indexLevel.length-1].orgId,
	    			orgId:_this.dataset.orgId,
		    		orgName:_this.dataset.orgName
	    		}
			});
		}else{
			indexLevel.push({orgId:_this.dataset.orgId,orgName:_this.dataset.orgName,orgType:_this.dataset.orgType});
			param.orgId = _this.dataset.orgId;
			mui.fire(plus.webview.getWebviewById('page-part-cover-st'),'updateTitleOrganize',{orgName:_this.dataset.orgName,indexLevelLength:indexLevel.length});
			loadOrganizeByParent(param.orgId);
			loadProductCoverRate();
		}
    });
}