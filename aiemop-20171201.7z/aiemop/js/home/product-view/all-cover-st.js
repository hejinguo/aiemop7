mui.init({
	gestureConfig:{
		hold:true,//按住屏幕
		release:true//离开屏幕
	},
	beforeback:function() {
		if(indexLevel.length > 1){
//			返回上一层指标数据
			plus.nativeUI.showWaiting("正在加载数据,请稍等.");
			indexLevel.pop();
			param.orgId = indexLevel[indexLevel.length-1].orgId;
			mui('.mui-title a')[0].innerText=indexLevel[indexLevel.length-1].orgName;
			loadProductValueChart();
			return false;
		}else{
			return true;
		}
	}
});

var myChart = null;
var param = {productId1:-1,orgId:-1};
var chartType = "stack-bar-chart";//默认显示产品大类柱状图
var indexLevel = new Array();
template.helper("_decimalFormat", ai.decimalFormat);

mui.plusReady(function(){
	mui('.mui-title a')[0].innerText=ai.user.organize.orgName;
//	 初始化变更页面数据展示方式
    changeShowTypeEvent();
//  初始化点击全覆盖产品明细条目事件
	initTapProductDetailItem();
    
/*
//	初始化双击页面的下钻操作
    doubleNextLevelEvent();
//  初始化点击机构名称打开选择操作列表事件
    organizeNameTapEvent();
// 	初始化同等级机构变更操作事件
	changeShowOrganizeEvent();
	mui('#organize-popover>.mui-scroll-wrapper').scroll();
*/

	indexLevel.push({orgId:ai.user.organize.orgId,orgName:ai.user.organize.orgName,orgType:ai.user.organize.orgType});//默认使用当前机构ID
    param.orgId = indexLevel[indexLevel.length-1].orgId;
    plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	loadProductValueChart();
//  直接关闭窗口事件
	mui('#close-page-button')[0].addEventListener('tap',function(e){
		plus.screen.lockOrientation('portrait-primary');
		plus.webview.currentWebview().close();
	});
	
	mui('.mui-slider-group').on('release','.echarts-div-box',function(e){
		var myChart = echarts.getInstanceByDom(document.getElementById(this.getAttribute('id')));
	  	myChart.dispatchAction({type:'hideTip'});
	});
});

//初始化页面数据展示方式事件
function changeShowTypeEvent(){
	mui("#more-popover").on("tap",".mui-table-view-cell",function(e){
    	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
		chartType = this.dataset.itemType;
		loadProductValueChart();
    });
}

//立即刷新当前层级Charts
function loadProductValueChart(){
	if(chartType == "stack-bar-chart"){
		setTimeout('initStackBarCharts()',1500);
		setTimeout('initIncomeLineCharts()',1500);
//	}else if(chartType == "income-line-chart"){
//		setTimeout('initIncomeLineCharts()',1500);
	}else if(chartType == "product-bar-chart"){
		setTimeout('initProductBarChart()',1500);
		setTimeout('initIncomeLineCharts()',1500);
	}
}

/*
//初始化点击机构名称打开选择操作列表事件
function organizeNameTapEvent(){
	mui('#organize-popover-button')[0].addEventListener("tap",function(){
    	if(indexLevel[indexLevel.length-1].orgId != ai.user.organize.orgId){
    		mui('.mui-scroll-wrapper').scroll().scrollTo(0,0,100);
    		mui('#organize-popover').popover('show');
    	}
    });
}

//初始化同等级机构变更操作事件
function changeShowOrganizeEvent(){
	mui("#organize-popover").on("tap",".mui-table-view-cell",function(e){
    	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
     	indexLevel[indexLevel.length-1].orgId = this.dataset.orgId;
     	indexLevel[indexLevel.length-1].orgName = this.dataset.orgName;
     	param.orgId = indexLevel[indexLevel.length-1].orgId;
		mui('.mui-title a')[0].innerText=indexLevel[indexLevel.length-1].orgName;
		loadProductValueChart();
    });
}

//初始化双击页面的下钻操作
function doubleNextLevelEvent(){
	mui('#main-echarts')[0].addEventListener("doubletap",function(){
	    if(indexLevel[indexLevel.length-1].orgType >= 4){//4:当前层级为片区查看经理级别
			ai.openWindow({
				url:"all-cover-dw.html",
	    		id:"page-all-cover-dw",
	    		extras:{
	    			rangeType:2,
	    			parentOrgId:indexLevel[indexLevel.length-1].orgId
	    		}
			});
			plus.nativeUI.closeWaiting();
		}else{
			loadOrganizeAndProduct(1);
		}
	});
}

//加载机构列表和集团产品数据Charts
function loadOrganizeAndProduct(levelType){
	var poid = -1;
	if(levelType > 0){
		poid = indexLevel[indexLevel.length-1].orgId;
	}else if(levelType < 0 && indexLevel.length-3 >=0){
		poid = indexLevel[indexLevel.length-3].orgId;
	}
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
//	ai.ajax("base/organize/getOrganizeByParent",{parentOrgId:poid},function(data){
	ai.ajax("product/view/organizePValueOrderByOrg",{orgId:poid},function(data){
		if(data.state){
			var table = mui('#organize-popover ul')[0];
			table.innerHTML='';
			mui.each(data.info,function(index,item){
				var li = document.createElement('li');
				li.className = 'mui-table-view-cell';
				li.dataset.orgId=item.ORG_ID;
				li.dataset.orgName=item.ORG_NAME;
				li.innerHTML = item.ORG_NAME;
				table.appendChild(li);
				if(index == 0 && levelType > 0){
					indexLevel.push({orgId:item.ORG_ID,orgName:item.ORG_NAME,orgType:item.ORG_TYPE});
					param.orgId = item.ORG_ID;
					mui('.mui-title a')[0].innerText=item.ORG_NAME;
				}
			});
			if(levelType < 0){
				indexLevel.pop();
				param.orgId = indexLevel[indexLevel.length-1].orgId;
				mui('.mui-title a')[0].innerText=indexLevel[indexLevel.length-1].orgName;
			}
			loadProductValueChart();
		}else{
			plus.nativeUI.closeWaiting();
		}
	},function(){
		plus.nativeUI.closeWaiting();
	},function(){
		
	});
}
*/

function initStackBarCharts(){
	ai.ajax('product/view/productValueByOrg',param,function(data){
		if(data.state){
			var table = document.body.querySelector('#all-cover-item>.mui-table-view');
			table.innerHTML = template('all-cover-big-template', data);
//			console.log(JSON.stringify(data)+"");
			var mainDiv = document.getElementById('main-echarts-1');;
			myChart = echarts.init(mainDiv);
			option = {
			    tooltip : {
			        trigger: 'axis',
			        position:['20%',1],
			        axisPointer : {            // 坐标轴指示器，坐标轴触发有效
			            type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
			        }
			    },
			    calculable : true,
			    grid:{top:10,bottom:40,left:40,right:10},
			    backgroundColor:'#0085D0',
			    color:['#CBE07B','#FE967D', '#DF7CFA', '#78CDE1', '#FDE47F'],
			    xAxis:[
			        {
			            type : 'category',
			            axisLine:{lineStyle:{color:'#FFF'}},
			            axisTick:{lineStyle:{color:'#FFF'}},
			            axisLabel:{textStyle:{color:'#FFF'}},
		//	            axisLabel:{interval:0,rotate:60,textStyle:{color:'#FFF'}},
					    splitLine:{show:false},
			            data : data.info.xAxis
			        }
			    ],
			    yAxis:[
			        {
			            type:'value',
			            axisLine:{lineStyle:{color:'#FFF'}},
			            axisTick:{lineStyle:{color:'#FFF'}},
			            axisLabel:{textStyle:{color:'#FFF'},formatter:function(value, index){
			            	return ai.echartsAxisFormat(value);
			            }},
//			            position: 'left',
			            splitLine:{show:true,lineStyle:{color:'#498FD0'}}
			        }
			    ],
			    series:data.info.series
			};
			myChart.setOption(option);
		}
	},function(){
		
	},function(){
		plus.nativeUI.closeWaiting();
	});
}

function initIncomeLineCharts(){
	ai.ajax("product/view/productValueLineByOrg",param,function(data){
		if(data.state){
//			var table = document.body.querySelector('#all-cover-item>.mui-table-view');
//			table.innerHTML = '';
			var mainDiv = document.getElementById('main-echarts-2');
			myChart = echarts.init(mainDiv);
			var option = {
			    tooltip : {
	                trigger: 'axis',
	                position:['20%',1]
	            },
	            grid:{top:10,bottom:40,left:40,right:10},
			    backgroundColor:'#0085D0',
	            color:['#CBE07B','#FE967D', '#DF7CFA', '#78CDE1', '#FDE47F'],
			    xAxis:[
			        {
			            type:'category',
			            axisLine:{lineStyle:{color:'#FFF'}},
			            axisTick:{lineStyle:{color:'#FFF'}},
			            axisLabel:{textStyle:{color:'#FFF'}},
		//	            axisLabel:{interval:0,rotate:60,textStyle:{color:'#FFF'}},
					    splitLine:{show:false},
			            data:data.info.xAxis
			        }
			    ],
			    yAxis:[
			        {
			            type:'value',
			            axisLine:{lineStyle:{color:'#FFF'}},
			            axisTick:{lineStyle:{color:'#FFF'}},
			            axisLabel:{textStyle:{color:'#FFF'},formatter:function(value, index){
			            	return ai.echartsAxisFormat(value);
			            }},
//			            position: 'left',
			            splitLine:{show:true,lineStyle:{color:'#498FD0'}}
			        }
			    ],
			    series:data.info.series
//			    [
//			        {
//			            name:'指标趋势',
//			            type:'line',
//			            data:data.info.barData
//			        }
//			    ]
			};
			myChart.setOption(option);
		}
	},function(){
		
	},function(){
		plus.nativeUI.closeWaiting();
	});
}

function initProductBarChart(){
	param.productId1=1;
	ai.ajax("product/view/productItemValueByType",param,function(data){
		if(data.state){
			var table = document.body.querySelector('#all-cover-item>.mui-table-view');
			table.innerHTML = template('all-cover-small-template', data);
			var mainDiv = document.getElementById('main-echarts-1');
			myChart = echarts.init(mainDiv);
			option = {
			    tooltip : {
			        trigger: 'axis',
			        position:['20%',1],
			        formatter: '{b} : {c}',
			        axisPointer : {            // 坐标轴指示器，坐标轴触发有效
			            type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
			        }
			    },
			    calculable : true,
			    grid:{top:10,bottom:40,left:40,right:10},
			    backgroundColor:'#0085D0',
			    color:['#78CDE1', '#FDE47F','#CBE07B','#FE967D', '#DF7CFA'],
			    xAxis:[
			        {
			            type : 'category',
			            axisLine:{lineStyle:{color:'#FFF'}},
			            axisTick:{lineStyle:{color:'#FFF'}},
			            axisLabel:{textStyle:{color:'#FFF'}},
		//	            axisLabel:{interval:0,rotate:60,textStyle:{color:'#FFF'}},
					    splitLine:{show:false},
			            data : data.info.xAxisData
			        }
			    ],
			    yAxis:[
			        {
			            type:'value',
			            axisLine:{lineStyle:{color:'#FFF'}},
			            axisTick:{lineStyle:{color:'#FFF'}},
			            axisLabel:{textStyle:{color:'#FFF'},formatter:function(value, index){
			            	return ai.echartsAxisFormat(value);
			            }},
//			            position: 'left',
			            splitLine:{show:true,lineStyle:{color:'#498FD0'}}
			        }
			    ],
			    series:{
		            name:'产品分布',
		            type:'bar',
		            data:data.info.itemData
		        }
			};
			myChart.setOption(option);
		}
		
	},function(){
		
	},function(){
		plus.nativeUI.closeWaiting();
	});
}

//初始化点击全覆盖产品明细条目事件
function initTapProductDetailItem(){
	mui("#all-cover-item").on("tap",".mui-table-view-cell",function(e){
		var _this = this;
		if(chartType == "product-bar-chart"){
	    	ai.openWindow({
				url:"prod-detail-st.html",
				id:"page-prod-detail-st",
				extras:{
					orgId:param.orgId,
					productId2:_this.dataset.productId2,
					productId2Name:_this.dataset.productId2Name,
					rangeType:2//全覆盖
				}
			});
		}else if(chartType == "stack-bar-chart"){
			if(indexLevel[indexLevel.length-1].orgType >= 4){//4:当前层级为片区查看经理级别
				ai.openWindow({
					url:"all-cover-dw.html",
		    		id:"page-all-cover-dw",
		    		extras:{
		    			rangeType:2,
		    			parentOrgId:indexLevel[indexLevel.length-1].orgId,
		    			orgId:_this.dataset.orgId,
		    			orgName:_this.dataset.orgName
		    		}
				});
			}else{
				plus.nativeUI.showWaiting("正在加载数据,请稍等.");
				indexLevel.push({orgId:_this.dataset.orgId,orgName:_this.dataset.orgName,orgType:_this.dataset.orgType});
				param.orgId = _this.dataset.orgId;
				mui('.mui-title a')[0].innerText=_this.dataset.orgName;
				loadProductValueChart();
			}
		}
    });
}