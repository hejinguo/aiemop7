mui.init({
	pullRefresh: {
		container: '#pullup-container',
		up: {
			callback: pullupRefresh
		}
	}
});

var param = {pageNo:1,pageSize:10,productId2Name:''};

mui.plusReady(function(){
//	初始化搜索框事件
	initSearchBoxEvent();
	loadUnCoverProduct();
});

//初始化搜索框事件
function initSearchBoxEvent(){
	mui('span.mui-placeholder')[0].addEventListener('tap',function(e){
		mui('.mui-input-clear')[0].focus();
	});
	document.querySelector('form').addEventListener('submit', function(e){
	    e.preventDefault(); // 阻止默认事件
	    var searchInputBox = mui('.mui-input-clear')[0];
	    searchInputBox.blur();
	    param.productId2Name = searchInputBox.value;
	    mui('#pullup-container').pullRefresh().refresh(true);//重置上拉加载
	    loadUnCoverProduct();
	});
}

function loadUnCoverProduct(){
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	document.body.querySelector('.mui-scroll>.mui-table-view').innerHTML = '';
	param.pageNo = 1;
	pullupRefresh();
	if(mui.os.ios){
		plus.webview.currentWebview().evalJS("mui('#pullup-container').pullRefresh().scrollTo(0,0,100)");
	}else{
		plus.webview.currentWebview().evalJS('mui.scrollTo(0, 100)');
	}
}

function pullupRefresh(){
	setTimeout(function() {
		ai.ajax('product/view/unCoverProduct',param,function(data){
			if(data.state){
				var table = document.body.querySelector('.mui-scroll>.mui-table-view');
				mui.each(data.info.rows,function(index,item){
					var li = document.createElement('li');
					li.className = 'mui-table-view-cell';
					li.dataset.productId2 = item.PRODUCT_ID2;
					li.innerHTML = '<div class="mui-row"><div class="mui-col-xs-9"><h4 class="mui-ellipsis">'+item.PRODUCT_ID2_NAME+'</h4></div>'+
									'<div class="mui-col-xs-3 mui-text-right"><h5 class="mui-ellipsis">'+item.PRODUCT_ID1_NAME+'</h5></div></div>'+
									'<div class="mui-row"><div class="mui-col-xs-6 mui-h5">年累计实收：'+ai.decimalFormat(item.ADD_PAID_IN,2)+'元</div><div class="mui-col-xs-6 mui-h5">全累计实收：'+ai.decimalFormat(item.ALL_PAID_IN,2)+'元</div>'+
									'<div class="mui-col-xs-12 mui-h5">最新账期：'+item.LAST_TIME+'</div>'+
									'<div class="mui-col-xs-12 mui-h5">产品描述：'+item.PRODUCT_CONTENT+'</div></div>';
					table.appendChild(li);
				});
				mui.toast('共'+data.info.total+'条记录,已加载'+(param.pageNo*param.pageSize > data.info.total ? '完毕':param.pageNo*param.pageSize+'条'));
				if(++param.pageNo > Math.ceil(data.info.total/param.pageSize)){
					mui('#pullup-container').pullRefresh().endPullupToRefresh(true);//加载完毕
				}else{
					mui('#pullup-container').pullRefresh().endPullupToRefresh(false);//还有更多数据
				}
			}
		},function(){
			mui('#pullup-container').pullRefresh().endPullupToRefresh(false);//还有更多数据
		},function(){
			plus.nativeUI.closeWaiting();
		});
	}, 1500);
}