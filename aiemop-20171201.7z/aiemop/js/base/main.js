mui.init({
	beforeback:function(){
		return false;
	}
})

var subpages = [{id:'page-home',url:'../home/home-pull.html',flag:true,loaded:false},
				{id:'page-spread',url:'../spread/spread.html',flag:false,loaded:false},
				{id:'page-cust',url:'../cust/cust-manage.html',flag:true,loaded:false},
				//{id:'page-kpi',url:'../kpi/kpi-result-st-pull.html',flag:true,loaded:false},
				{id:'page-me',url:'../me/me.html',flag:true,loaded:false}];
var activeTab = subpages[0].id;//当前激活选项,默认第一个页面webview选项

mui.plusReady(function() {
	plus.webview.close(plus.webview.getLaunchWebview());
	plus.webview.close("page-login");
	
//	加载当前用户未读的最新重要公告消息
	loadTopBulletinByUser();
//	加载当前用户未读的通知消息数量更新提醒标记
	loadUnReadNoticeAmountByUser();
//	初始化页面选项卡和Tap事件
//	initPageTabTapEvent();
	initPageTabTapEvent_20170718();
//	初始化Header中图标Tap事件
	initHeaderIconTapEvent();
	
	window.addEventListener('changeNoticeAmount',function(event){
		if(event.detail.amount < 1){
			mui("#showmessage-button .circle-box")[0].classList.add('mui-hidden');
		}else{
			mui("#showmessage-button .circle-box")[0].classList.remove('mui-hidden');
		}
	});
});

//加载当前用户未读的最新重要公告消息
function loadTopBulletinByUser(){
	ai.ajax('base/notice/getTopBulletinByUser',{},function(data){
		if(data.state && data.info){
			var noticew=plus.webview.create("bulletin.html","page_bulletin.html",
			{width:'260px',height:'330px',margin:"auto",background:"rgba(0,0,0,0.6)",scrollIndicator:'none',scalable:false,popGesture:'none'},
			{noticeId:data.info.NOTICE_ID,noticeTitle:data.info.NOTICE_TITLE,noticeContent:data.info.NOTICE_CONTENT});
			noticew.addEventListener("loaded",function(){
				noticew.show('fade-in',300);
			},false);
		}
	},function(){
		
	},function(){
		
	});
}

//加载当前用户未读的通知消息数量更新提醒标记
function loadUnReadNoticeAmountByUser(){
	ai.ajax('base/notice/countUnReadNoticeByUser',{},function(data){
		if(data.state){
			if(data.info < 1){
				mui("#showmessage-button .circle-box")[0].classList.add('mui-hidden');
			}else{
				mui("#showmessage-button .circle-box")[0].classList.remove('mui-hidden');
			}
		}
	},function(){
		
	},function(){
		
	});
}

//初始化页面选项卡和Tap事件
function initPageTabTapEvent(){
	mui('.mui-title')[0].innerHTML = mui('.mui-bar-tab .mui-active')[0].innerText;
	var main = plus.webview.currentWebview();
	var subpage_style = {
		bottom: '51px'
	};
	if(ai.user.organize.orgType == 5){//客户经理
		subpages[1].flag = true;//只有客户经理才能使用业务推广功能
	}
//	创建子页面，首个选项卡页面显示，其它均隐藏；
	for (var i = 0; i < subpages.length; i++) {
		if(subpages[i].flag){
			if(subpages[i].id == 'page-me'){
				subpage_style.top='0px';
			}else{
				subpage_style.top=44+'px';
			}
			var sub = plus.webview.create(subpages[i].url, subpages[i].id, subpage_style);
			if (i > 0) {
				sub.hide();
			}
			main.append(sub);
		}
	}
//	选项卡点击事件
	mui('.mui-bar-tab').on('tap', 'a', function(e) {
		var targetTab = this.getAttribute('id');
		if (targetTab == activeTab) {
			return;
		}
		mui('.mui-title')[0].innerHTML = this.innerText;
		//显示目标选项卡
		plus.webview.show(targetTab);
		//隐藏当前;
		plus.webview.hide(activeTab);
		//更改当前活跃的选项卡
		activeTab = targetTab;
	});
}

//初始化Header中图标Tap事件
function initHeaderIconTapEvent(){
	if(ai.user.organize.orgType == 5){//客户经理
		mui('#index-alarm-button')[0].classList.remove('mui-hidden');
	}
	//打开消息页面
	document.getElementById("showmessage-button").addEventListener('tap', function() {
		ai.openWindow({
			url:'../me/notice.html',
    		id:'page-notice'
		});
	});
	//打开预警页面
	document.getElementById("index-alarm-button").addEventListener('tap', function() {
		ai.openWindow({
			url:"../home/index-alarm/index-alarm.html",
    		id:"page-index-alarm"
		});
	});
}


//初始化页面选项卡和Tap事件
function initPageTabTapEvent_20170718(){
	mui('.mui-title')[0].innerHTML = mui('#'+activeTab)[0].innerText;
	var main = plus.webview.currentWebview();
	var subpage_style = {
		bottom:'51px',
		top:'44px'
	};
//	创建默认开启的选项
	for (var i = 0; i < subpages.length; i++) {
		if(subpages[i].id == activeTab){
			main.append(plus.webview.create(subpages[i].url, subpages[i].id, subpage_style));
			subpages[i].loaded = true;
		}
		if(ai.user.organize.orgType == 5 && !subpages[i].flag){//5:客户经理
			subpages[i].flag = true;//只有客户经理才能使用业务推广功能
		}
	}
//	选项卡点击事件
	mui('.mui-bar-tab').on('tap', 'a', function(e) {
		var targetTab = this.getAttribute('id');
		if (targetTab == activeTab) {
			return;
		}
		mui('.mui-title')[0].innerHTML = this.innerText;
		//显示目标选项卡
		for (var i = 0; i < subpages.length; i++) {
			if(subpages[i].id == targetTab){
				if(subpages[i].loaded && subpages[i].flag){
					plus.webview.show(targetTab);//显示目标选项卡
				}else if(subpages[i].flag){
					if(subpages[i].id == 'page-me'){
						subpage_style.top='0px';
					}else{
						subpage_style.top='44px';
					}
					main.append(plus.webview.create(subpages[i].url, subpages[i].id, subpage_style));
					subpages[i].loaded = true;
				}
				plus.webview.hide(activeTab);//隐藏当前选项卡
				activeTab = targetTab;//更改当前活跃的选项卡
			}
		}
	});
}