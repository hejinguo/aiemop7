mui.init({
    statusBarBackground:'#3497E1'//0085d0
});

var deviceInfo = {};
var mainPage = null;
var sendMarkWait = 60;
var sh;
var inputErrorTime;//已经失败登陆或获取验证码的次数
var waitInputTime;//截至可尝试登陆或获取验证码的时间
var authCache = {authStep:-1,authPhone:''};//默认先账号密码验证

mui.plusReady(function(){
	//记住上次登录过的用户名称
	mui('#login-code-input')[0].value = ai.user ? ai.user.a4Code : '';
	//初始化获取验证码按钮Tap事件逻辑
	initMarkButtonTapEvent();
	//初始化登陆按钮Tap事件逻辑
	initLoginButtonTapEvent();
	//加载设备及运行环境信息
	loadDeviceBaseInfo();
	
	inputErrorTime = plus.storage.getItem('INPUT_ERROR_TIME');
	if(!inputErrorTime){
		inputErrorTime = 0;
	}
	waitInputTime = plus.storage.getItem('WAIT_INPUT_TIME');
	if(!waitInputTime){
		waitInputTime= 0;
	}
	
	initTestPicker();
});

//累计登陆过程错误计数信息
function addedInputErrorTime(errorMsg){
	inputErrorTime++;
	if(inputErrorTime >= 5){
		inputErrorTime = 0;//保证10分钟后再次重新累计
		waitInputTime = (new Date().getTime()+(1000*60*10));
		plus.storage.setItem('WAIT_INPUT_TIME',waitInputTime+"");//10分钟
		plus.storage.setItem('INPUT_ERROR_TIME',inputErrorTime+"");
		mui.alert('登陆尝试达到上限,已将您的终端禁止使用10分钟.');
	}else{
		plus.storage.setItem('INPUT_ERROR_TIME',inputErrorTime+"");
		mui.alert(errorMsg+',您已尝试'+inputErrorTime+'次登陆操作,累计达到5次将禁止使用10分钟.');
	}
}

//初始化获取验证码按钮Tap事件逻辑
function initMarkButtonTapEvent(){
	mui('#mark-button')[0].addEventListener('tap',function(e){
		if(waitInputTime > new Date().getTime()){
			var t = new Date();
			t.setTime(waitInputTime);
			mui.alert('登陆尝试达到上限,您的终端已被禁止使用10分钟,'+t.getHours()+':'+t.getMinutes()+':'+t.getSeconds()+'后解禁.');
			return false;
		}
		authCache.authStep = -1;
		mui.trigger(mui('#login-button')[0],'tap');
	});
}

//等待短信发送过程
function waitSendMark(){
	if(sendMarkWait <= 0){
		clearInterval(sh);
		sendMarkWait=60;
		mui('#mark-button')[0].innerHTML = '获取';
		mui('#mark-button')[0].removeAttribute('disabled','disabled');
	}else{
		mui('#mark-button')[0].innerHTML = (sendMarkWait--)+'秒';
	}
}

//初始化登陆按钮Tap事件逻辑
function initLoginButtonTapEvent(){
	mui('#login-button')[0].addEventListener('tap',function(e){
		if(waitInputTime > new Date().getTime()){
			var t = new Date();
			t.setTime(waitInputTime);
			mui.alert('登陆尝试达到上限,您的终端已被禁止使用10分钟,'+t.getHours()+':'+t.getMinutes()+':'+t.getSeconds()+'后解禁.');
			return false;
		}
		
		var loginCodeValue = mui('#login-code-input')[0].value;
		var loginPasswordValue = mui('#login-password-input')[0].value;
		var loginMarkValue = mui('#login-mark-input')[0].value;
		if(authCache.authStep == -1 && loginCodeValue && loginPasswordValue ){//账号密码验证
			plus.nativeUI.showWaiting("正在加载数据,请稍等.");
			var param = {staffCode:loginCodeValue,password:Base64.encode(loginPasswordValue),authStep:authCache.authStep,appVersion:ai.appLocalVersion,deviceInfo:Base64.encode(JSON.stringify(deviceInfo))};
			ai.ajax('base/inteLogin',param,function(data){
				if(data.state){
					//还有多种用户的情况，data.info 返回合法數組
					if(data.info.staffCode){
						authCache.authStep = -1;
						mui('#login-mark-input-box')[0].classList.add('mui-hidden');
						plus.storage.setItem('USER-BASE-INFO',Base64.encode(JSON.stringify(data.info)));
						mui('#login-mark-input')[0].value = '';//验证码已失效
						inputErrorTime = 0;//保证再次重新累计
						plus.storage.setItem('INPUT_ERROR_TIME',inputErrorTime+"");
						mainPage = mui.preload({
				  			url: 'main.html',
							id: 'page-main'
						});
						mainPage.show();
					}else{
						authCache.authStep = 1;
						authCache.authPhone = data.info;
						mui('#login-mark-input-box')[0].classList.remove('mui-hidden');
						mui.alert('验证码已发送至 '+data.info +'');
						mui('#mark-button')[0].setAttribute('disabled','disabled');
						sh=setInterval(waitSendMark,1000);
					}
				}else if('USERCODE_OR_PASSWORD_ERROR' == data.code){
					addedInputErrorTime('用户名或密码不正确');
				}else if('LOGIN_MARK_ERROR' == data.code){
					addedInputErrorTime('验证码不正确');
				}else if('USER_NOT_FOUND_ERROR' == data.code){
					addedInputErrorTime('未找到从账号用户信息');
				}else if('4A_ACCT_REL_ERROR' == data.code){
					addedInputErrorTime('未找到4A主从账号信息');
				}else if('APP_VERSION_ERROR' == data.code){
					applicationVersionMismatch();
				}else{
					mui.alert(data.code);
				}
			},function(){
				
			},function(){
				plus.nativeUI.closeWaiting();
			});
		}else if(authCache.authStep == 1 && loginCodeValue && loginPasswordValue && loginMarkValue){//短信验证码鉴权
			plus.nativeUI.showWaiting("正在加载数据,请稍等.");
			var param = {staffCode:loginCodeValue,phoneNo:authCache.authPhone,loginMark:loginMarkValue,authStep:authCache.authStep,appVersion:ai.appLocalVersion,deviceInfo:Base64.encode(JSON.stringify(deviceInfo))};
			ai.ajax('base/inteLogin',param,function(data){
				if(data.state){
					authCache.authStep = -1;
					mui('#login-mark-input-box')[0].classList.add('mui-hidden');
					plus.storage.setItem('USER-BASE-INFO',Base64.encode(JSON.stringify(data.info)));
					mui('#login-mark-input')[0].value = '';//验证码已失效
					inputErrorTime = 0;//保证再次重新累计
					plus.storage.setItem('INPUT_ERROR_TIME',inputErrorTime+"");
					mainPage = mui.preload({
			  			url: 'main.html',
						id: 'page-main'
					});
					mainPage.show();
				}else if('USERCODE_OR_PASSWORD_ERROR' == data.code){
					addedInputErrorTime('用户名或密码不正确');
				}else if('LOGIN_MARK_ERROR' == data.code){
					addedInputErrorTime('验证码不正确');
				}else if('USER_NOT_FOUND_ERROR' == data.code){
					addedInputErrorTime('未找到从账号用户信息');
				}else if('4A_ACCT_REL_ERROR' == data.code){
					addedInputErrorTime('未找到4A主从账号信息');
				}else if('APP_VERSION_ERROR' == data.code){
					applicationVersionMismatch();
				}else{
					mui.alert(data.code);
				}
			},function(){
				
			},function(){
				plus.nativeUI.closeWaiting();
			});
		}else{
			mui.toast('请完整填写登陆信息后继续');
		}
	});
}

//APP本地版本与服务器端最新版本不匹配
function applicationVersionMismatch(){
	if(mui.os.android){
		mui.confirm('您的APP版本过低,是否立即升级至最新版?', '提示', ['否', '是'], function(e) {
			if(e.index == 1){
				var dtask = plus.downloader.createDownload(ai.appPathObject.download,{},function (d,status){
				    if (status == 200) { // 下载成功
				    	var path = d.filename;
				    	plus.runtime.install(path);// 安装下载的apk文件
				    }else{//下载失败
				    	mui.alert( "下载安装包文件失败:"+status);
				    }
				    plus.nativeUI.closeWaiting();
				});
				dtask.start();
				plus.nativeUI.showWaiting("正在下载最新安装包,请稍等.");
			}
		});
	}else{
		mui.alert('您的APP版本过低,请联系开发人员为您更新至最新版.');
	}
}

//加载设备及运行环境信息
function loadDeviceBaseInfo(){
	var networktypes = {};
	networktypes[plus.networkinfo.CONNECTION_UNKNOW] = "网络连接状态未知";
	networktypes[plus.networkinfo.CONNECTION_NONE] = "未连接网络";
	networktypes[plus.networkinfo.CONNECTION_ETHERNET] = "有线网络";
	networktypes[plus.networkinfo.CONNECTION_WIFI] = "无线WIFI网络";
	networktypes[plus.networkinfo.CONNECTION_CELL2G] = "蜂窝移动2G网络";
	networktypes[plus.networkinfo.CONNECTION_CELL3G] = "蜂窝移动3G网络";
	networktypes[plus.networkinfo.CONNECTION_CELL4G] = "蜂窝移动4G网络";

	deviceInfo = {
		appVersion:ai.appLocalVersion,
		deviceImei:plus.device.imei,
		deviceModel:plus.device.model,
		deviceVendor:plus.device.vendor,
		deviceUuid:plus.device.uuid,
		networkInfo:networktypes[plus.networkinfo.getCurrentType()],
		osLanguage:plus.os.language,
		osVersion:plus.os.version,
		osName:plus.os.name,
		osVendor:plus.os.vendor,
		launchLoadedTime:plus.runtime.launchLoadedTime
	};
}


function initTestPicker(){
	
	var userPicker = new mui.PopPicker();
	userPicker.setData([{
		value: 'ywj',
		text: '董事长 叶文洁'
	}, {
		value: 'aaa',
		text: '总经理 艾AA'
	}, {
		value: 'lj',
		text: '罗辑'
	}, {
		value: 'ymt',
		text: '云天明'
	}, {
		value: 'shq',
		text: '史强'
	}, {
		value: 'zhbh',
		text: '章北海'
	}, {
		value: 'zhy',
		text: '庄颜'
	}, {
		value: 'gyf',
		text: '关一帆'
	}, {
		value: 'zhz',
		text: '智子'
	}, {
		value: 'gezh', 
		text: '歌者'
	}]);
	var showUserPickerButton = document.getElementById('showUserPicker');
	showUserPickerButton.addEventListener('tap', function(event) {
		userPicker.show(function(items) {
			mui.toast(JSON.stringify(items[0]));
			//返回 false 可以阻止选择框的关闭
			//return false;
		});
	}, false);
}
