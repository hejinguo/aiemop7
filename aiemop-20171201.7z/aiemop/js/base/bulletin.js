mui.init({
	
});

mui.plusReady(function(){
	var self = plus.webview.currentWebview();
//	mui.alert(self.noticeId+' '+self.noticeTitle+' '+self.noticeContent);
	mui('#notice_content')[0].innerHTML = self.noticeContent;
	mui('#read-bulletin-button')[0].addEventListener('tap',function(e){
		ai.ajax('base/notice/saveReadedNotice',{noticeId:self.noticeId},function(data){
			if(data.state){
				plus.webview.currentWebview().close();
			}
		},function(){
			
		},function(){
			
		});
	});
});