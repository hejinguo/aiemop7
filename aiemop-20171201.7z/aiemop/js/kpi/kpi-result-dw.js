mui.init({
	gestureConfig:{
		doubletap:true
	},
	beforeback:function() {
		mui.fire(plus.webview.getWebviewById('page-kpi-result-dw-pull'),'validKpiLevel',{});
		return false;
	},
	subpages:[{
		id:'page-kpi-result-dw-pull',
		url:'kpi-result-dw-pull.html',
		styles:{
			top: '44px',
			bottom: '0px', 
		}
	}]
});

mui.plusReady(function(){
	var self = plus.webview.currentWebview();
	mui(".mui-title")[0].innerHTML=self.kpiName;
	setTimeout(function(){
		mui.fire(plus.webview.getWebviewById('page-kpi-result-dw-pull'),'initParamKpiId',{
			kpiId:self.kpiId,
			opTime:self.opTime,
			targetValue:self.targetValue,
			resultValue:self.resultValue,
    		completeProgress:self.completeProgress,
    		warnFlag:self.warnFlag,
    		orgId:self.orgId,
    		orgName:self.orgName,
    		orgType:self.orgType
		});
		
	},500);
	
	var contentWebview = null;
	document.querySelector('header').addEventListener('doubletap',function () {
		if(contentWebview==null){
			contentWebview = self.children()[0];
		}
		contentWebview.evalJS("mui('#pullrefresh').pullRefresh().scrollTo(0,0,100)");
	});
	//  直接关闭窗口事件
    mui('#close-page-button')[0].addEventListener('tap',function(e){
		self.close();
	});
});
