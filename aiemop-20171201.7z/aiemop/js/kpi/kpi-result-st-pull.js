mui.init({
	gestureConfig:{
		hold:true,//按住屏幕
		release:true//离开屏幕
	},
	pullRefresh: {
		container: '#pullup-container',
		down: {
			callback: pulldownRefresh
		},
		up: {
			callback: pullupRefresh
		}
	}
});

//var firstLoad = true;//防止在登陆成功时就提示加载信息
var scolor = ['#F85363','#FEAA09','#1ED3B0','#5DC6F5'];
var param = {completeFlag:0,pageNo:1,pageSize:10};
var moduleOrgInfo = {};//緩存当前用户的KPI模块机构信息

mui.plusReady(function(){
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	setTimeout(function() {
		mui('#pullup-container').pullRefresh().pullupLoading();
	}, 500);
	
	initItemTapEvent();
	loadKpiResultTopObject();
	
	mui('.mui-slider-group').on('release','.echarts-div-box',function(e){
		var myChart = echarts.getInstanceByDom(document.getElementById(this.getAttribute('id')));
	  	myChart.dispatchAction({type:'hideTip'});
	});
});

/**
 * 加载页面顶部的基础进度信息
 */
function loadKpiResultTopObject(){
	ai.ajax("/kpi/result/getKpiDateInfo",{},function(data){
		if(data.state){
			moduleOrgInfo = data.info.organizeInfo;
			mui("#kpi-result-op-time")[0].innerHTML= "更新日期:"+data.info.kpiDateInfo.LATEST_PERIOD;
//			var shiDays = ai.numberFormat((data.info.kpiDateInfo.ALL_DAYS-data.info.kpiDateInfo.YU_DAYS)/data.info.kpiDateInfo.ALL_DAYS,2)*100;
//			var shiDays = ai.numberFormat(data.info.kpiDateInfo.YU_DAYS/data.info.kpiDateInfo.ALL_DAYS,2)*100;
			var shiDays = parseInt(ai.numberFormat(data.info.kpiDateInfo.YU_DAYS/data.info.kpiDateInfo.ALL_DAYS*100));
			mui("#kpi-result-yu-day")[0].innerHTML= "剩余"+data.info.kpiDateInfo.YU_DAYS+"天("+shiDays+"%)";
			loadTopMainEcharts(data.info.allKpiBubble);
			loadTopAllotEcharts(data.info.allKpiAllot);
		}
	});
}

/**
 * 初始化页面选项卡和下钻Tap事件
 */
function initItemTapEvent(){
	mui("#complete-state-control").on('tap', '.mui-control-item', function() {
		param.completeFlag = this.dataset.completeFlag;
		pulldownRefresh();
	});
	
	mui(".mui-table-view").on('tap', '.mui-table-view-cell', function() {
		ai.openWindow({
			id:'page-kpi-result-dw',
			url:'kpi-result-dw.html',
			extras:{
    			kpiId:this.dataset.kpiId,
    			kpiName:this.dataset.kpiName,
    			opTime:this.dataset.opTime,
    			targetValue:this.dataset.targetValue,
    			resultValue:this.dataset.resultValue,
    			completeProgress:this.dataset.completeProgress,
    			warnFlag:this.dataset.warnFlag,
    			orgId:moduleOrgInfo.orgId,
    			orgName:moduleOrgInfo.orgName,
    			orgType:moduleOrgInfo.orgType
    		}
		});
	});
}

/**
 * 下拉刷新具体业务实现
 */
function pulldownRefresh() {
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	loadKpiResultTopObject();
	setTimeout(function() {
		mui('#pullup-container').pullRefresh().refresh(true);//重置上拉加载
		document.body.querySelector('.mui-table-view').innerHTML='';
		param.pageNo = 1;
		pullupRefresh();
	    if(mui.os.ios){
			plus.webview.currentWebview().evalJS("mui('#pullup-container').pullRefresh().scrollTo(0,0,100)");
		}else{
			plus.webview.currentWebview().evalJS('mui.scrollTo(0, 100)');
		}
		mui('#pullup-container').pullRefresh().endPulldownToRefresh(); //refresh completed
	}, 1500);
}

/**
 * 上拉加载具体业务实现
 */
function pullupRefresh() {
	setTimeout(function() {
		ai.ajax("/kpi/result/getKpiResultByOrg",param,function(data){
			if(data.state){
				var table = document.body.querySelector('.mui-table-view');
				mui.each(data.info.rows,function(index,item){
					var li = document.createElement('li');
					li.className = "mui-table-view-cell";
					li.dataset.kpiId = item.KPI_ID;
					li.dataset.kpiName = item.KPI_NAME;
					li.dataset.opTime = item.OP_TIME;
					li.dataset.targetValue = item.TARGET_VALUE;
					li.dataset.resultValue = item.RESULT_VALUE;
					li.dataset.completeProgress = item.COMPLETE_PROGRESS;
					li.dataset.warnFlag = item.WARN_FLAG;
					var per = parseInt(item.COMPLETE_PROGRESS*10000)/100;
					per = per > 100 ? 100 : per;
					li.innerHTML = '<h4 class="mui-ellipsis">'+item.KPI_NAME+'</h4>'+
									'<table style="width:100%;"><tr><td class="complete-result-value" style="width:'+per+'%;" nowrap="nowrap"><h5 style="color:'+scolor[item.WARN_FLAG-1]+'">'+
										ai.numberFormat(item.RESULT_VALUE)+'</h5></td><td class="complete-target-value" style="width:'+(100-per)+'%" nowrap="nowrap"><h5>'+ai.numberFormat(item.TARGET_VALUE)+'</h5></td></tr></table>'+
									'<div class="profile-progressbar">'+
									'<div style="width:'+per+'%;background:'+scolor[item.WARN_FLAG-1]+'"></div>'+
									'</div>';
					table.appendChild(li);
				});
//				if(!firstLoad){//预防登陆后在首页就显示此页面的加载提醒
//					mui.toast('共'+data.info.total+'条记录,已加载'+(param.pageNo*param.pageSize > data.info.total ? '完毕':param.pageNo*param.pageSize+'条'));
//				}else{
//					firstLoad = false;
//				}
				if(++param.pageNo > Math.ceil(data.info.total/param.pageSize)){
					mui('#pullup-container').pullRefresh().endPullupToRefresh(true);//加载完毕
				}else{
					mui('#pullup-container').pullRefresh().endPullupToRefresh(false);//还有更多数据
				}
			}
		},function(){
			mui('#pullup-container').pullRefresh().endPullupToRefresh(false);
		},function(){
			plus.nativeUI.closeWaiting();
		});
	}, 1500);
}

function loadTopMainEcharts(kpiBubble){
	var mainDiv = document.getElementById('main-echarts');
	var myChart = echarts.init(mainDiv);
	var option = {
		grid: {
			top:5,left:10,right:10,bottom:25
		},
	    tooltip: {
	        trigger: 'item',
	        position: ['20%','1px'],
			formatter :function(params){
				return params.data[4];
			}
	    },
		color:['#F85363','#FEAA09','#1ED3B0','#5DC6F5'],
		xAxis: {
	        type : 'value',
	        axisLine: {show: false},
	        axisLabel: {show: false},
	        axisTick: {show: false},
	        splitLine: {show: false}
	    },
	    yAxis: {
	        type : 'value',
	        axisLine: {show: false},
	        axisLabel: {show: false},
	        axisTick: {show: false},
	        splitLine: {show: false}
	    },
	    series : [
	        {
	            type:'scatter',
	            symbolSize: function (value){
	                return Math.round(value[2] * 2);
	            },
	            data: kpiBubble.laggingBubble
	        },
	        {
	            type:'scatter',
	            symbolSize: function (value){
	                return Math.round(value[2] * 2);
	            },
	            data: kpiBubble.delayBubble
	        },
	        {
	            type:'scatter',
	            symbolSize: function (value){
	                return Math.round(value[2] * 2);
	            },
	            data: kpiBubble.normalBubble
	        },
	        {
	            type:'scatter',
	            symbolSize: function (value){
	                return Math.round(value[2] * 2);
	            },
	            data: kpiBubble.completeBubble
	        }
	    ]
	};
	myChart.setOption(option);
}

function loadTopAllotEcharts(allKpiAllot){
	var allotDiv = document.getElementById('allot-echarts');
	var myChart = echarts.init(allotDiv);
	mui.each(allKpiAllot.series,function(i,n){
		n.barMinHeight=2;//最小高度
	});
	var option = {
	    tooltip:{
	        trigger:'axis',
	        position:['20%',1],
	        axisPointer:{// 坐标轴指示器，坐标轴触发有效
	            type:'line'// 默认为直线，可选为：'line' | 'shadow' | 'cross'
	        }
	    },
	    grid:{top:10,bottom:18,left:40,right:10},
	    color:['#0ECBEF','#FE967D'],
	    xAxis : [
	        {
	            type : 'category',
	            axisLine:{lineStyle:{color:'#FFF'}},
	            axisTick:{show:false,lineStyle:{color:'#FFF'}},
	            axisLabel:{show:false,textStyle:{color:'#FFF'}},
			    splitLine:{show:false},
	            data : allKpiAllot.xAxis
	        }
	    ],
	    yAxis : [
	        {
	            type : 'value',
	            axisLine:{lineStyle:{color:'#FFF'}},
	            axisTick:{lineStyle:{color:'#FFF'}},
	            axisLabel:{textStyle:{color:'#FFF'},formatter:function(value, index){
	            	return ai.echartsAxisFormat(value);
	            }},
	            splitLine:{show:true,lineStyle:{color:'#5940A5'}}
	        }
	    ],
	    series : allKpiAllot.series
	};
	myChart.setOption(option);
}
