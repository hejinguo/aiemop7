mui.init({
	pullRefresh: {
		container: '#pullup-container',
		down: {
			callback: pulldownRefresh
		},
		up: {
			contentrefresh: '正在加载...',
			callback: pullupRefresh
		}
	}
});

var scolor = ['#F85363','#FEAA09','#1ED3B0','#5DC6F5'];
var param = {kpiId:-1,opTime:'',parentId:0,pageNo:1,pageSize:10};
var kpiLevel = new Array();

mui.plusReady(function(){
//	初始化由主窗口触发的函数
	initParamKpiId();
//	自定义验证返回层级的函数
	validKpiLevel();
//	初始化页面Tap事件
	initItemTapEvent();
});

//初始化由主窗口触发的函数
function initParamKpiId(){
	window.addEventListener('initParamKpiId',function(event){
//		kpiLevel.push({orgId:ai.user.organize.orgId,orgName:ai.user.organize.orgName,orgType:ai.user.organize.orgType,
//			targetValue:event.detail.targetValue,resultValue:event.detail.resultValue,completeProgress:event.detail.completeProgress,warnFlag:event.detail.warnFlag});//默认使用当前机构ID
		kpiLevel.push({orgId:event.detail.orgId,orgName:event.detail.orgName,orgType:event.detail.orgType,
			targetValue:event.detail.targetValue,resultValue:event.detail.resultValue,completeProgress:event.detail.completeProgress,warnFlag:event.detail.warnFlag});//默认使用当前机构ID
    	param.parentId = kpiLevel[kpiLevel.length-1].orgId;
		param.kpiId = event.detail.kpiId;
		param.opTime = event.detail.opTime;
		plus.nativeUI.showWaiting("正在加载数据,请稍等.");
		mui('#pullup-container').pullRefresh().pullupLoading();
		//pullupRefresh();
	});
}

//自定义验证返回层级的函数
function validKpiLevel(){
	window.addEventListener('validKpiLevel',function(event){
		if(kpiLevel.length > 1){
			kpiLevel.pop();
			param.parentId = kpiLevel[kpiLevel.length-1].orgId;
			pulldownRefresh();
		}else{
			plus.webview.currentWebview().parent().close();
		}
	});
}

/**
 * 初始化页面下钻Tap事件
 */
function initItemTapEvent(){
	mui(".mui-table-view").on('tap', '.mui-table-view-cell', function() {
		var orgType = this.dataset.orgType;
		if(orgType <= 5){
			kpiLevel.push({orgId:this.dataset.orgId,orgName:this.dataset.orgName,orgType:this.dataset.orgType,
				targetValue:this.dataset.targetValue,resultValue:this.dataset.resultValue,completeProgress:this.dataset.completeProgress,warnFlag:this.dataset.warnFlag});
			param.parentId = kpiLevel[kpiLevel.length-1].orgId;
			pulldownRefresh();
		}else{
			//mui.toast('已无可供查看的下级数据.');
		}
	});
}

/**
 * 下拉刷新具体业务实现
 */
function pulldownRefresh() {
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	setTimeout(function() {
		mui('#pullup-container').pullRefresh().refresh(true);//重置上拉加载
		document.body.querySelector('.mui-table-view').innerHTML='';
		param.pageNo = 1;
		pullupRefresh();
	    if(mui.os.ios){
			plus.webview.currentWebview().evalJS("mui('#pullup-container').pullRefresh().scrollTo(0,0,100)");
		}else{
			plus.webview.currentWebview().evalJS('mui.scrollTo(0, 100)');
		}
		mui('#pullup-container').pullRefresh().endPulldownToRefresh(); //refresh completed
	}, 1500);
}

/**
 * 上拉加载具体业务实现
 */
function pullupRefresh() {
	setTimeout(function() {
		var currentOrgKpi = kpiLevel[kpiLevel.length-1];
		var orgType = currentOrgKpi.orgType;
		var requestAddr = orgType > 4 ? "/kpi/result/getKpiResultByManager" : "/kpi/result/getKpiResultByParent";
		param.managerOrgId = currentOrgKpi.orgId;
		ai.ajax(requestAddr,param,function(data){
			if(data.state){
				loadTopEcharts();//加载顶部Echarts等信息
				var table = document.body.querySelector('.mui-table-view');
				mui.each(data.info.rows,function(index,item){
					var li = document.createElement('li');
					li.className = "mui-table-view-cell";
					if(orgType > 4){
						li.dataset.unitId = item.UNIT_ID;
						li.innerHTML = '<h4 class="mui-ellipsis">'+item.UNIT_NAME+'</h4>'+
										'<div class="mui-row">'+
										'<div class="mui-col-xs-12 mui-ellipsis mui-h5">已经完成：'+ai.numberFormat(item.RESULT_VALUE)+'</div>'+
										'<div class="mui-col-xs-12 mui-ellipsis mui-h5">集团编码：'+item.UNIT_ID+'</div>'+
										'<div class="mui-col-xs-12 mui-ellipsis mui-h5">集团等级：'+item.DYNAMIC_TYPE+'</div>'+
										'<div class="mui-col-xs-12 mui-ellipsis mui-h5">集团行业：'+item.UNIT_TRADE+'</div>'+
										'</div>';
					}else{
						li.dataset.orgId = item.ORG_ID;
						li.dataset.orgName = item.ORG_NAME;
						li.dataset.orgType = item.ORG_TYPE;
						li.dataset.targetValue = item.TARGET_VALUE;
						li.dataset.resultValue = item.RESULT_VALUE;
						li.dataset.completeProgress = item.COMPLETE_PROGRESS;
						li.dataset.warnFlag = item.WARN_FLAG;
						var per = parseInt(item.COMPLETE_PROGRESS*10000)/100;
						per = per > 100 ? 100 : per;
						li.innerHTML = '<h4 class="mui-ellipsis">'+item.ORG_NAME+'</h4>'+
										'<table style="width:100%;"><tr><td class="complete-result-value" style="width:'+per+'%;" nowrap="nowrap"><h5 style="color:'+scolor[item.WARN_FLAG-1]+'">'+
											ai.numberFormat(item.RESULT_VALUE)+'</h5></td><td class="complete-target-value" style="width:'+(100-per)+'%" nowrap="nowrap"><h5>'+ai.numberFormat(item.TARGET_VALUE)+'</h5></td></tr></table>'+
										'<div class="profile-progressbar">'+
										'<div style="width:'+per+'%;background:'+scolor[item.WARN_FLAG-1]+'"></div>'+
										'</div>';
					}
					table.appendChild(li);
				});
				mui.toast('共'+data.info.total+'条记录,已加载'+(param.pageNo*param.pageSize > data.info.total ? '完毕':param.pageNo*param.pageSize+'条'));
				if(++param.pageNo > Math.ceil(data.info.total/param.pageSize)){
					mui('#pullup-container').pullRefresh().endPullupToRefresh(true);//加载完毕
				}else{
					mui('#pullup-container').pullRefresh().endPullupToRefresh(false);//还有更多数据
				}
			}
		},function(){
			mui('#pullup-container').pullRefresh().endPullupToRefresh(false);
		},function(){
			plus.nativeUI.closeWaiting();
		});
	}, 1500);
}

function loadTopEcharts(){
	var currentOrgKpi = kpiLevel[kpiLevel.length-1];
	mui('#org-kpi-target-box')[0].innerHTML=currentOrgKpi.orgName+"_目标:"+ai.numberFormat(currentOrgKpi.targetValue);
	var per = parseInt(currentOrgKpi.completeProgress*10000)/100;
	per = per > 100 ? 100 : per;//避免大于100%时在饼图上的显示问题
//	console.log(currentOrgKpi.warnFlag);
	var mainDiv = document.getElementById('main-echarts');
	var myChart = echarts.init(mainDiv);
	var option = {
		color:[scolor[currentOrgKpi.warnFlag-1], '#F0F0F0'],
	    series : [
	        {
	            name:'',
	            type:'pie',
	            hoverAnimation:false,
	            radius : ['85%', '90%'],
                label : {
	                normal :{
	                    show : true,
	                 	position : 'center',
	                 	textStyle :{
	                 		fontSize :12
	                 	}
                	}
                },
	            data:[
	                {value:(per-0), name:(ai.numberFormat(currentOrgKpi.resultValue)+'\n已完成')},
	              	{value:(100-per), name:''}
	            ]
	        }
	    ]
	};
	myChart.setOption(option);
}