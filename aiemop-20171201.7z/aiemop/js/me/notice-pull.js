mui.init({
	pullRefresh: {
		container: '#pullup-container',
		up: {
			callback: pullupRefresh
		}
	}
});

var param = {pageNo:1,pageSize:10};

mui.plusReady(function(){
//	加载消息记录
	loadNotice();
//	初始化点击消息条目响应事件
	initNoticeTapEvent();
});

//初始化点击消息条目响应事件
function initNoticeTapEvent(){
	mui('.mui-table-view').on('tap', '.mui-table-view-cell', function(e) {
		if(this.dataset.readFlag == 0){
			this.dataset.readFlag = 1;
			this.classList.remove('unread-notice-item');
			mui.fire(plus.webview.getWebviewById('page-notice'),'readedNotice',{noticeId:this.dataset.noticeId});
		}
	});
}

//加载消息记录
function loadNotice(){
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	document.body.querySelector('.mui-scroll>.mui-table-view').innerHTML='';
//	mui('#pullup-container').pullRefresh().refresh(true);//重置上拉加载
	param.pageNo = 1;
    pullupRefresh();
    if(mui.os.ios){
		plus.webview.currentWebview().evalJS("mui('#pullup-container').pullRefresh().scrollTo(0,0,100)");
	}else{
		plus.webview.currentWebview().evalJS('mui.scrollTo(0, 100)');
	}
}

function pullupRefresh() {
	setTimeout(function() {
		ai.ajax('base/notice/noticeByUser',param,function(data){
			var table = mui('.mui-scroll>.mui-table-view')[0];
			if(data.state){
				mui.each(data.info.rows,function(index,item){
					var li = document.createElement("li");
					li.dataset.noticeId = item.NOTICE_ID;
					li.dataset.readFlag = item.READ_FLAG;
					li.className = 'mui-table-view-cell';
					if(li.dataset.readFlag == 0){
						li.classList.add('unread-notice-item');
					}
					li.innerHTML = '<div class="mui-row"><div class="mui-col-xs-12 mui-ellipsis mui-h4">'+item.NOTICE_TITLE+'</div>'+
									//<div class="mui-col-xs-2 mui-text-right mui-ellipsis mui-h5"></div>
									'</div><div><h5>'+item.NOTICE_CONTENT+'</h5></div>'+
									'<div><h6 class="mui-text-right">'+item.NOTICE_TIME+'</h6></div>';
					table.appendChild(li);
				});
				mui.toast('共'+data.info.total+'条记录,已加载'+(param.pageNo*param.pageSize > data.info.total ? '完毕':param.pageNo*param.pageSize+'条'));
				if(++param.pageNo > Math.ceil(data.info.total/param.pageSize)){
					mui('#pullup-container').pullRefresh().endPullupToRefresh(true);//加载完毕
				}else{
					mui('#pullup-container').pullRefresh().endPullupToRefresh(false);//还有更多数据
				}
			}
		},function(){
			mui('#pullup-container').pullRefresh().endPullupToRefresh(false);//还有更多数据
		},function(){
			plus.nativeUI.closeWaiting();
		});
	}, 1500);
}