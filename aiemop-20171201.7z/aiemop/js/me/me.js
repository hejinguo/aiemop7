mui.init({
	
});

var toolItemArray = [{id:'page-notice',url:'../me/notice.html'},
	{id:'page-signed',url:'../me/signed.html'},
	{id:'page-barcode',url:'../me/barcode_scan.html'},
	{id:'page-alarm-index',url:'../setting/alarm-index.html'},
	{id:'page-core-index',url:'../setting/core-index.html'},
	{id:'page-market-group',url:'../setting/market-group.html'},
	{id:'page-group-index',url:'../setting/group-index.html'},
//	{id:'page-work-main',url:'../work/work-main.html'},
	{id:'page-big-data',url:'../work/bigdata/bigdata-unit-list.html'},
	{id:'page-about-this',url:'../me/about.html'}];

mui.plusReady(function() {
	mui('#user-staff-label')[0].innerHTML=ai.user.staffName+'('+ai.user.staffCode+')';
	mui('#user-organize-label')[0].innerHTML=ai.user.organize.orgName;
	mui('#user-role-label')[0].innerHTML=ai.user.roles[0].roleName;
	if(ai.user.organize.orgType == 5){//客户经理角色启用预警阈值设置功能
		mui('#page-alarm-index')[0].parentNode.classList.remove('mui-hidden');
	}
	if(ai.user.roles.length > 1){
		mui('#aboutme h5 a')[0].classList.remove('mui-hidden');
	}
	if(mui.os.android){
		mui('#close-button')[0].classList.remove('mui-hidden');
	}
	
//	点击切换用户角色按钮
	changeUserRoleTapEvent();
//	点击页面功能模块
	openToolPageTapEvent();
//	退出登录(注销)
	logoutButtonTapEvent();
//	退出应用(关闭)
	closeButtonTapEvent();
});

//点击切换用户角色按钮
function changeUserRoleTapEvent(){
	mui('#aboutme h5 a')[0].addEventListener('tap',function(){
		var buttons = new Array();
		mui.each(ai.user.roles,function(index,item){
			buttons.push({title:item.roleName});
		});
		plus.nativeUI.actionSheet( {
//			title:"切换角色",
			cancel:"取消",
			buttons:buttons
		}, function(e){
			var index = e.index;
			if(e.index == 0){
				
			}else{
				if(e.index <= ai.user.roles.length){
					plus.nativeUI.showWaiting("正在加载数据,请稍等.");
					ai.ajax('base/role/modifyUserDefaultRole',{roleId:ai.user.roles[e.index-1].roleId,orgId:ai.user.roles[e.index-1].orgId},function(data){
						plus.storage.setItem("CHANGE-USER-ROLE",ai.user.roles[e.index-1].roleName);//记录接下来不用登录验证
						plus.runtime.restart();
					},function(){
						
					},function(){
						plus.nativeUI.closeWaiting();
					});
				}
			}
		});
	});
}

//点击页面功能模块
function openToolPageTapEvent(){
	mui('.mui-table-view').on('tap', 'a', function(e) {
		var find = false;
		for (var i = 0; i < toolItemArray.length; i++) {
			if(this.getAttribute('id') == toolItemArray[i].id){
				ai.openWindow({
					url:toolItemArray[i].url,
		    		id:toolItemArray[i].id,
		    		styles:{
		    			scrollIndicator:'none'
		    		}
				});
				find=true;
				break;
			}
		}
		if(!find){
			mui.alert('对不起,该功能尚未对您开放.');
		}
	});
}

//退出登录(注销)
function logoutButtonTapEvent(){
	mui('#logout-button')[0].addEventListener('tap', function() {
		mui.confirm('您确定要注销当前登录用户吗?','操作确认',['取消','确定'],function(e){
			if (e.index == 1) {
				plus.runtime.restart();
			}
		});
	});
}

//退出应用(关闭)
function closeButtonTapEvent(){
	mui('#close-button')[0].addEventListener('tap', function() {
		mui.confirm('您确定要退出应用程序吗?','操作确认',['取消','确定'],function(e){
			if (e.index == 1) {
				plus.runtime.quit();
			}
		});
	});
}
