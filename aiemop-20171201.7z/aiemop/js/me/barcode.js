var flash = false;//闪光灯开启状态
var scan = null;//二维码扫描器对象

mui.plusReady(function() {
	plus.nativeUI.closeWaiting();
	scan = new plus.barcode.Barcode('bcid');
	scan.onmarked = onmarked; 
});

/**
 * 扫码成功处理函数
 * @param {Object} type
 * @param {Object} result
 */
function onmarked(type, result){
	if(type == plus.barcode.QR){
		var splits = result.split(":");
		switch(splits[0]){
			case "QR_AIEMOP_LOGIN":
				qrSetLoginToken(splits[1]);
				break;
			default:
				scan.start();
				mui.toast("您扫描的不是我们提供的二维码.");
		}
	}else{
		scan.start();
		mui.toast("您扫描的不是我们提供的二维码.");
	}
}

/**
 * 扫码二维码进行WEB端登陆
 * @param {Object} token
 */
function qrSetLoginToken(token){
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	var param = {oldToken:ai.user.lastLoginToken,newToken:token};
	ai.ajax('http://218.205.252.12:10029/aiemopPro/base/setToken',param,function(data){
		console.log(JSON.stringify(data));
		if(data.state){
			mui.alert("扫码处理成功,请在浏览器中确认使用.","提示","确定",function(){
				ai.user.lastLoginToken = token;
				plus.storage.setItem('USER-BASE-INFO',Base64.encode(JSON.stringify(ai.user)));
				mui.back();
			});
		}
	},function(){
		
	},function(){
		plus.nativeUI.closeWaiting();
	});
}

/**
 * 改变闪光灯状态
 */
function setFlash() {
	flash = !flash;
	scan.setFlash(flash);
}