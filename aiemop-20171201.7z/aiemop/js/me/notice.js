mui.init({
	gestureConfig:{
		doubletap: true
	},
	subpages:[{
		url:'notice-pull.html',
		id:'page-notice-pull',
		styles:{
			top:'44px',
			bottom:'0px'
//			scrollIndicator:'none'
		}
	}],
	beforeback:saveReadedNotice
});

var param = "";//标记为已读的信息ID集

mui.plusReady(function(){
	window.addEventListener('readedNotice',function(event){
		param += "&noticeId="+event.detail.noticeId;//通过event.detail可获得传递过来的参数内容
	});
	
	var contentWebview = null;
	mui('header')[0].addEventListener('doubletap',function () {
		if(contentWebview==null){
			contentWebview = plus.webview.currentWebview().children()[0];
		}
		contentWebview.evalJS("mui('#pullup-container').pullRefresh().scrollTo(0,0,100)");
	});
});

//保存用户阅读的通知信息
function saveReadedNotice(){
	if(param){
//		当反馈成功结果时，需要更新首页的消息数量标记
		ai.ajax('base/notice/saveReadedNotice',param.substring(1),function(data){
			if(data.state){
				mui.fire(plus.webview.currentWebview().opener(),'changeNoticeAmount',{amount:data.info});
			}
		},function(){
			
		},function(){
			
		});
	}
}