var app = null;

mui.plusReady(function() {
	app = new Vue({
		el: '#page-body-vid',
		data: {
			title: '打卡签到',
			moment: moment(),
			calendar: [],
			signDisabled: false//默认今天还未签到
		},
		created: function(){
			this.refreshCalendar();
		},
		methods: {
			refreshCalendar: function(){//刷新日历数据
				var _this = this;
				var today = moment().format("YYYYMMDD");//当日日期
				var _month = _this.moment.format("YYYYMM");//查看的月份
				var _week = _this.moment.date(1).weekday();
				var ctemp = new Array();
				for (var i = 0; i< _week;i++) {
					ctemp.push({date:'',signed:false,today:false});
				}
				for (var i = 1;i<= _this.moment.daysInMonth();i++) {//_this.moment.daysInMonth()-当月共有的多少天
					ctemp.push({date:i,signed:false,today: today == _month+(i<10?'0':'')+i});
				}
//				_this.calendar = ctemp; 决定进入页面是先展示日期还是等加载数据后统一展示
				plus.nativeUI.showWaiting("正在加载数据,请稍等.");
				ai.ajax("setting/signed/getByMonth",{signedMonth:_month},function(data){
					if(data.state){
						mui.each(data.info,function(i,n){
							ctemp[n.SIGNED_DATE%100 + _week - 1].signed = true;
							if(n.SIGNED_DATE == today){//找到今天签到的记录是禁用签到按钮
								_this.signDisabled = true;
							}
						});
						_this.calendar = ctemp;
					}
				},function(){
					
				},function(){
					plus.nativeUI.closeWaiting();
				});
			},
			leftMonthCalendar: function(){//翻到上一月并刷新日历数据
				this.moment = this.moment.subtract(1, 'months');
				this.refreshCalendar();
			},
			rightMonthCalendar: function(){//翻到下一月并刷新日历数据
				this.moment = this.moment.add(1, "months");
				this.refreshCalendar();
			},
			jumpTodayCalendar: function(){
				this.moment = moment();
				this.refreshCalendar();
			},
			tapSignedBtn: function(){//点击签到按钮提交签到记录
				var _this = this;
				plus.nativeUI.showWaiting("正在加载数据,请稍等.");
				ai.ajax("setting/signed/record",{},function(data){
					if(data.state){
						_this.signDisabled = true;
						_this.jumpTodayCalendar();
					}else{
						if(data.info == "HAVE_ONCE_SIGNED"){
							mui.alert("您今日已经签到,请勿重复提交.","提醒");
							_this.signDisabled = true;
							_this.jumpTodayCalendar();
						}else{
							plus.nativeUI.closeWaiting();
						}
					}
				},function(){
					plus.nativeUI.closeWaiting();
				},function(){
					
				});
			}
		}
	});
}); 