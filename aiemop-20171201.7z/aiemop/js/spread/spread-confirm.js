var shares = null; //当前终端支持的分享目标
mui.init({
	swipeBack: false
});
var arr = [{
	way_idint: 1,
	way_id: "way_msg",
	way_name: "本机短信"
}, {
	way_idint: 2,
	way_id: "way_phone",
	way_name: "语音外呼"
}, {
	way_idint: 3,
	way_id: "way_1008688",
	way_name: "1008688"
}, {
	way_idint: 4,
	way_id: "way_weixin",
	way_name: "微信"
}, {
	way_idint: 5,
	way_id: "way_pengyouquan",
	way_name: "朋友圈"
}, {
	way_idint: 6,
	way_id: "way_qq",
	way_name: "QQ"
}];
var delete_userid = "";
mui.plusReady(function() {
	var self = plus.webview.currentWebview();
	var mkt_id = self.mkt_id;
	var mkt_name = self.mkt_name;
	var way_id = self.way_id;
	var way_name;
	var way_idint;
	for (var i in arr) {
		if (arr[i].way_id == way_id) {
			way_name = arr[i].way_name;
			way_idint = arr[i].way_idint;
		}
	}
	var group_id = self.group_id;
	var group_name;
	if (group_id == -1000) {
		group_name = "无";
	} else {
		group_name = self.group_name;
	}
	var delete_unitid = self.delete_unitid;
	if (!delete_unitid) {
		//mui.alert(delete_unitid);
		delete_unitid = '';
	}
	if (self.delete_userid) {
		delete_userid = self.delete_userid;
	}
	var spreadState=1;//已推广
	if((delete_unitid&&delete_unitid!="")||(delete_userid&&delete_userid!="")){
		spreadState=2;//部分推广
	}
	//mui.alert(delete_userid);
	/**
	 * 顶部显示内容
	 */
	document.body.querySelector('#mkt_name').innerText = mkt_name;
	document.body.querySelector('#way_name').innerText = way_name;
	document.body.querySelector('#group_name').innerText = group_name;

	/**
	 * 确认内容
	 */
	document.body.querySelector('#show_mkt_name').innerHTML = mkt_name;
	document.body.querySelector('#show_group_name').innerText = group_name;
	document.body.querySelector('#show_way_name').innerHTML = way_name;
	//加载活动内容
	var unit_param = {
		'mktId': mkt_id,
		'groupId': group_id
	}
	ai.ajax("spread/getSpreadContent", unit_param, function(data) {
		if (data.state) {
			if (data.info[0]) {
				document.body.querySelector('#sharecontent').innerHTML = data.info[0].SPREAD_TEMPLATE;
			} else {
				document.body.querySelector('#sharecontent').innerHTML = "";
			}
		}
	}, function() {

	}, function() {

	});
	var phone_param = {
			'mktId': mkt_id,
			'groupId': group_id,
			'delUnitId': delete_unitid.toString(),
			'delUserId': delete_userid
		}
		//如果推广方式是本机短信，需要读取需要发送的手机号码和内容；
	if (way_id == "way_msg") {
		ai.ajax("spread/getSpreadPhoneList", phone_param, function(data) {
			if (data.state) {
				var send_phone = "";
				mui.each(data.info, function(index, item) {
					send_phone += item.PHONE_NO + ",";
				});
				var spread_con = document.body.querySelector('#sharecontent').innerHTML;
				//mui.alert(send_phone.substring(0,send_phone.length-1));
				document.body.querySelector("#spread_confirm_button").className = "btn_hide";
				var send_msg = document.body.querySelector("#send_message");
				send_msg.style.display = "";
				if (plus.os.name == "Android") {
					send_msg.setAttribute("href", "sms:" + send_phone.substring(0, send_phone.length - 1) + "?body=" + spread_con);
				} else {
					send_msg.setAttribute("href", "sms:" + send_phone.substring(0, send_phone.length - 1) + "&body=" + spread_con);
				}
			}
		}, function() {

		}, function() {

		});

	}
	//确认操作
	mui("#spread_confirm_button")[0].addEventListener("tap", function() {
		if (way_id == "way_weixin") {
			//通过微信方式推广
			//mui.alert(JSON.stringify(shares),"hello");
			shareAction("weixin", "wx_haoyou", mkt_id, group_id, way_idint, delete_unitid, spreadState);
		} else if (way_id == "way_pengyouquan") {
			//通过朋友圈推广
			//mui.alert(JSON.stringify(shares),"hello");
			shareAction("weixin", "wx_pengyouquan", mkt_id, group_id, way_idint, delete_unitid, spreadState);
		} else if (way_id == "way_qq") {
			//通过QQ推广
			shareAction("qq", "wx_none", mkt_id, group_id, way_idint, delete_unitid, spreadState);
		} else if (way_id == "way_phone") {
			//通过语音外呼推广
			insertSpreadRec(mkt_id, group_id, way_idint, delete_unitid,spreadState);
		} else if (way_id == "way_1008688") {
			//通过1008688推广
			insertSpreadRec(mkt_id, group_id, way_idint, delete_unitid, spreadState);
		}

	});
	mui("#send_message")[0].addEventListener("tap", function() {
		if (way_id == "way_msg") {
			//通过本机短信推广
			insertSpreadRec(mkt_id, group_id, way_idint, delete_unitid, spreadState);
		}
	});
	//	获取当前终端支持的分享目标
	plus.share.getServices(function(s) {
		shares = {};
		for (var i in s) {
			var t = s[i];
			shares[t.id] = t;
		}
	});
});
/**
 * 插入推广记录
 * @param {Object} mkt_id
 * @param {Object} group_id
 * @param {Object} way_idint
 * @param {Object} spreadState
 */
function insertSpreadRec(mkt_id, group_id, way_idint, delete_unitid, spreadState) {
	/**
	 * 插入数据到推广记录中
	 */
	//var rec_id=Math.floor(Math.random()*100000)+999999;
	var param = {
		'mktId': mkt_id,
		'groupId': group_id,
		'spreadContent': sharecontent.value,
		'spreadWay': way_idint,
		'spreadState': spreadState
	};
	ai.ajax("spread/insertSpreadRec", param, function(data) {

	},function(){
		
	},function(){
		
	});
	//如果不是网络推广
	if (group_id != -1000 && way_idint != 4 && way_idint != 5 && way_idint != 6) {
		var update_param = {
			'groupId': group_id,
			'mktId': mkt_id,
			'delUnitId': delete_unitid.toString(),
			'delUserId': delete_userid
		};
		ai.ajax("spread/updateSpreadRec", update_param, function(data) {
			//mui.alert("成功");
		});
	}
	//跳转到推广记录中
	ai.openWindow({
		url: "spread-history.html",
		id: "page-spread-history",
		styles: {
			popGesture: 'close'
		}
	});
}
/**
 * 分享操作
 * @param {String} id
 */
function shareAction(id, wx_type, mkt_id, group_id, way_idint, delete_unitid, spredstate) {
	var s = null;
	console.log("分享操作：" + id);
	if (!id || !(s = shares[id])) {
		console.log("无效的分享服务！");
		mui.toast("无效的分享服务！");
		return;
	}
	if (s.authenticated) {
		console.log("---已授权---");
		shareMessage(s, wx_type, mkt_id, group_id, way_idint, delete_unitid, spredstate);
	} else {
		console.log("---未授权---");
		s.authorize(function() {
			shareMessage(s, wx_type, mkt_id, group_id, way_idint, delete_unitid, spredstate);
		}, function(e) {
			console.log("认证授权失败：" + e.code + " - " + e.message);
			mui.toast("认证授权失败：" + e.code + " - " + e.message);
		});
	}
}

/**
 * 发送分享消息
 * @param {plus.share.ShareService} s
 */
function shareMessage(s, wx_type, mkt_id, group_id, way_idint, delete_unitid, spredstate) {
	//var msg={content:'abcd',extra:{scene:'WXSceneSession'}};
	var msg = {
		content: sharecontent.value
	};
	if (s.id == 'weixin' && wx_type == 'wx_haoyou') {
		msg.extra = {
			scene: 'WXSceneSession'
		}; //分享到微信时是发送给微信好友,而不是朋友圈
	} else if (s.id == 'weixin' && wx_type == 'wx_pengyouquan') {
		msg.extra = {
			scene: 'WXSceneTimeline'
		};
	}
	if (s.id == 'qq') {
		msg.href = "http://www.dcloud.io";
		msg.title = "政企营销";
		msg.thumbs = ["_www/css/images/chapter_already_extension.png"];
		msg.pictures = ["_www/css/images/chapter_already_extension.png"];
	}
	console.log(JSON.stringify(msg));
	s.send(msg, function() {
		console.log("分享到\"" + s.description + "\"成功！ ");
		mui.toast("推广完成!");
		insertSpreadRec(mkt_id, group_id, way_idint, delete_unitid, spredstate);
	}, function(e) {
		console.log("分享到\"" + s.description + "\"失败: " + e.code + " - " + e.message);
		mui.toast("推广未完成");
	});
}