mui.init({
	swipeBack: false
});
mui.plusReady(function() {
	//    		打开消息页面
	document.getElementById("showmessage_button").addEventListener('tap', function() {
		var mainPage = plus.webview.currentWebview().opener();
		mui.fire(mainPage, "main:showMessage");
	});

	mui('.mui-content').on('tap', 'div', function(e) {
		if (this.getAttribute('id') == 'market_unextension') {
			mui.openWindow({
				url: 'spread-market.html',
				id: 'page-spread-market',
				styles: {
					bounce: 'vertical',
					popGesture: 'close'
				}
			});
		} else if (this.getAttribute('id') == 'market_extensioned') {
			mui.openWindow({
				url: 'spread-history.html',
				id: 'page-spread-history',
				styles: {
					popGesture: 'close'
				}
			});
		}
	});
});

function initUnHisEcharts() {
	var spredNoneChart = echarts.init(document.getElementById('market_unextension'));
	var option = {
		title: {
			text: '已推广活动',
			textStyle: {
				fontSize: 14
			},
			left:'left'
			//subtext: '98.43%',
			//subtextStyle:{color:'#FFF',fontSize:18}
		},
		tooltip: {
			show: false,
			trigger: 'item',
			formatter: "{a} <br/>{b}: {c} ({d}%)"
		},
		color: ['#0ECBEF', '#9EDB18', '#9ED221', '#7EE4FB', '#7EE4FB', '#9ED221', '#B2E834'],
		legend: {
			orient: 'vertical',
			x: 'right',
			top: '50%',
			data: ['维稳类', '终端类', '实物类', '其他类']
		},
		//animation:false,
		series: [{
			name: '未推广',
			type: 'pie',
			radius: '65%',
			center: ['40%', '60%'],
			data: [{
				value: 15,
				name: '维稳类'
			}, {
				value: 8,
				name: '终端类'
			}, {
				value: 13,
				name: '实物类'
			}, {
				value: 12,
				name: '其他类'
			}],
			itemStyle: {
				emphasis: {
					shadowBlur: 10,
					shadowOffsetX: 0,
					shadowColor: 'rgba(0, 0, 0, 0.5)'
				}
			}
		}]
	};
	// 使用刚指定的配置项和数据显示图表。
	spredNoneChart.setOption(option);
	spredNoneChart.on('click', function(param) {
		mui.openWindow({
			url: 'spread-market.html',
			id: 'page-spread-market',
			styles: {
				bounce: 'vertical',
				popGesture: 'close'
			}
		});
	});
}

function initHisEcharts() {
	var spredChart = echarts.init(document.getElementById('market_extensioned'));
	var option = {
		title: {
			text: '未推广活动',
			textStyle: {
				fontSize: 14
			},
			left:'left'
			//subtext: '98.43%',
			//subtextStyle:{color:'#FFF',fontSize:18}
		},
		tooltip: {
			show: false,
			trigger: 'item',
			formatter: "{a} <br/>{b}: {c} ({d}%)"
		},
		color: ['#0ECBEF', '#9EDB18', '#9ED221', '#7EE4FB', '#7EE4FB', '#9ED221', '#B2E834'],
		legend: {
			orient: 'vertical',
			x: 'right',
			top: '50%',
			data: ['维稳类', '终端类', '实物类', '其他类']
		},
		//animation:false,
		series: [{
			name: '已推广',
			type: 'pie',
			radius: '65%',
			center: ['40%', '60%'],
			data: [{
				value: 25,
				name: '维稳类'
			}, {
				value: 9,
				name: '终端类'
			}, {
				value: 14,
				name: '实物类'
			}, {
				value: 12,
				name: '其他类'
			}],
			itemStyle: {
				emphasis: {
					shadowBlur: 10,
					shadowOffsetX: 0,
					shadowColor: 'rgba(0, 0, 0, 0.5)'
				}
			}
		}]
	};
	// 使用刚指定的配置项和数据显示图表。
	spredChart.setOption(option);
	spredChart.on('click', function(param) {
		mui.openWindow({
			url: 'spread-history.html',
			id: 'page-spread-history',
			styles: {
				popGesture: 'close'
			}
		});
	});
}