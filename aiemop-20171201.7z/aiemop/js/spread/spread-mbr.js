mui.init({
	swipeBack: false,
	gestureConfig: {
		tap: true, //默认为true
		doubletap: true, //默认为false
		longtap: true, //默认为false
		swipe: true, //默认为true
		drag: true, //默认为true
		hold: false, //默认为false，不监听
		release: false //默认为false，不监听
	}
});
var arr = [{
	way_id: "way_msg",
	way_name: "本机短信"
}, {
	way_id: "way_phone",
	way_name: "语音外呼"
}, {
	way_id: "way_1008688",
	way_name: "1008688"
}, {
	way_id: "way_weixin",
	way_name: "微信"
}, {
	way_id: "way_pengyouquan",
	way_name: "朋友圈"
}, {
	way_id: "way_qq",
	way_name: "QQ"
}];
/**
 * 保存所有集团删除的成员
 */
var delete_id_no = new Array();
var delete_unit_id = new Array();
mui.plusReady(function() {
	var self = plus.webview.currentWebview();
	var mkt_id = self.mkt_id;
	var mkt_name = self.mkt_name;
	var way_id = self.way_id;
	var way_name;
	for (var i in arr) {
		if (arr[i].way_id == way_id) {
			way_name = arr[i].way_name;
		}
	}

	/**
	 * 顶部显示内容
	 */
	document.body.querySelector('#mkt_name').innerText = mkt_name;
	document.body.querySelector('#way_name').innerText = way_name;
	/*
	 * 根据活动ID列出目标客户群
	 */
	loadTarget(self.mkt_id);
	/*
	 * 选择客户群标题加载集团
	 */
	mui("#mbr_list").on("tap", "a", function() {
		var li_list = document.getElementsByTagName("li");
		for (var i = 0; i < li_list.length; i++) {
			var li_one = li_list[i];
			li_one.classList.remove("mui-active");
		}
		var show_state = this.getAttribute("show_state");
		var group_id = this.getAttribute("group_id");
		//判断是否已经加载成功
		var check_num = document.getElementsByName("subcheck_" + group_id).length;
		if (show_state == 0 || check_num == 0) {
			loadUnitBase(group_id, self.mkt_id);
			this.setAttribute("show_state", 1);
		} else {
			//清空已记录的删除数据
			delete_id_no = new Array();
			delete_unit_id = new Array();
			//重新初始化群组选中状态
			mui("input[name='subcheck_" + group_id + "']").each(function() {
				this.checked = true;
				//初始化集团的成员数
				this_unit_id = this.getAttribute("unit_id");
				document.body.querySelector("#unit_num_" + this_unit_id).innerText = document.body.querySelector("#unit_num_none_" + this_unit_id).innerText;
			});
			document.body.querySelector("#shownum" + group_id).innerText = document.body.querySelector("#shownum_none" + group_id).innerText + "位";
		}
		//记录选中的群组和群组名称
		document.getElementById("lbl_group_id").innerText = this.getAttribute("group_id");
		document.getElementById("lbl_group_name").innerText = this.getAttribute("group_name");
	});
	/*
	 * 选择集团查看集团的该活动的目标客户
	 * */
	mui("#mbr_list").on("longtap", "h5", function() {
		var curr_unitid = this.getAttribute("unit_id");
		var curr_delete_idno = new Array();
		//先判断该集团是否已经删除过成员
		if (delete_unit_id.toString().indexOf(curr_unitid) >= 0) {
			//mui.alert(delete_unit_id.toString().indexOf(curr_unitid));
			for (var i = 1; i <= delete_unit_id.length; i++) {
				if (delete_unit_id[i - 1] == curr_unitid) {
					//mui.alert(delete_unit_id[i]);
					curr_delete_idno = delete_id_no[i - 1];
				}
			}
		}
		//mui.alert(curr_delete_idno);
		ai.openWindow({
			url: "spread-mbruser.html",
			id: "page-spread-mbruser",
			extras: {
				unit_id: curr_unitid,
				group_id: this.getAttribute("group_id"),
				mkt_id: mkt_id,
				mkt_name: mkt_name,
				way_id: way_id,
				delete_id_no: curr_delete_idno.toString()
			}
		});
	});
	/*
	 * 下一步操作按钮
	 */
	var btn_next_step = document.getElementById("next_step_button");
	btn_next_step.addEventListener("tap", function() {
		next_step(mkt_id, mkt_name, way_id);
	});
	/**
	 * Checkbox选择事件
	 */
	mui("#mbr_list").on("change", "input", function() {
		var num = this.getAttribute("unit_id_num");
		var group_id = this.getAttribute("group_id");
		var unit_id = this.getAttribute("unit_id");
		var group_num = document.body.querySelector("#shownum" + group_id);
		var old_num_txt = group_num.innerText;
		var old_num = -1;
		if (old_num_txt.indexOf("位") > 0) {
			old_num = old_num_txt.substring(0, old_num_txt.indexOf("位"));
		}
		var unit_id_num = document.body.querySelector("#unit_num_" + unit_id);
		var unit_id_num_none = document.body.querySelector("#unit_num_none_" + unit_id);
		//如果是选中
		if (this.checked) {
			//如果集团的被取消了所有成员
			if (unit_id_num.innerText == "0") {
				unit_id_num.innerText = unit_id_num_none.innerText;
				var delete_unit_index=-1;
				//如果已经做过调整
				for (var i=1;i<=delete_unit_id.length;i++) {
					if(delete_unit_id[i-1]==unit_id){
						//mui.alert(delete_unit_id[i]);
						delete_unit_index=i-1;
					}
				}
				//mui.alert(delete_unit_index.toString());
				//如果已经做过调整，先删除原来的记录；
				if(delete_unit_index>=0){
					delete_unit_id.splice(delete_unit_index,1);
					delete_id_no.splice(delete_unit_index,1);
				}
			} else {
				//group_num.innerText = parseInt(old_num) + parseInt(num) + "位";
			}
		} else {
			//group_num.innerText = parseInt(old_num) - parseInt(num) + "位";
		}
		//重新更新当前群组的成员数
		var group_id_num = 0;
		mui("input[name='subcheck_" + group_id + "']").each(function() {
			var this_num = document.body.querySelector("#unit_num_" + this.getAttribute("unit_id")).innerText;
			if (this.checked) {
				group_id_num += parseInt(this_num);
			}
		});
		if (group_id_num >= 0) {
			group_num.innerText = group_id_num + "位";
		} else {
			group_num.innerText = "无";
		}
	});
});

/**
 * 根据活动ID列出目标客户群
 * @param {Object} mkt_id
 */
function loadTarget(mkt_id) {
	var param = {
		'mktId': mkt_id
	};
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	ai.ajax("spread/chooseTargetCustomerBase", param, function(data) {
		if (data.state) {
			var mbr_list = document.body.querySelector("#mbr_list");
			mui.each(data.info, function(index, item) {
				var mbr_ul = document.createElement('ul');
				mbr_ul.className = "mui-card";
				mbr_ul.innerHTML = '<li class="mui-table-view-cell mui-collapse">' +
					'<a group_id="' + item.GROUP_ID + '" group_name="' + item.GROUP_NAME + '" show_state="0" class="mui-navigate-right" href="#">' +
					'<span id="shownum' + item.GROUP_ID + '" class="mui-badge mui-badge-inverted">' + item.MKT_ID_NUM + '位</span>' +
					'<span style="display:none" id="shownum_none' + item.GROUP_ID + '">' + item.MKT_ID_NUM + '</span><h4 class="mui-ellipsis">' + item.GROUP_NAME + '</h4></a>' +
					'<ul class="mui-table-view mui-table-view-chevron" id="unit_list_' + item.GROUP_ID + '"></ul>' +
					'<div class="mui-collapse-content"></div></li>';
				mbr_list.appendChild(mbr_ul);
			});
		}
	}, function() {

	}, function() {
		plus.nativeUI.closeWaiting();
	});
}

/**
 * 根据group_id加载集团明细
 * @param {Object} group_id
 */
function loadUnitBase(group_id, mkt_id) {
	//清空成员删除列表；
	delete_id_no = new Array();
	delete_unit_id = new Array();
	var unit_param = {
		'groupId': group_id,
		'mktId': mkt_id
	};
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	//mui.alert(group_id+","+mkt_id);
	ai.ajax("spread/checkUnitBase", unit_param, function(data) {
		if (data.state) {
			var unit_list = document.body.querySelector("#unit_list_" + group_id);
			unit_list.innerHTML = "";
			mui.each(data.info, function(index, item) {
				var unit_li = document.createElement("li");
				unit_li.className = "mui-table-view-cell  mui-checkbox mui-left";
				var unit_name = item.UNIT_NAME;
				if (unit_name.length > 14) {
					unit_name = unit_name.substr(0, 14) + "...";
				}
				unit_li.innerHTML = '<input group_id="' + item.GROUP_ID + '" unit_id="' + item.UNIT_ID + '" unit_id_num="' + item.UNIT_ID_NUM + '"  name="subcheck_' + item.GROUP_ID + '" type="checkbox" checked="true">' +
					'<h5 unit_id="' + item.UNIT_ID + '" group_id="' + item.GROUP_ID + '">' + unit_name + '（<span id="unit_num_' + item.UNIT_ID + '">' + item.UNIT_ID_NUM + '</span><span style="display:none" id="unit_num_none_' + item.UNIT_ID + '">' + item.UNIT_ID_NUM + '</span>位）</h5>';
				unit_list.appendChild(unit_li);
			});
		}
	}, function() {

	}, function() {
		plus.nativeUI.closeWaiting();
	});
}
/**
 * 点击下一步按钮的操作内容
 * @param {Object} mkt_id
 * @param {Object} mkt_name
 * @param {Object} way_id
 */
function next_step(mkt_id, mkt_name, way_id) {
	var group_id = document.getElementById("lbl_group_id").innerText;
	var group_name = document.getElementById("lbl_group_name").innerText;
	//mui.alert(group_name);
	if (group_id && group_name) {
		//根据group_id查看集团是否做了修改
		var input_name = "subcheck_" + group_id;
		var delete_unitid = new Array(); //取消选择的集团数组
		var check_unitid = 0;
		mui("input[name='" + input_name + "']").each(function() {
			var del_unitid = this.getAttribute("unit_id");
			if (!this.checked) {
				delete_unitid.unshift(del_unitid);
			} else if (this.checked) {
				check_unitid = check_unitid + 1;
			}
		});
		//mui.alert(delete_unitid.toString());
		//有没删除成员
		var delete_userid = "";
		if (delete_id_no.length > 0) {
			for (var i = 0; i < delete_id_no.length; i++) {
				if (i == delete_id_no.length - 1) {
					delete_userid += delete_id_no[i].toString();
				} else {
					delete_userid += delete_id_no[i].toString() + ",";
				}
			}
		}
		//mui.alert(delete_userid);
		//如果有取消集团选择，创建新的目标客户群记录推广的用户
		if (delete_unitid.length > 0 && check_unitid > 0) {
			ai.openWindow({
				url: "spread-confirm.html",
				id: "page-spread-confirm",
				extras: {
					mkt_id: mkt_id,
					mkt_name: mkt_name,
					way_id: way_id,
					group_id: group_id,
					group_name: group_name,
					delete_unitid: delete_unitid,
					delete_userid: delete_userid
				}
			});
		} else if (delete_unitid.length == 0 && check_unitid > 0) {
			//没有取消选择，直接跳转到确认页面
			ai.openWindow({
				url: "spread-confirm.html",
				id: "page-spread-confirm",
				extras: {
					mkt_id: mkt_id,
					mkt_name: mkt_name,
					way_id: way_id,
					group_id: group_id,
					group_name: group_name,
					delete_userid: delete_userid
				}
			});
		} else  {//if (delete_unitid.length > 0 && check_unitid <= 0)
			mui.toast('请选择目标客户群的集团！');
		}

	} else {
		mui.toast('请选择目标客户群！');
	}
}

/**
 * 接受成员页面删除的成员数组
 * @param {Object} userIdList
 */
function getChangeUser(group_id, unit_id, userIdList) {
	///mui.alert(userIdList+":"+unit_id,"dfd");
	var lbl_unit_num = document.body.querySelector("#unit_num_" + unit_id);
	//该集团的总数量
	var lbl_unit_none_num = document.body.querySelector("#unit_num_none_" + unit_id);
	//记录是否删除所有集团成员
	var delete_unit_allno = -1;
	//mui.alert(userIdList);
	//插入的集团数组
	var delete_unit_index = -1;
	//如果已经做过调整
	for (var i = 1; i <= delete_unit_id.length; i++) {
		if (delete_unit_id[i - 1] == unit_id) {
			//mui.alert(delete_unit_id[i]);
			delete_unit_index = i - 1;
		}
	}
	//mui.alert(delete_unit_index.toString());
	//如果已经做过调整，先删除原来的记录；
	if (delete_unit_index >= 0) {
		delete_unit_id.splice(delete_unit_index, 1);
		delete_id_no.splice(delete_unit_index, 1);
	}
	if (userIdList && userIdList != "") {
		//删除的成员
		var delete_id_no_now = userIdList.split(',');
		//更新集团数量的显示；
		if (lbl_unit_num && lbl_unit_none_num) {
			var old_num = parseInt(lbl_unit_none_num.innerText);
			if (old_num - delete_id_no_now.length == 0) {
				delete_unit_allno = 0;
			}
			lbl_unit_num.innerText = (old_num - delete_id_no_now.length).toString();
		}

		//插入数据
		delete_unit_id.push(unit_id);
		delete_id_no.push(delete_id_no_now);

		//mui.alert(delete_unit_id.toString());
		//mui.alert(delete_id_no[0].toString());
		//mui.alert(delete_id_no[1]);
	} else {
		lbl_unit_num.innerText = lbl_unit_none_num.innerText;
	}
	var all_group_num = 0;
	mui("input[name='subcheck_" + group_id + "']").each(function() {
		var curr_unit_id = this.getAttribute("unit_id");
		if (curr_unit_id == unit_id) {
			if (delete_unit_allno == 0) {
				this.checked = false;
			} else {
				this.checked = true;
			}
		}
		//修改群成员数
		var group_num = document.body.querySelector("#unit_num_" + curr_unit_id);
		if (group_num && this.checked) {
			all_group_num = all_group_num + parseInt(group_num.innerText);
		}
		//mui.alert(all_group_num.toString());
	});
	if (all_group_num >= 0) {
		document.body.querySelector("#shownum" + group_id).innerText = all_group_num + "位";
	} else {
		document.body.querySelector("#shownum" + group_id).innerText = "无";
	}
}