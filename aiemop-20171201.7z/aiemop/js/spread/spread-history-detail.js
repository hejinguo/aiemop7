mui.init({
	swipeBack: false
});
var arr = [{
	way_idint: 1,
	way_id: "way_msg",
	way_name: "本机短信"
}, {
	way_idint: 2,
	way_id: "way_phone",
	way_name: "语音外呼"
}, {
	way_idint: 3,
	way_id: "way_1008688",
	way_name: "1008688"
}, {
	way_idint: 4,
	way_id: "way_weixin",
	way_name: "微信"
}, {
	way_idint: 5,
	way_id: "way_pengyouquan",
	way_name: "朋友圈"
}, {
	way_idint: 6,
	way_id: "way_qq",
	way_name: "QQ"
}];
mui.plusReady(function() {
	var self = plus.webview.currentWebview();
	var rec_id = self.rec_id;
	loadRecDetail(rec_id);
	//确认操作
	mui("#spread_confirm_button")[0].addEventListener("tap", function() {
		mui.back();
	});
});

function loadRecDetail(recid) {
	//mui.alert(recid);
	var para = {
		'recId': recid
	};
	ai.ajax("spread/getSpreadRecDetail", para, function(data) {
		if (data.state) {
			mui.each(data.info, function(index, item) {
				var group_name = "";
				if (item.GROUP_NAME) {
					group_name = item.GROUP_NAME;
				} else {
					group_name = "无";
				}
				var way_idint = item.SPREAD_WAY;
				var way_name = "";
				for (var i in arr) {
					if (arr[i].way_idint == item.SPREAD_WAY) {
						way_name = arr[i].way_name;
					}
				}
				document.body.querySelector('#show_mkt_name').innerHTML = item.MKT_NAME;
				document.body.querySelector("#show_group_name").innerHTML = group_name;
				document.body.querySelector('#show_way_name').innerHTML = way_name;
				document.body.querySelector('#sharecontent').innerHTML = item.SPREAD_CONTENT;
			});
		}
	}, function() {

	}, function() {

	});
}