mui.init({
	pullRefresh: {
		container: '#pullrefresh',
		up: {
			callback: pullupRefresh
		}
	}
});
var way_arr = [{
	way_idint: 1,
	way_id: "way_msg",
	way_name: "本机短信"
}, {
	way_idint: 2,
	way_id: "way_phone",
	way_name: "语音外呼"
}, {
	way_idint: 3,
	way_id: "way_1008688",
	way_name: "1008688"
}, {
	way_idint: 4,
	way_id: "way_weixin",
	way_name: "微信"
}, {
	way_idint: 5,
	way_id: "way_pengyouquan",
	way_name: "朋友圈"
}, {
	way_idint: 6,
	way_id: "way_qq",
	way_name: "QQ"
}];
var para = {
	'pageNo': 1,
	'pageSize': 10
};
mui.plusReady(function() {
	window.addEventListener('initParamMktType', function(event) {
		para.mktType = event.detail.mktType;
	});
	/*
	 * 加载历史记录
	 */
	initSpreadHis();
	//初始化搜索事件
	searchRec();
	
	mui("#his_list").on("tap", "div", function() {
		var recid = this.getAttribute("rec_id");
		ai.openWindow({
			url: "spread-history-detail.html",
			id: "page-spread-history-detail",
			extras: {
				rec_id: recid
			}
		});
	});
});

function initSpreadHis() {
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	document.body.querySelector('.mui-table-view').innerHTML="";
	para.pageNo = 1;
	pullupRefresh();
	//mui('#pullrefresh').pullRefresh().scrollTo(0,0,100);
}

/**
 * 搜索历史记录
 */
function searchRec() {
	document.querySelector('form').addEventListener('submit', function(e) {
		e.preventDefault(); // 阻止默认事件
		var searchInputBox = mui('.mui-input-clear')[0];
		searchInputBox.blur();
		para.mktName = searchInputBox.value;
		mui('#pullrefresh').pullRefresh().refresh(true); //重置上拉加载
		initSpreadHis();
	});
}
function pullupRefresh() {
	setTimeout(function() {
		loadSpreadHis();
	}, 1500);
}

function loadSpreadHis() {
	ai.ajax("spread/selectSpreadRec", para, function(data) {
		if (data.state) {
			//var his_list = document.body.querySelector("#his_list");
			var his_list = document.body.querySelector('.mui-table-view');
			var length = 0;
			mui.each(data.info.rows, function(index, item) {
				length = index + 1;
				//推广方式名称
				var way_name = '';
				for (var i in way_arr) {
					if (way_arr[i].way_idint == item.SPREAD_WAY) {
						way_name = way_arr[i].way_name;
					}
				}
				var group_name = item.GROUP_NAME;
				if (!group_name) {
					group_name = "无";
				}
				//是否完全推广	
				var class_list_name = "mkt_spread_finish";
				if (item.SPREAD_STATE == "2" && item.SPREAD_WAY != "4" && item.SPREAD_WAY != "5" && item.SPREAD_WAY != "6") {
					class_list_name = "mkt_spread_part";
				}
				var mkt_div = document.createElement("li");
				mkt_div.className = 'mui-table-view-cell';
				//mkt_div.className = "mui-card " + class_list_name;
				//mkt_div.setAttribute("rec_id", item.REC_ID);
				mkt_div.innerHTML = '<div class="mui-card '+class_list_name+' " rec_id="'+item.REC_ID+'" ><h4 class="mui-ellipsis" style="width:80%">' + item.MKT_NAME + '</h4>' +
					'<h5 class="mui-ellipsis">活动地域：' + item.ORG_NAME + '</h5>' +
					'<h5 class="mui-ellipsis">活动时间：' + item.MKT_BEGIN_TIME + '~' + item.MKT_END_TIME + '</h5>' +
					'<h5 class="mui-ellipsis">推广时间：' + item.CREATE_TIME + '</h5>' +
					'<h5 class="mui-ellipsis">目标客户群：' + group_name + '</h5>' +
					'<h5 class="mui-ellipsis">推广渠道：' + way_name + '</h5></div>';
				his_list.appendChild(mkt_div);
			});
			/*if (length <= 0) {
				his_list.innerHTML = '<li><div class="mui-card" style="text-align: center;">还没有记录，赶快推广吧！</div></li>';
			}*/
			mui.toast('共' + data.info.total + '条记录,已加载' + (para.pageNo * para.pageSize > data.info.total ? '完毕' : para.pageNo * para.pageSize + '条'));
			//mui.alert(Math.ceil(data.info.total/para.pageSize));
			//mui.alert(para.pageNo);
			if (++para.pageNo > Math.ceil(data.info.total/para.pageSize)) {
				mui('#pullrefresh').pullRefresh().endPullupToRefresh(true); //加载完毕
			} else {
				mui('#pullrefresh').pullRefresh().endPullupToRefresh(false); //还有更多数据
			}
		}
	}, function() {
		//mui('#pullrefresh').pullRefresh().endPullupToRefresh(false);
	}, function() {
		plus.nativeUI.closeWaiting();
	});
}