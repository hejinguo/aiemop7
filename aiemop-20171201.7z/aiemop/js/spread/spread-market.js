mui.init({
	subpages: [{
		url: 'spread-market-pull.html',
		id: 'page-spread-market-pull',
		styles: {
			top: '44px',
			bottom: '0px',
		}
	}]
});
mui.plusReady(function() {
	var self = plus.webview.currentWebview();
	//mui.alert(self.mkt_type);
	setTimeout(function() {
		mui.fire(plus.webview.getWebviewById('page-spread-market-pull'), 'initParamMktId', {
			mktId: self.mkt_type
		});
	}, 1500);
	/*
	 * 下一步操作按钮
	 */
	var btn_next_step = document.getElementById("next_step_button");
	btn_next_step.addEventListener("tap", function() {
		var pull = plus.webview.getWebviewById('page-spread-market-pull');
		pull.evalJS("next_step()");
		/*var mkt_id = pull.document.getElementById("lbl_mkt_id").innerHTML;
		var mkt_name = document.getElementById("lbl_mkt_name").innerHTML;
		if (mkt_id && mkt_name) {
			ai.openWindow({
				url: "spread-way.html",
				id: "page-spread-way",
				extras: {
					mkt_id: mkt_id,
					mkt_name: mkt_name
				}
			});
		} else {
			mui.toast('请选择活动！');
		}*/
	});
});