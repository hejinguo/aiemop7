mui.init({
	pullRefresh: {
		container: '#mkt_list',
		up: {
			callback: pullupRefresh
		}
	},
	gestureConfig: {
		tap: true, //默认为true
		doubletap: true, //默认为false
		longtap: true, //默认为false
		swipe: true, //默认为true
		drag: true, //默认为true
		hold: false, //默认为false，不监听
		release: false //默认为false，不监听
	}
});
var param = {
	pageNo: 1,
	pageSize: 10
};
mui.plusReady(function() {
	window.addEventListener('initParamMktId', function(event) {
		param.mktType = event.detail.mktId;
	});
	//加载可以推广的活动明细
	loadSpreadMarket();
	//搜索事件
	searchMarket();
	/*
	 * 预选择活动
	 */
	mui(".mui-scroll>.mui-table-view").on("tap", "div", function(e) {
		chooseMarket(this);
	});
	/**
	 * 长按活动选项卡事件
	 */
	mui(".mui-scroll>.mui-table-view").on("longtap", "div", function(e) {
		chooseMarket(this);
		next_step();
	});
});
/**
 * 搜索事件
 */
function searchMarket() {
	document.querySelector('form').addEventListener('submit', function(e) {
		e.preventDefault(); // 阻止默认事件
		var searchInputBox = mui('.mui-input-clear')[0];
		searchInputBox.blur();
		param.marketName = searchInputBox.value;
		mui('#mkt_list').pullRefresh().refresh(true); //重置上拉加载
		loadSpreadMarket();
	});
}

/*
 * 加载可以推广的活动明细
 */
function loadSpreadMarket() {
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	document.body.querySelector('.mui-scroll>.mui-table-view').innerHTML = '';
	param.pageNo = 1;
	pullupRefresh();	
	//mui('#mkt_list').pullRefresh().scrollTo(0,0,100);
	//每次加载重置已选择活动
	document.getElementById("lbl_check_id").innerHTML="";
}

/*
 * * 参数：选择的活动类型
 * 
 */
function pullupRefresh() {
	setTimeout(function() {
		ai.ajax("spread/chooseMarketActivities", param, function(data) {
			if (data.state) {
				var mkt_list = document.body.querySelector(".mui-scroll>.mui-table-view");
				mui.each(data.info.rows, function(index, item) {
					var li = document.createElement('li');
					/*li.className = 'mui-table-view-cell';
					var mkt_div = document.createElement('div');
					mkt_div.className = "mui-card";
					mkt_div.id = "mkt_id" + item.MKT_ID;
					mkt_div.setAttribute("mkt_id", item.MKT_ID);
					mkt_div.setAttribute("mkt_name", item.MKT_NAME);*/
					if (!item.MKT_CONTENT) {
						item.MKT_CONTENT = "无";
					}
					li.innerHTML = '<div class="mui-card" id="mkt_id' + item.MKT_ID + '" mkt_id="' + item.MKT_ID + '" mkt_name="' + item.MKT_NAME + '" is_target="'+item.IS_TARGET+'" >' +
						'<h4 class="mui-ellipsis">' + item.MKT_NAME + '</h4>' +
						'<h5 class="mui-ellipsis">活动时间：' + item.MKT_BEGIN_TIME + '~' + item.MKT_END_TIME + '</h5>' +
						'<h5 class="mui-ellipsis">活动地域：' + item.ORG_NAME + '</h5>' +
						'<h5 class="mui-ellipsis">活动描述：' + item.MKT_CONTENT + '</h5></div>';
					mkt_list.appendChild(li);

				});
				mui.toast('共' + data.info.total + '条记录,已加载' + (param.pageNo * param.pageSize > data.info.total ? '完毕' : param.pageNo * param.pageSize + '条'));
				if (++param.pageNo > Math.ceil(data.info.total / param.pageSize)) {
					mui('#mkt_list').pullRefresh().endPullupToRefresh(true); //加载完毕
				} else {
					mui('#mkt_list').pullRefresh().endPullupToRefresh(false); //还有更多数据
				}
			}
		}, function() {

		}, function() {
			plus.nativeUI.closeWaiting();
		});
	}, 1500);
}

/**
 * 点击下一步按钮
 */
function next_step() {
	var mkt_id = document.getElementById("lbl_mkt_id").innerHTML;
	var mkt_name = document.getElementById("lbl_mkt_name").innerHTML;
	var is_target = document.getElementById("lbl_is_target").innerHTML;
	//mui.alert(is_target);
	if (mkt_id && mkt_name) {
		ai.openWindow({
			url: "spread-way.html",
			id: "page-spread-way",
			extras: {
				mkt_id: mkt_id,
				mkt_name: mkt_name,
				is_target:is_target
			}
		});
	} else {
		mui.toast('请选择活动！');
	}
}
/**
 * 活动选项卡选中事件
 * @param {Object} choose_div
 */
function chooseMarket(choose_div) {
	//如果已选择过，清除上次选择活动的样式
	var check_id = document.getElementById("lbl_check_id").innerHTML;
	if (check_id) {
		document.getElementById(check_id).classList.remove("list_check");
	}
	//记录当前选择的活动编号和名称
	document.getElementById("lbl_mkt_id").innerHTML = choose_div.getAttribute('mkt_id');
	document.getElementById("lbl_mkt_name").innerHTML = choose_div.getAttribute('mkt_name');
	document.getElementById("lbl_check_id").innerHTML = choose_div.getAttribute('id');
	document.getElementById("lbl_is_target").innerHTML = choose_div.getAttribute('is_target');
	//修改当前被选择活动的样式
	choose_div.classList.add("list_check");
}