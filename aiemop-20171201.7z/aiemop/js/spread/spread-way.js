mui.init({
	swipeBack: false,
	gestureConfig: {
		tap: true, //默认为true
		doubletap: true, //默认为false
		longtap: true, //默认为false
		swipe: true, //默认为true
		drag: true, //默认为true
		hold: false, //默认为false，不监听
		release: false //默认为false，不监听
	}
});

mui.plusReady(function() {
	var self = plus.webview.currentWebview();
	var mkt_id = self.mkt_id;
	var mkt_name = self.mkt_name;
	var is_target = self.is_target;
	document.body.querySelector('#mkt_name').innerText = mkt_name;

	mui("#way_grid").on("tap", "a", function() {
		choose_way(this, is_target);
	});
	/**
	 * 推广方式长按事件；
	 */
	mui("#way_grid").on("longtap", "a", function() {
		choose_way(this, is_target);
		next_step(mkt_id, mkt_name, is_target);
	});
	/*
	 * 下一步操作按钮
	 */
	var btn_next_step = document.getElementById("next_step_button");
	btn_next_step.addEventListener("tap", function() {
		next_step(mkt_id, mkt_name, is_target);
	});
});

/**
 * 下一步操作
 */
function next_step(mkt_id, mkt_name) {
	var choose_id = document.getElementById("lbl_way_id").innerHTML;
	if (choose_id == "way_msg" || choose_id == "way_phone" || choose_id == "way_1008688") {
		ai.openWindow({
			url: "spread-mbr.html",
			id: "page-spread-mbr",
			extras: {
				mkt_id: mkt_id,
				mkt_name: mkt_name,
				way_id: choose_id
			}
		});
	} else if (choose_id == "way_weixin" || choose_id == "way_pengyouquan" || choose_id == "way_qq") {
		ai.openWindow({
			url: "spread-confirm.html",
			id: "page-spread-confirm",
			extras: {
				mkt_id: mkt_id,
				mkt_name: mkt_name,
				group_id: -1000,
				way_id: choose_id
			}
		});
	} else {
		if (is_target == '1') {
			mui.toast('请选择推广方式！');
		}
	}
}

function choose_way(wayGrid, is_target) {
	var check_last = document.getElementById("lbl_check_way").innerHTML;
	if (check_last) {
		document.getElementById(check_last).classList.remove("list_check");
	}
	document.getElementById("lbl_way_id").innerHTML="";
	var check_now = wayGrid.getAttribute('id');
	if (is_target == '0' && (check_now == "way_msg" || check_now == "way_phone" || check_now == "way_1008688")) {
		mui.toast("没有目标客户群，只能选择网络推广！");
	} else {
		document.getElementById("lbl_way_id").innerHTML = wayGrid.getAttribute('id');
		document.getElementById("lbl_check_way").innerHTML = check_now;
		document.getElementById(check_now).classList.add("list_check");
	}
}