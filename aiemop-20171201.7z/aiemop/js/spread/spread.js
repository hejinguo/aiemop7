mui.init({
	swipeBack: false
});

mui.plusReady(function() {
	//    		打开消息页面
	/*document.getElementById("showmessage-button").addEventListener('tap', function() {
		var mainPage = plus.webview.currentWebview().opener();
		mui.fire(mainPage, "main:showMessage");
	});*/
	//计算高度
	//mui.alert(plus.screen.resolutionHeight+" "+plus.screen.resolutionWidth+"   "+plus.display.resolutionHeight+" "+plus.display.resolutionWidth,"hello");
	//var item_height = (plus.display.resolutionHeight - 44) / 2 - 220;
	//var spread_un = document.getElementById('market_unextension');
	//spread_un.style.marginTop = item_height + "px";
	//
	//var item_width = plus.display.resolutionWidth - 330;
	//var un_float_right = document.getElementById('un_float_right');
	//un_float_right.style.marginRight = item_width + "px";
	//var float_right = document.getElementById('float_right');
	//float_right.style.marginRight = item_width + "px";
	//加载推广情况数据
	loadSpreadData();
	//圆形按钮点击事件
	mui('.mui-content').on('tap', '.spred_show', function(e) {
		var spread_0_num=document.getElementById("un_lbl_num").innerText;
		if (this.getAttribute('id') == 'market_unextension') {
			if(spread_0_num>0){
				ai.openWindow({
					url: 'spread-market.html',
					id: 'page-spread-market',
					extras: {
						mkt_type: ''
					},
					styles: {
						bounce: 'vertical',
						popGesture: 'close'
					}
				});
			}else{
				mui.toast("没有活动可以推广！");
			}
		} else if (this.getAttribute('id') == 'market_extensioned') {
			ai.openWindow({
				url: 'spread-history.html',
				id: 'page-spread-history',
				extras: {
					mkt_type: ''				
				},
				styles: {
					popGesture: 'close'
				}
			});
		}
	});
	//未推广活动分类按钮点击事件
	mui("#un_ul_list").on('tap', 'li', function(e) {
		var mkt_type_id = this.getAttribute("mkt_type_id");
		if (mkt_type_id) {
			ai.openWindow({
				url: 'spread-market.html',
				id: 'page-spread-market',
				extras: {
					mkt_type: mkt_type_id				
				},
				styles: {
					bounce: 'vertical',
					popGesture: 'close'
				}
			});
		}
	});
	//已推广活动分类按钮点击事件
	mui("#ul_list").on('tap', 'li', function(e) {
		var mkt_type_id = this.getAttribute("mkt_type_id");
		ai.openWindow({
			url: 'spread-history.html',
			id: 'page-spread-history',
			extras: {
				mkt_type: mkt_type_id				
			},
			styles: {
				popGesture: 'close'
			}
		});
	});
});
var spread_0_all = 0; //未推广总数
var spread_1_all = 0; //已推广总数
function loadSpreadData(){
	var spread_0 = 0;
	var spread_1 = 0;
	//绑定数值
	var param = {};
	ai.ajax("spread/defaulSpreadREC", param, function(data) {
		if (data.state) {
			var un_ul_list = document.body.querySelector("#un_ul_list");
			var ul_list = document.body.querySelector("#ul_list");
			un_ul_list.innerHTML = "";
			ul_list.innerHTML = "";
			mui.each(data.info, function(index, item) {
				//mui.alert(item.SPREAD_STATE);
				//未推广
				if (item.SPREAD_STATE == 0) {
					spread_0 = spread_0 + item.MKT_NUM;
					var un_li_list = document.createElement('li');
					un_li_list.setAttribute("mkt_type_id", item.MKT_TYPE);
					un_li_list.setAttribute("mkt_num", item.MKT_TYPE_NAME);
					un_li_list.innerHTML ='<h5>'+item.MKT_TYPE_NAME + '：' + item.MKT_NUM+'</h5>';
					un_ul_list.appendChild(un_li_list);
				} else if (item.SPREAD_STATE == 1) {
					spread_1 = spread_1 + item.MKT_NUM;
					var li_list = document.createElement('li');
					li_list.setAttribute("mkt_type_id", item.MKT_TYPE);
					li_list.innerHTML = '<h5>'+item.MKT_TYPE_NAME + '：' + item.MKT_NUM+'</h5>';
					ul_list.appendChild(li_list);
				}
			});
			if (spread_0 == 0) {
				un_ul_list.innerHTML = "<li><h5>存送：0</h5></li><li><h5>终端：0</h5></li>" +
					"<li><h5>裸机：0</h5></li><li>其他：0</h5></li>";
			}
			if (spread_1 == 0) {
				ul_list.innerHTML = "<li><h5>存送：0</h5></li><li><h5>终端：0</h5></li>" +
					"<li><h5>裸机：0</h5></li><li><h5>其他：0</h5></li>";
			}
			document.getElementById("un_lbl_num").innerText = spread_0;
			document.getElementById("lbl_num").innerText = spread_1;
		}
	},function(){
		
	},function(){
		spread_0_all=spread_0;
		spread_1_all=spread_1;
	});
	ai.ajax("spread/getSpreadRecCount", param, function(data) {
		if (data.state) {
			document.getElementById("lbl_count").innerText = data.info;
		}
	},function(){
		
	},function(){
		
	});
}
