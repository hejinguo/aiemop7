mui.init({
	swipeBack: false,
	beforeback: function() {
		var lbl_unit_id=document.body.querySelector('#lbl_unit_id').innerText;
		var lbl_group_id=document.body.querySelector('#lbl_group_id').innerText;
		var pull = plus.webview.getWebviewById('page-spread-mbr');
		pull.evalJS("getChangeUser("+lbl_group_id+","+lbl_unit_id+",'"+delete_id.toString()+"')");
		var this_page = plus.webview.getWebviewById('page-spread-mbruser');
		this_page.close();
	}
});
var arr = [{
	way_id: "way_msg",
	way_name: "本机短信"
}, {
	way_id: "way_phone",
	way_name: "语音外呼"
}, {
	way_id: "way_1008688",
	way_name: "1008688"
}, {
	way_id: "way_weixin",
	way_name: "微信"
}, {
	way_id: "way_pengyouquan",
	way_name: "朋友圈"
}, {
	way_id: "way_qq",
	way_name: "QQ"
}];
var page_no = 1;
var page_size = 10;
var page_num=0;//总页数
var delete_id=new Array();//记录需要删除的用户
var group_id=0;
mui.plusReady(function() {
	var self = plus.webview.currentWebview();
	var mkt_id = self.mkt_id;
	var mkt_name = self.mkt_name;
	var way_id = self.way_id;
	unit_id=self.unit_id;
	var way_name;
	for (var i in arr) {
		if (arr[i].way_id == way_id) {
			way_name = arr[i].way_name;
		}
	}
	//已删除过的用户
	var delete_id_old=self.delete_id_no;
	//mui.alert(delete_id_old);
	if(delete_id_old&&delete_id_old!=""){
		delete_id=delete_id_old.split(',');
	}else{
		delete_id=new Array();
	}
	group_id=self.group_id
	//mui.alert(delete_id);
	/**
	 * 顶部显示内容
	 */
	document.body.querySelector('#lbl_unit_id').innerText = self.unit_id;
	document.body.querySelector('#lbl_group_id').innerText = self.group_id;
	document.body.querySelector('#mkt_name').innerText = mkt_name;
	document.body.querySelector('#way_name').innerText = way_name;
	/*
	 * 根据活动ID列出目标客户
	 */
	loadMbrUser(self.unit_id, mkt_id, self.group_id, page_no, page_size);
	/*
	 * 确认按钮操作
	 */
	var btn_next = document.getElementById("next_step_button");
	btn_next.addEventListener("tap", function() {
		//如果没有取消用户，直接返回上一页
		//如果有取消的用户，则返回取消用户的明细
		mui.back();
	});
	/**
	 * 分页按钮点击事件
	 */
	mui('.mui-pagination').on('tap', 'a', function() {
		var li = this.parentNode;
		var classList = li.classList;
		if (!classList.contains('mui-active') && !classList.contains('mui-disabled')) {
			var active = li.parentNode.querySelector('.mui-active');
			if (classList.contains('mui-previous')) { //previous
				if (active) {
					var previous = active.previousElementSibling;
					console.log('previous', previous);
					if (previous && !previous.classList.contains('mui-previous')) {
						mui.trigger(previous.querySelector('a'), 'tap');
					} else {
						classList.add('mui-disabled');
					}
				}
			} else if (classList.contains('mui-next')) { //next
				if (active) {
					var next = active.nextElementSibling;
					if (next && !next.classList.contains('mui-next')) {
						mui.trigger(next.querySelector('a'), 'tap');
					} else {
						classList.add('mui-disabled');
					}
				}
			} else { //点击数字
				active.classList.remove('mui-active');
				classList.add('mui-active');
				var page = parseInt(this.innerText);
				var previousPageElement = li.parentNode.querySelector('.mui-previous');
				var nextPageElement = li.parentNode.querySelector('.mui-next');
				previousPageElement.classList.remove('mui-disabled');
				nextPageElement.classList.remove('mui-disabled');
				if (page <= 1) {
					previousPageElement.classList.add('mui-disabled');
				} else if (page >= page_num) {
					nextPageElement.classList.add('mui-disabled');
				}
				loadMbrUser(self.unit_id, mkt_id, self.group_id, page, page_size);
			}
		}
	});
	mui("#user_list").on("change", "input[name='subcheck']", function() {
		var del_id_no=this.getAttribute("idno");
		if(this.checked){
			delete_id.shift(del_id_no);
		}else{
			delete_id.unshift(del_id_no);
		}
		//mui.alert(delete_id.toString(),"dfdfd");
	});
});

/**
 * 加载页码
 */
function initUserPage(page_num) {
	var user_list_page = document.body.querySelector("#user_list_page");
	var page_html = '<li class="mui-previous mui-disabled"><a href="#">&laquo;</a></li><li class="mui-active"><a href="#">1</a></li>';				
	for (var i = 2; i <= page_num; i++) {
		page_html += '<li><a href="#">' + i + '</a></li>';
	}
	page_html += '<li class="mui-next"><a href="#">&raquo;</a></li>';
	user_list_page.innerHTML = page_html;
}

/**
 * 加载活动
 * @param {Object} unit_id
 * @param {Object} mkt_id
 * @param {Object} group_id
 * @param {Object} page_no
 * @param {Object} page_size
 */
function loadMbrUser(unit_id, mkt_id, group_id, page_no, page_size) {
	var param = {
		pageNo: page_no,
		pageSize: page_size,
		unitId:unit_id,
		groupId:group_id,
		mktId:mkt_id
	};
	//mui.alert(param.groupId+'df'+param.unitId+'dsd'+param.mktId,"hello");
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	ai.ajax("spread/checkUnitUser", param, function(data) {
		if (data.state) {
			var user_list = document.body.querySelector("#user_ul_list");
			user_list.innerHTML="";
			mui.each(data.info.rows, function(index, item) {
				//判断该元素是否在删除列表 中
				var init_check='checked="true"';
				if(delete_id.toString().indexOf(item.ID_NO)>=0){
					init_check="";
				}
				var user_li = document.createElement("li");
				user_li.className = "mui-table-view-cell mui-checkbox mui-left";
				user_li.innerHTML = '<input name="subcheck" idno="'+item.ID_NO+'"  type="checkbox" '+init_check+' >' +
					'<h5>' + item.PHONE_NO + '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' + item.USER_NAME + '</h5>';
				user_list.appendChild(user_li);
			});
			//初始加载页码
			if(page_no==1){
				page_num=Math.ceil(data.info.total/page_size);
				initUserPage(page_num);
			}
			
		}
	}, function() {

	}, function() {
		plus.nativeUI.closeWaiting();
	});
}