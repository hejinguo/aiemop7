mui.init({
	swipeBack: false,
	beforeback: function() {
		var page_market = plus.webview.getWebviewById("page-spread-market");
		if (page_market)
			page_market.close();
		var page_way = plus.webview.getWebviewById("page-spread-way");
		if (page_way)
			page_way.close();
		var page_mbr = plus.webview.getWebviewById("page-spread-mbr");
		if (page_mbr)
			page_mbr.close();
		var page_mbruser = plus.webview.getWebviewById("page-spread-mbruser");
		if (page_mbruser)
			page_mbruser.close();
		var page_confirm = plus.webview.getWebviewById("page-spread-confirm");
		if (page_confirm)
			page_confirm.close();
		var page_his= plus.webview.getWebviewById("page-spread-history");
		if (page_his)
			page_his.close();	
		var page_pull= plus.webview.getWebviewById("page-spread-history-pull");
		if (page_pull)
			page_pull.close();	
		var pull = plus.webview.getWebviewById('page-spread');
		pull.evalJS("loadSpreadData()");
	},
	subpages: [{
		url: 'spread-history-pull.html',
		id: 'page-spread-history-pull',
		styles: {
			top: '45px',
			bottom: '0px',
		}
	}]
});
var way_arr = [{
	way_idint: 1,
	way_id: "way_msg",
	way_name: "本机短信"
}, {
	way_idint: 2,
	way_id: "way_phone",
	way_name: "语音外呼"
}, {
	way_idint: 3,
	way_id: "way_1008688",
	way_name: "1008688"
}, {
	way_idint: 4,
	way_id: "way_weixin",
	way_name: "微信"
}, {
	way_idint: 5,
	way_id: "way_pengyouquan",
	way_name: "朋友圈"
}, {
	way_idint: 6,
	way_id: "way_qq",
	way_name: "QQ"
}];
mui.plusReady(function() {
	/*
	 * 加载历史记录
	 */
	var self = plus.webview.currentWebview();
	var curr_mkt_type=self.mkt_type;
	if(!curr_mkt_type){
		curr_mkt_type='';
	}
	setTimeout(function() {
		mui.fire(plus.webview.getWebviewById('page-spread-history-pull'), 'initParamMktType', {
			mktType: curr_mkt_type
		});
	}, 1500);
});

/*function loadSpreadHis() {
	var para = {};
	ai.ajax("spread/selectSpreadRec", para, function(data) {
		if (data.state) {
			var his_list = document.body.querySelector("#his_list");
			var length = 0;
			mui.each(data.info, function(index, item) {
				length = index + 1;
				//推广方式名称
				var way_name = '';
				for (var i in way_arr) {
					if (way_arr[i].way_idint == item.SPREAD_WAY) {
						way_name = way_arr[i].way_name;
					}
				}
				var group_name = item.GROUP_NAME;
				if (!group_name) {
					group_name = "无";
				}
				//是否完全推广
				var mkt_div = document.createElement("div");
				var class_list_name = "mkt_spread_finish";
				if (item.SPREADFINISH == "1" && item.SPREAD_WAY != "4" && item.SPREAD_WAY != "5" && item.SPREAD_WAY != "6") {
					class_list_name = "mkt_spread_part";
				}
				mkt_div.className = "mui-card " + class_list_name;
				mkt_div.setAttribute("rec_id", item.REC_ID);
				mkt_div.innerHTML = '<h4 class="mui-ellipsis" style="width:80%">' + item.MKT_NAME + '</h4>' +
					'<h5 class="mui-ellipsis">活动地域：' + item.ORG_NAME + '</h5>' +
					'<h5 class="mui-ellipsis">活动时间：' + item.MKT_BEGIN_TIME + '~' + item.MKT_END_TIME + '</h5>' +
					'<h5 class="mui-ellipsis">目标客户群：' + group_name + '</h5>' +
					'<h5 class="mui-ellipsis">推广渠道：' + way_name + '</h5>';
				his_list.appendChild(mkt_div);
			});
			if (length <= 0) {
				his_list.innerHTML = '<div class="mui-card" style="text-align: center;">还没有记录，赶快推广吧！</div>';
			}
		}
	}, function() {

	}, function() {

	});
}*/