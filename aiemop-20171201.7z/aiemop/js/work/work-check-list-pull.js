mui.init({
	pullRefresh: {
		container: '#pullup-container',
		up: {
			contentrefresh: '正在加载...',
			callback: _pullupRefresh
		}
	}
});

var app = null;
var param = {unitIdName:'',pageNum:1,pageSize:10};

mui.plusReady(function() {
	app = new Vue({
		el: '#mui-work-check-vid',
		data: {
			checks: []
		},
		created:_vue_created,
		methods: {
			clickCheckItem:_vue_clickCheckItem
		}
	});
});

function _vue_created(){
	//初始化搜索框事件
	mui('span.mui-placeholder')[0].addEventListener('tap',function(e){
		mui('.mui-input-clear')[0].focus();
	});
	document.querySelector('form').addEventListener('submit', function(e){
	    e.preventDefault(); // 阻止默认事件
	    var searchInputBox = mui('.mui-input-clear')[0];
	    searchInputBox.blur();
		param.unitIdName = searchInputBox.value;
		mui('#pullup-container').pullRefresh().refresh(true);//重置上拉加载
		loadWorkCheck();
	});
	//加载集团列表数据
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	_pullupRefresh();
	//自定义重新加载并刷新列表信息的事件
	window.addEventListener('_writeCheckSuggestCallBack',function(event){
		plus.webview.getWebviewById(event.detail.webviewId).close();
		loadWorkCheck();
	});
	//自定义修改商机档案后关闭填报窗口的事件
	window.addEventListener('_templateWriteCallBack',function(event){
		plus.webview.getWebviewById(event.detail.webviewId).close();
	});
}

/**
 * 点击集团列表项目
 */
function _vue_clickCheckItem(write){
	plus.nativeUI.actionSheet({
//		title:"操作选择",
		cancel:"取消",
		buttons:[{title:'查看填报内容'},{title:'提交处理结果'},{title:'编辑商机档案'}]
	}, function(e){
		var index = e.index;
		if(e.index > 0){
			var extras = {};
			switch (e.index){
				case 1://查看填报内容
					extras={
						unitId:write.unit.unitId,
						unitName:write.unit.unitName,
						writeId:write.writeId};
					_open_commonTemplateRecordWindow(extras);
					break;
				case 2://提交处理结果
					extras={
						unitId:write.unit.unitId,
						unitName:write.unit.unitName,
						writeId:write.writeId};
					_open_commonTemplateSuggestWindow(extras);
					break;
				case 3://编辑商机档案
					extras={
						unitId:write.unit.unitId,
						unitName:write.unit.unitName,
						modifyWriteId:write.writeArchive.writeId};
					_open_commonTemplateWrtieWindow(extras);
					break;
				default:
					mui.toast('尚未实现的功能.');
					break;
			}
		}
	});
}

/**
 * 加载数据(搜索或初始化页面时)
 */
function loadWorkCheck(){
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	if(app){app.checks = [];}
	param.pageNum = 1;
	_pullupRefresh();
	if(mui.os.ios){
		plus.webview.currentWebview().evalJS("mui('#pullup-container').pullRefresh().scrollTo(0,0,100)");
	}else{
		plus.webview.currentWebview().evalJS('mui.scrollTo(0, 100)');
	}
}

/**
 * 上拉加载更多数据
 */
function _pullupRefresh() {
	setTimeout(function() {
		ai.ajax(ai.appPathObject.work + 'check/getWaitingRecord',param,function(data){
			if(data.state){
				app.checks = app.checks.concat(data.info.list)
				mui.toast('共'+data.info.total+'条记录,已加载'+(app.checks.length == data.info.total ? '完毕':app.checks.length+'条'));
				if(data.info.hasNextPage){
					mui('#pullup-container').pullRefresh().endPullupToRefresh(false);//还有更多数据
					param.pageNum++;
				}else{
					mui('#pullup-container').pullRefresh().endPullupToRefresh(true);//加载完毕
				}
			}
		},function(){
			mui('#pullup-container').pullRefresh().endPullupToRefresh(false);//还有更多数据
		},function(){
			plus.nativeUI.closeWaiting();
		});
	}, 1500);
}

/**
 * 通用的打开结果窗口页面的方法
 */
function _open_commonTemplateRecordWindow(extras){
	ai.openWindow({
		url:"./template/record.html",
		id:"page-work-template-record",
		extras:extras
	});
}

/**
 * 通用的打开意见反馈窗口页面的方法
 */
function _open_commonTemplateSuggestWindow(extras){
	ai.openWindow({
		url:"./work-check-suggest.html",
		id:"page-work-check-suggest",
		extras:extras
	});
}

/**
 * 通用的打开填报窗口页面的方法
 */
function _open_commonTemplateWrtieWindow(extras){
	ai.openWindow({
		url:"./template/write.html",
		id:"page-work-template-write",
		extras:extras
	});
}