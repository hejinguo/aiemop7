var app = null;
var pdata = {unit:{unitId:'',unitName:''},writeId:'',archiveId:'',auditState:''};

mui.plusReady(function() {
	app = new Vue({
		el: '#mui-work-audit-record-vid',
		data: {
			records:[],
			auditState:''
		},
		created:_vue_created,
		methods: {

		}
	});
});

function _vue_created(){
	var self = plus.webview.currentWebview();
	pdata.unit={unitId:self.unitId,unitName:self.unitName};
	pdata.writeId = self.writeId;
	pdata.archiveId = self.archiveId;
	pdata.auditState = self.auditState;
	this.auditState = pdata.auditState;
	mui('.mui-title')[0].innerHTML = pdata.unit.unitName;
	_loadWorkAuditRecord();
}

/**
 * 加载审批记录
 */
function _loadWorkAuditRecord(){
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	ai.ajax(ai.appPathObject.work + 'audit/getAuditRecord',{archiveId:pdata.archiveId},function(data){
		if(data.state){
			app.records = data.info;
//			app.records.push({auditStateDesc:'提交创建商机审批流程',auditTime:new Date(),auditDesc:'1111',auditState:110,auditCode:'zs',user:{staffName:'张三',phoneNo:'13333333333'}});
//			app.records.push({auditStateDesc:'创建商机由地市审批时驳回',auditTime:new Date(),auditDesc:'222',auditState:111,auditCode:'ls',user:{staffName:'李四',phoneNo:'13444444444'}});
//			app.records.push({auditStateDesc:'创建商机省级审批通过并结束创建流程',auditTime:new Date(),auditDesc:'222',auditState:130,auditCode:'ww',user:{staffName:'王五',phoneNo:'13555555555'}});
		}
	},function(){},function(){
		plus.nativeUI.closeWaiting();
	});
}