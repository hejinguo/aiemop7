var app = null;
var pdata = {
	unit:{unitId:'',unitName:''},
	moreparam : {archive:{templateCode:'BUILD_ARCHIVE',pageNum:1,pageSize:10},
				workplan:{templateCode:'WORK_PLAN',pageNum:1,pageSize:10}}//商机列表和工作计划分页参数
};

mui.plusReady(function() {
	app = new Vue({
		el: '#mui-work-unit-vid',
		data: {
			info:{archive:{},workplan:{}}//加载集团的更多挂牌信息
		},
		created:_vue_created,
		methods: {
			clickCreateCommonWorkPlan:_vue_clickCreateCommonWorkPlan,
			clickUnitProductItem:_vue_clickUnitProductItem,
			clickUnitArchiveItem:_vue_clickUnitArchiveItem,
			clickUnitWorkplanItem:_vue_clickUnitWorkplanItem,
			clickChangeWritePageNumBtn:_vue_clickChangeWritePageNumBtn
		}
	});
});

function _vue_created(){
	var self = plus.webview.currentWebview();
	pdata.unit={unitId:self.unitId,unitName:self.unitName};
	mui('.mui-title')[0].innerHTML = pdata.unit.unitName;
	_vue_loadUnitMore();
//	自定义重新加载并刷新集团相关信息的事件
	window.addEventListener('_templateWriteCallBack',function(event){
		plus.webview.getWebviewById(event.detail.webviewId).close();
		_vue_loadUnitMore();
	});
}

/**
 * 加载集团更多挂牌信息
 */
function _vue_loadUnitMore(){
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	ai.ajax(ai.appPathObject.work + 'unit/more',{unitId:pdata.unit.unitId,pageSize:pdata.moreparam.archive.pageSize},function(data){
		if(data.state){
			app.info = data.info;
		}
	},function(){},function(){
		plus.nativeUI.closeWaiting();
	});
}

/**
 * 创建普通工作计划
 */
function _vue_clickCreateCommonWorkPlan(){
	var extras = {//创建普通工作计划
		unitId:pdata.unit.unitId,
		unitName:pdata.unit.unitName,
		templateCode:'WORK_PLAN'};
	_open_commonTemplateWriteWindow(extras);
//	mui('#popover').popover('show');
}

/**
 * 单击集团攻坚产品条目
 */
function _vue_clickUnitProductItem(item){
	plus.nativeUI.actionSheet({
//		title:"操作选择",
		cancel:"取消",
		buttons:[{title:'创建产品商机'}]
	}, function(e){
		var index = e.index;
		if(e.index > 0){//创建产品商机
			var extras = {
				unitId:pdata.unit.unitId,
				unitName:pdata.unit.unitName,
				templateCode:'BUILD_ARCHIVE',
				productId:item.productId,
				productName:item.productName
			};
			_open_commonTemplateWriteWindow(extras);
		}
	});
}

/**
 * 单击集团商机档案条目
 */
function _vue_clickUnitArchiveItem(item){
	plus.nativeUI.actionSheet({
//		title:"操作选择",
		cancel:"取消",
		buttons:[{title:'创建工作计划'},{title:'申请商机归档'},{title:'查看商机信息'},{title:'查看审批流程'}]
	}, function(e){
		var index = e.index;
		if(e.index > 0){
			var extras = {};
			switch (e.index){
				case 1://创建工作计划
					extras = {
						unitId:pdata.unit.unitId,
						unitName:pdata.unit.unitName,
						templateCode:'WORK_PLAN',
						archiveId:item.writeArchive.archiveId};
					_open_commonTemplateWriteWindow(extras);
					break;
//				case 2://申请商机归档
//					mui.toast(JSON.stringify(item));
//					break;
				case 3://查看商机信息
					extras={
						unitId:pdata.unit.unitId,
						unitName:pdata.unit.unitName,
						writeId:item.writeId};
					_open_commonTemplateRecordWindow(extras);
					break;
				case 4://查看审批流程
					extras={
						unitId:pdata.unit.unitId,
						unitName:pdata.unit.unitName,
						archiveId:item.writeArchive.archiveId,
						auditState:item.writeArchive.auditState,
						writeId:item.writeId};
					_open_commonAuditRecordWindow(extras);
					break;
				default:
					mui.toast('尚未实现的功能.');
					break;
			}
		}
	});
}

/**
 * 单击工作计划列表条目
 */
function _vue_clickUnitWorkplanItem(item){
	var buttons = [{title:item.childWriteId.length > 0 ? '查看工作反馈' : '反馈工作结果'},{title:'查看工作计划'}];
	if(item.checkRecord && item.checkRecord.length > 0){
//		writeId:item.childWriteId[0]};
		buttons.push({title:'查看工作建议'});
	}
	plus.nativeUI.actionSheet({
//		title:"操作选择",
		cancel:"取消",
		buttons:buttons
	}, function(e){
		var index = e.index;
		if(e.index > 0){
			var extras = {};
			switch (e.index){
				case 1://查看工作反馈 or 反馈工作结果
					if(item.childWriteId.length > 0){//查看反馈结果
						extras={
							unitId:pdata.unit.unitId,
							unitName:pdata.unit.unitName,
							writeId:item.childWriteId[0]};
						_open_commonTemplateRecordWindow(extras);
					}else{//反馈工作结果
						extras = {
							unitId:pdata.unit.unitId,
							unitName:pdata.unit.unitName,
							templateCode:'WORK_FEEDBACK',
							parentWriteId:item.writeId};
						if(item.writeArchive){
							extras.productId = item.writeArchive.productId;
							extras.productName = item.writeArchive.productName;
						}
						_open_commonTemplateWriteWindow(extras);
					}
					break;
				case 2://查看工作计划
					extras={
						unitId:pdata.unit.unitId,
						unitName:pdata.unit.unitName,
						writeId:item.writeId};
					_open_commonTemplateRecordWindow(extras);
					break;
				case 3://查看工作建议
					extras={
						unitId:pdata.unit.unitId,
						unitName:pdata.unit.unitName,
						writeId:item.childWriteId[0]};
					_open_commonCheckRecordWindow(extras);
					break;
				default:
//					mui.toast(JSON.stringify(item));
					mui.toast('尚未实现的功能.');
					break;
			}
		}
	});
}

/**
 * 点击分页查询填报信息页面
 */
function _vue_clickChangeWritePageNumBtn(pageNum,writeWay){
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	pdata.moreparam[writeWay].pageNum = pageNum;
	pdata.moreparam[writeWay].unitId = pdata.unit.unitId;
	ai.ajax(ai.appPathObject.work + 'unit/getWriteRecord',pdata.moreparam[writeWay],function(data){
		if(data.state){
//			mui.alert(JSON.stringify(data.info));
			app.info[writeWay] = data.info;
		}
	},function(){},function(){
		plus.nativeUI.closeWaiting();
	});
}

/**
 * 通用的打开填报窗口页面的方法
 */
function _open_commonTemplateWriteWindow(extras){
	ai.openWindow({
		url:"./template/write.html",
		id:"page-work-template-write",
		extras:extras
	});
}

/**
 * 通用的打开结果窗口页面的方法
 */
function _open_commonTemplateRecordWindow(extras){
	ai.openWindow({
		url:"./template/record.html",
		id:"page-work-template-record",
		extras:extras
	});
}

/**
 * 通用的打开审批记录窗口页面的方法
 */
function _open_commonAuditRecordWindow(extras){
	ai.openWindow({
		url:"./work-audit-record.html",
		id:"page-work-audit-record",
		extras:extras
	});
}

/**
 * 通用的打开工作建议记录窗口页面的方法
 */
function _open_commonCheckRecordWindow(extras){
	ai.openWindow({
		url:"./work-check-record.html",
		id:"page-work-check-record",
		extras:extras
	});
}
