mui.init({
//	statusBarBackground: '#0085d0',
	pullRefresh:{
		container:'#pullup-container',
		down:{
//	    	contentdown : "下拉可以刷新",//可选，在下拉可刷新状态时，下拉刷新控件上显示的标题内容
//	    	contentover : "释放立即刷新",//可选，在释放可刷新状态时，下拉刷新控件上显示的标题内容
//	    	contentrefresh : "正在刷新...",//可选，正在刷新状态时，下拉刷新控件上显示的标题内容
	    	callback :_pulldownRefresh //必选，刷新函数，根据具体业务来编写，比如通过ajax从服务器获取新数据；
	    }
	}
});

var app = null;

mui.plusReady(function() {
	app = new Vue({
		el: '#mui-work-main-vid',
		data: {
//			info:{}
		},
//		created:_vue_created,
		methods: {
			clickWorkUnitList:_vue_clickWorkUnitList,
			clickWorkCheckList:_vue_clickWorkCheckList
		}
	});
});

/**
 * 点击查看我管辖的集团列表
 */
function _vue_clickWorkUnitList(){
	ai.openWindow({
		url:"work-unit-list.html",
		id:"page-work-unit-list"
	});
}

/**
 * 点击查看需反馈意见的填报
 */
function _vue_clickWorkCheckList(){
	ai.openWindow({
		url:"work-check-list.html",
		id:"page-work-check-list"
	});
}

/**
 * 下拉刷新
 */
function _pulldownRefresh(){
	mui('#pullup-container').pullRefresh().endPulldownToRefresh();
	mui.toast('尚未实现今日提醒事项功能');
}
