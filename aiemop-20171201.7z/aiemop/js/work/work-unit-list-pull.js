mui.init({
	pullRefresh: {
		container: '#pullup-container',
		up: {
			contentrefresh: '正在加载...',
			callback: _pullupRefresh
		}
	}
});

var app = null;
var param = {unitIdName:'',pageNum:1,pageSize:10};

mui.plusReady(function() {
	app = new Vue({
		el: '#mui-work-unit-vid',
		data: {
			units: []
		},
		created:_vue_created,
		methods: {
			clickUnitItem:_vue_clickUnitItem
		}
	});
});

function _vue_created(){
	//初始化搜索框事件
	mui('span.mui-placeholder')[0].addEventListener('tap',function(e){
		mui('.mui-input-clear')[0].focus();
	});
	document.querySelector('form').addEventListener('submit', function(e){
	    e.preventDefault(); // 阻止默认事件
	    var searchInputBox = mui('.mui-input-clear')[0];
	    searchInputBox.blur();
		param.unitIdName = searchInputBox.value;
		mui('#pullup-container').pullRefresh().refresh(true);//重置上拉加载
		loadWorkUnit();
	});
	//加载集团列表数据
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	_pullupRefresh();
}

/**
 * 点击集团列表项目
 * @param {Object} unit
 */
function _vue_clickUnitItem(unit){
	ai.openWindow({
		url:"work-unit-info.html",
		id:"page-work-unit-info",
		extras:{
			unitId:unit.unitId,
			unitName:unit.unitName
		}
	});
}

/**
 * 加载数据(搜索或初始化页面时)
 */
function loadWorkUnit(){
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	if(app){app.units = [];}
	param.pageNum = 1;
	_pullupRefresh();
	if(mui.os.ios){
		plus.webview.currentWebview().evalJS("mui('#pullup-container').pullRefresh().scrollTo(0,0,100)");
	}else{
		plus.webview.currentWebview().evalJS('mui.scrollTo(0, 100)');
	}
}

/**
 * 上拉加载更多数据
 */
function _pullupRefresh() {
	setTimeout(function() {
		ai.ajax(ai.appPathObject.work + 'unit/list',param,function(data){
			if(data.state){
				app.units = app.units.concat(data.info.list)
				mui.toast('共'+data.info.total+'条记录,已加载'+(app.units.length == data.info.total ? '完毕':app.units.length+'条'));
				if(data.info.hasNextPage){
					mui('#pullup-container').pullRefresh().endPullupToRefresh(false);//还有更多数据
					param.pageNum++;
				}else{
					mui('#pullup-container').pullRefresh().endPullupToRefresh(true);//加载完毕
				}
			}
		},function(){
			mui('#pullup-container').pullRefresh().endPullupToRefresh(false);//还有更多数据
		},function(){
			plus.nativeUI.closeWaiting();
		});
	}, 1500);
}