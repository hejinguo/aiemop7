var pdata = {groupId:'',groupName:'',unitId:'',unitName:''};

mui.init({
	subpages: [{
		url: 'work-group-list-pull.html',
		id: 'page-work-template-group-list-pull',
		styles: {
			top: '45px',
			bottom: '0px',
		}
	}]
});

mui.plusReady(function(){
	var self = plus.webview.currentWebview();
	pdata = {groupId:self.groupId,groupName:self.groupName,unitId:self.unitId,unitName:self.unitName};
	mui('.mui-title')[0].innerHTML = "已填报提交的"+pdata.groupName;

	setTimeout(function(){
		mui.fire(plus.webview.getWebviewById("page-work-template-group-list-pull"),'_workGroupListExtras',pdata);
	},500);
});