var app = null;
var pdata = {writeId:'',unit: {unitId:'',unitName:''}};

mui.plusReady(function() {
	app = new Vue({
		el: '#mui-work-template-record-vid',
		data: {
			templates: []
		},
		created:_vue_created
	});
});

function _vue_created(){
	var self = plus.webview.currentWebview();
	pdata.writeId=self.writeId ? self.writeId : '';
	pdata.unit={unitId:self.unitId ? self.unitId : '',unitName:self.unitName ? self.unitName : ''};
	mui('.mui-title')[0].innerHTML = pdata.unit.unitName;
	
	_vue_loadTemplateItemRecord();
}

/**
 * 加载模板填报结果对象
 */
function _vue_loadTemplateItemRecord(){
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	ai.ajax(ai.appPathObject.work+'template/getRecordMore',{writeId:pdata.writeId},function(data){
		if(data.state){
			app.templates = data.info;
		}
	},function(){},function(){
		plus.nativeUI.closeWaiting();
	});
}