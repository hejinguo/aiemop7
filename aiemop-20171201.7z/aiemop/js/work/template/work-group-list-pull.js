mui.init({
	pullRefresh: {
		container: '#pullup-container',
		up: {
			contentrefresh: '正在加载...',
			callback: _pullupRefresh
		}
	}
});

var app = null;
var pdata = {
	param:{unitId:'',groupId:'',pageNum:1,pageSize:5},
	unit:{unitId:'',unitName:''},
	group:{groupId:'',groupName:''}
};

mui.plusReady(function() {
	app = new Vue({
		el: '#mui-work-group-list-vid',
		data: {
			records: []
		},
//		created:_vue_created,
		methods: {
			clickWriteItem:_vue_clickWriteItem
		}
	});
//	自定义触发页面参数传递的方法
	window.addEventListener('_workGroupListExtras',function(event){
		pdata.param.unitId = event.detail.unitId;
		pdata.param.groupId = event.detail.groupId;
		pdata.unit = {unitId:event.detail.unitId,unitName:event.detail.unitName};
		pdata.group = {groupId:event.detail.groupId,groupName:event.detail.groupName};
		plus.nativeUI.showWaiting("正在加载数据,请稍等.");
		_pullupRefresh();
	});
	//自定义修改填报后关闭填报窗口的事件
	window.addEventListener('_templateWriteCallBack',function(event){
		plus.webview.getWebviewById(event.detail.webviewId).close();
		_loadWorkGroupList();
	});
});

/**
 * 加载页面已填报数据记录
 */
function _loadWorkGroupList(){
	mui('#pullup-container').pullRefresh().refresh(true);//重置上拉加载
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	if(app){app.records = [];}
	pdata.param.pageNum = 1;
	_pullupRefresh();
	if(mui.os.ios){
		plus.webview.currentWebview().evalJS("mui('#pullup-container').pullRefresh().scrollTo(0,0,100)");
	}else{
		plus.webview.currentWebview().evalJS('mui.scrollTo(0, 100)');
	}
}

/**
 * 点击填报记录
 */
function _vue_clickWriteItem(record){
	ai.openWindow({
		url:"./write.html",
		id:"page-work-template-write-modify",
		extras:{unitId:pdata.unit.unitId,
				unitName:pdata.unit.unitName,
				modifyWriteId:record.writeId}
	});
}

/**
 * 上拉加载更多数据
 */
function _pullupRefresh() {
	setTimeout(function() {
		ai.ajax(ai.appPathObject.work + 'template/getWriteByGroup',pdata.param,function(data){
			if(data.state){
				app.records = app.records.concat(data.info.list)
				mui.toast('共'+data.info.total+'条记录,已加载'+(app.records.length == data.info.total ? '完毕':app.records.length+'条'));
				if(data.info.hasNextPage){
					mui('#pullup-container').pullRefresh().endPullupToRefresh(false);//还有更多数据
					pdata.param.pageNum++;
				}else{
					mui('#pullup-container').pullRefresh().endPullupToRefresh(true);//加载完毕
				}
			}
		},function(){
			mui('#pullup-container').pullRefresh().endPullupToRefresh(false);//还有更多数据
		},function(){
			plus.nativeUI.closeWaiting();
		});
	}, 1500);
}