var app = null;
var pdata = {templateCode:'',//模板代码;当不存在mwrite的时候此参数不可缺
			unit: {unitId:'',unitName:''},//集团编码;当不存在mwrite的时候此参数不可缺
			product: {productId:'',productName:''},//集团产品ID;为空或0代表不考虑集团产品,>0代表需要考虑特定产品模板
			archive: {archiveId:''},//商机档案ID;为空或0代表不考虑商机档案,>0代表基于档案填报模板
			parentWriteId: '',//填报记录ID;为空或0代表一般填报模板,>0代表关系填报模板(一般指计划后的结果填报)
			modifyWriteId: ''//填报记录ID;为空或0代表一般的新增填报,>0代表获取填报数据并提供编辑操作
			};

mui.plusReady(function() {
	app = new Vue({
		el: '#mui-work-template-write-vid',
		data: {
			template: {},
			submitWay : ''//提交数据方式,APPEND MODIFY
		},
		created:_vue_created,
		methods: {
			clickTemplateItemSelect:_vue_clickTemplateItemSelect,
			clickTemplateItemDate:_vue_clickTemplateItemDate,
			clickResetTemplateWrite:_vue_clickResetTemplateWrite,
			clickSubmitTemplateWrite:_vue_clickSubmitTemplateWrite,
			clickAppendTemplateGroupButton:_vue_clickAppendTemplateGroupButton,
			clickRemoveTemplateGroupButton:_vue_clickRemoveTemplateGroupButton,
			clickDisplayTemplateGroupButton:_vue_clickDisplayTemplateGroupButton
		}
	});
});

function _vue_created(){
	var self = plus.webview.currentWebview();
	pdata.templateCode=self.templateCode ? self.templateCode : '';
	pdata.unit={unitId:self.unitId ? self.unitId : '',unitName:self.unitName ? self.unitName : ''};
	pdata.product={productId:self.productId ? self.productId : '',productName:self.productName ? self.productName : ''};
	pdata.archive={archiveId:self.archiveId ? self.archiveId : ''};
	pdata.parentWriteId = self.parentWriteId ? self.parentWriteId : '';
	pdata.modifyWriteId = self.modifyWriteId ? self.modifyWriteId : '';
	
	if(pdata.product.productName){
		mui('.mui-title')[0].innerHTML = pdata.product.productName;
	}else{
		mui('.mui-title')[0].innerHTML = pdata.unit.unitName;
	}
	mui('#_refresh_template_form')[0].addEventListener("tap",function () {
  		app.clickResetTemplateWrite();
	});
	_vue_loadTemplateItemRecord();
}

/**
 * 加载填报模板输入对象
 */
function _vue_loadTemplateItemRecord(){
	if(pdata.templateCode || pdata.modifyWriteId){//存在模板编码或编辑记录ID均允许
		var url = "";
		var param = {};
		plus.nativeUI.showWaiting("正在加载数据,请稍等.");
		if(pdata.modifyWriteId){
			url = ai.appPathObject.work+"template/getRecord";
			param = {writeId:pdata.modifyWriteId};
		}else{
			url = ai.appPathObject.work+"template/getTemplateByCode";
			param = {code:pdata.templateCode,product:pdata.product.productId};
		}
		ai.ajax(url,param,function(data){
			if(data.state){
				app.template = data.info;
				mui.each(app.template.templateGroup,function(index,group){
					if(group.groupType == 2){//可自定义增减的项目
						group.displayBtn = true;//是否是用于显示操作按钮的首行分组的标记
					}
				});
				if(app.template && app.template.templateCode && !pdata.modifyWriteId){
					app.submitWay = "_APPEND";
				}else if(app.template && app.template.templateCode && pdata.modifyWriteId){
					app.submitWay = "_MODIFY";
				}
			}
		},function(){},function(){
			plus.nativeUI.closeWaiting();
		});
	}else{
		mui.alert('不合法的请求,因为您没有提供填报必须的参数信息!');
	}
}

/**
 * 点击重置模板填报内容
 */
function _vue_clickResetTemplateWrite(){
	_vue_loadTemplateItemRecord();
}

/**
 * 点击提交模板填报内容
 */
function _vue_clickSubmitTemplateWrite(){
	var _this = this;
	if(_validTemplateItemForm()){
		mui.confirm("您确定要提交吗?","确认",["取消","确定"],function(e){
			if(e.index == 1){
				plus.nativeUI.showWaiting("正在加载数据,请稍等.");
				var url = "";
				// pdata.modifyWriteId && pdata.modifyWriteId > 0
				if(pdata.modifyWriteId){//编辑填报记录信息
					url = ai.appPathObject.work+"template/modifyRecord";
				}else{
					url = ai.appPathObject.work+"template/writeRecord";
				}
				var writeRecord = _generateWriteRecord();
				ai.json(url,JSON.stringify(writeRecord),function(data){
					if(data.state){
						var resultMsg = _this.template.templateName+'成功!';
						if(pdata.modifyWriteId){//编辑填报记录信息
							resultMsg = "编辑 "+resultMsg;
						}else{
							_this.clickResetTemplateWrite();
						}
						mui.toast(resultMsg);
						var self = plus.webview.currentWebview();
						mui.fire(self.opener(),'_templateWriteCallBack',{webviewId:self.id});//调用打开本页面窗口的回调函数
					}
				},function(){},function(){
					plus.nativeUI.closeWaiting();
				});
			}
		});
	}else{
		mui.alert('请按红色标记要求填写数据后再提交.');
	}
}

/**
 * 单击添加克隆模板分组
 */
function _vue_clickAppendTemplateGroupButton(group,index){
	var _this = this;
	if(group.groupType == 2 && group.hiddenInput == true){
		group.hiddenInput = false;//如果前期已经将首行影藏并失效处理,添加时候优先启用该行
		Vue.set(_this.template.templateGroup, index, group);
	}else{
		plus.nativeUI.showWaiting("正在加载数据,请稍等.");
		ai.ajax(ai.appPathObject.work+'template/getGroup',{groupId:group.groupId},function(data){
			if(data.state){
				data.info.groupIndex = new Date().getTime();//缓存groupIndex用于后期剔除的依据
				_this.template.templateGroup.splice(index+1, 0, data.info);
				mui.toast('成功添加'+group.groupName+'条目.');
			}
		},function(){},function(){
			plus.nativeUI.closeWaiting();
		});
	}
}

/**
 * 单击移除克隆模板分组
 */
function _vue_clickRemoveTemplateGroupButton(group,index){
	var _this = this;
	if(group.groupType == 2 && group.displayBtn == true){
		group.hiddenInput = true;//如果点击的是首行既影藏并失效即可,因为要保留操作按钮
		Vue.set(_this.template.templateGroup, index, group);
	}else{
		_this.template.templateGroup.splice(index, 1);
	}
}

/**
 * 点击查看已填报分组历史
 */
function _vue_clickDisplayTemplateGroupButton(group){
	var extras = {
		groupId:group.groupId,
		groupName:group.groupName,
		unitId:pdata.unit.unitId,
		unitName:pdata.unit.unitName
	};
	ai.openWindow({
		url:"./work-group-list.html",
		id:"page-work-template-group-list",
		extras:extras
	});
}

/**
 * 填报模板表单验证
 * @returns {Boolean}
 */
function _validTemplateItemForm(){
	var submit = true;//验证结果是否合法标记
	mui.each(app.template.templateGroup,function(g,group){
		if(!group.hiddenInput){//只显示表单的进行合法验证
			mui.each(group.templateItem,function(i,item){
				item.itemValue = item.itemValue ? item.itemValue.replace(/(^\s*)|(\s*$)/g, "") : '';
				if(item.itemRegex && !item.itemValue.match(eval(item.itemRegex))){
					submit = false;
				}
			});
		}
	});
	return submit;
}

/**
 * 生成表单填报结果对象
 */
function _generateWriteRecord(){
	var writeRecord = {templateId:app.template.templateId,templateCode:app.template.templateCode,writeDetail:[]};
	if(pdata.unit.unitId && pdata.unit.unitId > 0){
		writeRecord.unitId = pdata.unit.unitId;
	}
	if(pdata.parentWriteId && pdata.parentWriteId > 0){//填报时需建立填报关系的父模板
		writeRecord.parentWriteId = pdata.parentWriteId;
	}
	if(pdata.product.productId && 'BUILD_ARCHIVE' == pdata.templateCode){//创建商机档案
		writeRecord.writeArchive = {unitId:pdata.unit.unitId,productId:pdata.product.productId};
	}else if(pdata.archive.archiveId && pdata.archive.archiveId > 0){//基于商机档案填报的模板
		writeRecord.writeArchive = {archiveId:pdata.archive.archiveId};
	}
	mui.each(app.template.templateGroup,function(g,group){
		if(!group.hiddenInput){//只显示表单的进行封装提交
			mui.each(group.templateItem,function(i,item){
				writeRecord.writeDetail.push({
					groupId:group.groupId,
					groupCode:group.groupCode,
					groupIndex:(group.groupIndex ? group.groupIndex : 0),
					itemId:item.itemId,
					itemCode:item.itemCode,
					itemValue:item.itemValue
				});
			});
		}
	});
	if(pdata.modifyWriteId){//编辑填报记录信息
		writeRecord.writeId = pdata.modifyWriteId;
	}
	return writeRecord;
}

/**
 * 激活下拉选择控件
 * @param {Object} item
 */
function _vue_clickTemplateItemSelect(item){
	if(item.selectList ? item.selectList.length : 0 > 0){
		var picker = new mui.PopPicker();
		picker.setData(item.selectList);
		picker.show(function(items) {//返回 false 可以阻止选择框的关闭
			item.itemValue = items[0].value;
		});
	}else{
		mui.toast("对不起,没有可供选择的项目.");
	}
}

/**
 * 激活日期时间选择控件
 * @param {Object} item
 * @param {Object} options
 */
function _vue_clickTemplateItemDate(item,options){
	var picker = new mui.DtPicker(options);
	picker.show(function(rs) {
		/*
		 * rs.value 拼合后的 value
		 * rs.text 拼合后的 text
		 * rs.y 年，可以通过 rs.y.vaue 和 rs.y.text 获取值和文本
		 * rs.m 月，用法同年
		 * rs.d 日，用法同年
		 * rs.h 时，用法同年
		 * rs.i 分（minutes 的第二个字母），用法同年
		 */
		if(options.type && options.type == 'date'){
			item.itemValue = rs.text;
		}else{
			item.itemValue = rs.text+":00";
		}
		/* 
		 * 返回 false 可以阻止选择框的关闭
		 * return false;
		 */
		/*
		 * 释放组件资源，释放后将将不能再操作组件
		 * 通常情况下，不需要示放组件，new DtPicker(options) 后，可以一直使用。
		 * 当前示例，因为内容较多，如不进行资原释放，在某些设备上会较慢。
		 * 所以每次用完便立即调用 dispose 进行释放，下次用时再创建新实例。
		 */
		picker.dispose();
	});
}