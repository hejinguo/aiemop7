var app = null;
var pdata = {unit:{unitId:'',unitName:''},writeId:''};

mui.plusReady(function() {
	app = new Vue({
		el: '#mui-work-check-record-vid',
		data: {
			suggests:[]
		},
		created:_vue_created,
		methods: {

		}
	});
});

function _vue_created(){
	var self = plus.webview.currentWebview();
	pdata.unit={unitId:self.unitId,unitName:self.unitName};
	pdata.writeId = self.writeId;
	mui('.mui-title')[0].innerHTML = pdata.unit.unitName;
	_loadWorkCheckRecord();
}

/**
 * 加载工作意见记录
 */
function _loadWorkCheckRecord(){
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	ai.ajax(ai.appPathObject.work + 'check/getCheckRecord',{writeId:pdata.writeId},function(data){
		if(data.state){
			app.suggests = data.info;
		}
	},function(){},function(){
		plus.nativeUI.closeWaiting();
	});
}
