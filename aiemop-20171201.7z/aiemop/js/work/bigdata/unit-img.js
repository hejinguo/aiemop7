var pdata = {unit:{}};
var vm = null;

mui.plusReady(function(){
	var self = plus.webview.currentWebview();
	pdata.unit={unitId:self.unitId,unitName:self.unitName};
	
	vm = new Vue({
		el : '#_page_div',
		data : {
			columnStyle : {width:'100%'},
			canvasWidth : (plus.screen.resolutionWidth-40)+'px',
			info : {}
		},
		mounted : function(){
//			mui.alert(plus.screen.resolutionWidth);//335-340
			var _this = this;
			plus.nativeUI.showWaiting("正在加载数据,请稍等.");
			var param = {unitId : pdata.unit.unitId};
			ai.ajax(ai.appPathObject.work + 'report/getUnitInfo',param,function(data){
				if(data.state){
//					_this.info = JSON.parse(data.info);
					_this.info = JSON.parse(data.info.content);
					Vue.nextTick(function(){
						initPageEcharts(_this);
						initPageCanvas(_this);
					});
				}
			},function(){
				
			},function(){
				plus.nativeUI.closeWaiting();
			});
		},
		methods : {
			percent : function(value,dval){
//				return Math.round(value*10000)/100;//数字均保留的4位小数
				return " "+(value ? Math.round(value*10000)/100 : dval)+" ";
			},
			dvalue : function(value,dval){
				return " "+(value ? value : dval)+" ";
			}
		}
	})
});

/**
 * 页面改变大小时的自适应(仅支持PC/APP)
 */
/*function initPageSize(_this){
	var w = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
	var h = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
	if(w >= 1250){
//		_this.columnStyle = {width:'33.3%',float:'left'};
		_this.columnStyle = {width:(w*0.33-2)+"px",float:'left'};
		_this.canvasWidth = (w*0.33-45)+"px";
	}else{
		_this.columnStyle = {width:'100%',float:'none',minWidth:'370px'};
		_this.canvasWidth = (w-55 > 370 ? w-55 : 370)+"px";
	}
}*/