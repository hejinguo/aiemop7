/**
 * 供调用的画Echarts方法
 * @param _this
 */
function initPageEcharts(_this){
	if(_this.$refs._echarts_arrear){
		drawCommonSeriesChart({el:_this.$refs._echarts_arrear,xAxisData:["0-6个月","7-12个月","13-24个月","24个月以上"],series:[{
			name: '集团欠费',
	        type: 'bar',
	        barWidth:'10',
	        barMinHeight:'2',
	        data: _this.info.MON_OWE,//[_this.info.OWE_0_6, _this.info.OWE_7_12, _this.info.OWE_13_24, _this.info.OWE_25],
	        itemStyle:{normal:{color:'#64AF83'}}
		}]});
	}
	if(_this.$refs._echarts_dedicate){
		drawCirqueChart({el:_this.$refs._echarts_dedicate,items:[
		    {thisTitle:'当前集团收入',thisValue:_this.info.ZX_CUR_FEE,
		     otherTitle:'同类平均收入',otherValue:_this.info.ZX_FEE_TL,
		     rate:_this.info.ZX_FEE_TL_RATE},
		    {thisTitle:'当前集团规模',thisValue:_this.info.ZX_NUMS,
		     otherTitle:'同类平均规模',otherValue:_this.info.ZX_PACK_TL,
		     rate:_this.info.ZX_PACK_TL_RATE},
		    {thisTitle:'当前集团单价',thisValue:_this.info.ZX_PRICE,
		     otherTitle:'同类平均单价',otherValue:_this.info.ZX_PRICE_TL,
		     rate:_this.info.ZX_PRICE_TL_RATE}
		]});
		//drawCommonLineChart({el:_this.$refs._echarts_dedicate,xAxisData:["1月","2月","3月","4月","5月","6月","7月","8月","9月","10月","11月","12月"],seriesData:_this.info.ZX_MON_FEE,seriesName:'集团专线收入'});
	}
	if(_this.$refs._echarts_mas){
		drawCirqueChart({el:_this.$refs._echarts_mas,items:[
			{thisTitle:'当前集团收入',thisValue:_this.info.MAS_CUR_FEE,
			 otherTitle:'同类平均收入',otherValue:_this.info.MAS_FEE_TL,
			 rate:_this.info.MAS_FEE_TL_RATE},
			{thisTitle:'当前集团规模',thisValue:_this.info.MAS_PACK,
			 otherTitle:'同类平均规模',otherValue:_this.info.MAS_PACK_TL,
			 rate:_this.info.MAS_PACK_TL_RATE},
			{thisTitle:'当前集团发送',thisValue:_this.info.PORT_MSG_NUMS,
			 otherTitle:'同类平均发送',otherValue:_this.info.PORT_MSG_TL,
			 rate:_this.info.PORT_MSG_TL_RATE}
		]});
		//drawCommonLineChart({el:_this.$refs._echarts_mas,xAxisData:["1月","2月","3月","4月","5月","6月","7月","8月","9月","10月","11月","12月"],seriesData:_this.info.MAS_MON_FEE,seriesName:'MAS收入'});
	}
	//drawCommonLineChart({el:_this.$refs._echarts_business,xAxisData:["1月","2月","3月","4月","5月","6月","7月","8月","9月","10月","11月","12月"],seriesData:[],seriesName:'商务动力收入'});
	/*drawCommonSeriesChart({el:_this.$refs._echarts_mas,xAxisData:["1月","2月","3月","4月","5月","6月","7月","8月","9月","10月","11月","12月"],series:[{
    	name:'月端口发送量',
    	type:'line',
    	data:[0,0,0,0,0,10],
    	itemStyle:{normal:{color:'#FE9592'}},
    	areaStyle:{normal:{color:'#FE9592'}}
    },{
    	name:'MAS收入',
        type: 'line',
        data: [5, 20, 36, 20,10,30],
        itemStyle:{normal:{color:'#FFDF36'}}
    }]});*/
	if(_this.$refs._echarts_hinge){
		drawCommonLineChart({el:_this.$refs._echarts_hinge,xAxisData:["1月","2月","3月","4月","5月","6月","7月","8月","9月","10月","11月","12月"],seriesData:_this.info.GJR_MON_FEE,seriesName:'集团关键人员消费'});
	}
}

/**
 * 画常规线性质的趋势Echart
 * @param options
 */
function drawCommonLineChart(options){
	var chart = echarts.init(options.el);
	var option = {
    	tooltip: {trigger:'axis',axisPointer:{lineStyle:{color:'#FFF'}}},
        grid:{
        	top:5,
        	bottom:20,
        	right:5
        },
        xAxis: {
        	axisLine:{lineStyle:{color:'#FFFFFF'}},
            data: options.xAxisData
        },
        yAxis: {
        	axisLine:{lineStyle:{color:'#FFFFFF'}},
        	axisLabel:{textStyle:{color:'#FFFFFF'},formatter:function(value, index){
            	return ai.echartsAxisFormat(value);
            }}
        },
        series: [{
        	name: options.seriesName,
            type: 'line',
            data: options.seriesData,
            itemStyle:{normal:{color:'#FFDF36'}}
        }]
    };
    chart.setOption(option);
}

/**
 * 画集团业务特征指标对比圆环的Echart
 * @param options
 */
function drawCirqueChart(options){
	var chart = echarts.init(options.el);
	var option = {
		graphic:privateCirqueGraphic(options.items),
		series:privateCirqueSeries(options.items)
	};
    chart.setOption(option);
    chart.resize();
}

/**
 * 画通用series配置的Echart
 * @param options
 */
function drawCommonSeriesChart(options){
	var chart = echarts.init(options.el);
    var option = {
        tooltip: {trigger:'axis',axisPointer:{lineStyle:{color:'#FFF'}}},
        grid:{
        	top:5,
        	bottom:20,
        	right:5
        },
        xAxis: {
        	axisLine:{lineStyle:{color:'#FFFFFF'}},
            data: options.xAxisData
        },
        yAxis: {
        	axisLine:{lineStyle:{color:'#FFFFFF'}},
        	axisLabel:{textStyle:{color:'#FFFFFF'},formatter:function(value, index){
            	return ai.echartsAxisFormat(value);
            }}
        },
        series: options.series
    };
    chart.setOption(option);
}


function privateCirqueGraphic(items){
	var results = [];
	for(var i = 0;i < items.length;i++){
		results.push({
            type: 'text',
            z: 100,
            bottom:'5px',
            left: (i*34)+'%',
            style: {
                text: items[i].otherTitle+":"+ai.decimalFormat(ai.defaultValue(items[i].otherValue,0),0),
                font: '12px "STHeiti", sans-serif',//bolder
                fill: '#99DEFD'
            }
        });
		results.push({
            type: 'text',
            z: 100,
            bottom:'20px',
            left: (i*34)+'%',
            style: {
                text: items[i].thisTitle+":"+ai.decimalFormat(ai.defaultValue(items[i].thisValue,0),0),
                font: '12px "STHeiti", sans-serif',//bolder
                fill: '#FFDF36'
            }
        });
        results.push({
            type: 'text',
            z: 100,
            top:'50px',
            left: (33*i+10)+"%",
            style: {
                text: ai.decimalFormat(ai.defaultValue(items[i].rate,0)*100.00,2)+"%",
                font: '12px "STHeiti", sans-serif',//bolder
                fill: '#FFDF36'
            }
        });
	}
	return results;
}

function privateCirqueSeries(items){
	var results = [];
	for(var i = 0;i < items.length;i++){
		results.push({
		    type:'pie',
		    clockWise:false,
		    radius : [25, 35],
		    center:[(33*i+16)+"%","55px"],
		    hoverAnimation:false,
		    label:{normal:{show:false}},
		    labelLine:{normal:{show:false}},
		    itemStyle:{normal:{color:'#FFDF36'}},
		    data:[
		        {
		            value:ai.defaultValue(items[i].thisValue,0), 
		            name:items[i].thisTitle
		        },
		        {
		            value:ai.defaultValue(items[i].otherValue,0),
		            name:'invisible',
		            itemStyle : {
		        	    normal : {
		        	        color: 'rgba(0,0,0,0)',
		        	    },
		        	    emphasis : {
		        	        color: 'rgba(0,0,0,0)'
		        	    }
		        	}
		        }
		    ]
		});
		results.push({
			type:'pie',
	        clockWise:false,
	        radius : [35, 45],
	        center:[(33*i+16)+"%","55px"],
	        hoverAnimation:false,
	        label:{normal:{show:false}},
	        labelLine:{normal:{show:false}},
	        itemStyle:{normal:{color:'#99DEFD'}},
	        data:[
	            {
	                value:ai.defaultValue(items[i].otherValue,0),
	                name:items[i].otherTitle
	            },
	            {
	                value:ai.defaultValue(items[i].thisValue,0),
	                name:'invisible',
	                itemStyle : {
		        	    normal : {
		        	        color: 'rgba(0,0,0,0)',
		        	    },
		        	    emphasis : {
		        	        color: 'rgba(0,0,0,0)'
		        	    }
		        	}
	            }
	        ]
		});
	}
	return results;
}