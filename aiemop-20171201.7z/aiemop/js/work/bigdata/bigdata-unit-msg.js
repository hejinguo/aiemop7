var param = {unitId:'',unitName:''};
 template.helper("moment", moment);
template.helper("percent", function(value){
	return Math.round(value*10000)/100;//数字均保留的4位小数
});

mui.plusReady(function(){
	var self = plus.webview.currentWebview();
	param = {unitId:self.unitId,unitName:self.unitName};
	mui('.mui-title')[0].innerHTML = param.unitName;
	
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	ai.ajax(ai.appPathObject.work + 'report/getUnitInfo',{unitId:param.unitId},function(data){
		if(data.state){
			mui('#mui-bigdata-unit-msg')[0].innerHTML=template('_unit_big_data_template',JSON.parse(data.info));
		}
	},function(){},function(){
		plus.nativeUI.closeWaiting();
	});
});