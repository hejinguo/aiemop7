var app = null;
var pdata = {unit:{unitId:'',unitName:''},writeId:''};

mui.plusReady(function() {
	app = new Vue({
		el: '#mui-work-suggest-vid',
		data: {
			checkSuggest:''
		},
		created:_vue_created,
		methods: {
			clickSubmitCheckSuggest:_vue_clickSubmitCheckSuggest
		}
	});
});

function _vue_created(){
	var self = plus.webview.currentWebview();
	pdata.unit={unitId:self.unitId,unitName:self.unitName};
	pdata.writeId = self.writeId;
	mui('.mui-title')[0].innerHTML = pdata.unit.unitName;
}

/**
 * 提交填报工作意见
 */
function _vue_clickSubmitCheckSuggest(){
	var _this = this;
	mui.confirm("您确定要提交吗?","确认",["取消","确定"],function(e){
		if(e.index == 1){
			plus.nativeUI.showWaiting("正在加载数据,请稍等.");
			var checkRecord = {writeId:pdata.writeId,checkSuggest:_this.checkSuggest};
			ai.json(ai.appPathObject.work+"check/saveCheckRecord",JSON.stringify(checkRecord),function(data){
				if(data.state){
					mui.toast('提交工作意见操作成功!');
					var self = plus.webview.currentWebview();
					mui.fire(self.opener(),'_writeCheckSuggestCallBack',{webviewId:self.id});//调用打开本页面窗口的回调函数
				}
			},function(){},function(){
				plus.nativeUI.closeWaiting();
			});
		}
	});
}
