mui.init({
	subpages: [{
		url: 'work-check-list-pull.html',
		id: 'page-work-check-list-pull',
		styles: {
			top: '45px',
			bottom: '0px',
		}
	}]
});