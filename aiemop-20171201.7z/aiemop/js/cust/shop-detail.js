mui.init({

});

mui.plusReady(function() {
	var self = plus.webview.currentWebview();
	//判断本地是否有该商铺照片
	var img_url = "_downloads/" +self.ent_code+"."+self.ent_imgtype;
	plus.io.resolveLocalFileSystemURL(img_url, function(entry) {
		getShopInfo(self.ent_code,'Y',entry.fullPath);
	},function(){
		getShopInfo(self.ent_code,'N','');
	});
	
});

function getShopInfo(shopCode,haveImage,imgURL) {
	//mui.alert(haveImage);
	var para = {
		'shopCode': shopCode,
		'haveImage':haveImage
	};
	plus.nativeUI.showWaiting("正在处理，请稍等...");
	ai.ajax("cust/getShopInfoByCode", para, function(data) {
			if(data.state) {
				var shop_detail = document.body.querySelector(".mui-content");
				var div_shop = document.createElement("div");
				div_shop.className = "mui-row mui-card";
				var item = data.info[0];
				mui('#shop_type_code')[0].innerText = item.TYPE_CODE;
				//联系方式
				var tel_way = "";
				if(!isNull(item.TEL1)) {
					tel_way += '、' + item.TEL1;
				}
				if(!isNull(item.TEL2)) {
					tel_way += '、' + item.TEL2;
				}
				//照片显示
				var ent_img='';
				if(haveImage=='Y'){
					ent_img = '<img width="200px" height="90px" src="'+imgURL+'"/>';
				}else if(!isNull(item.ENT_IMAGE)){
					ent_img = '<img width="200px" height="90px" src="'+ai.appPathObject.emop+'cust/getShopImage?entCode='+ item.ENT_IMAGE+'&version='+new Date().getTime()+'"/>';
				}else{
					ent_img = '<img width="200px" height="90px" src="../../images/cust/shop-icon.png"/>';
				}
				//行业显示
				var ent_type=item.TYPE_ID;
				if(!isNull(item.MARKET_NAME)){
					ent_type+="（"+item.MARKET_NAME+"）";
				}
				var div_html = '<div class="mui-col-xs-12 mui-text-left"><h3 class="mui-ellipsis">' + item.ENT_NAME + '</h3></div>' +
					'<div class="mui-col-xs-12 shop_info_title ">基础信息</div>' +
					'<div class="mui-col-xs-12 mui-text-left"><h5><span>行业：</span>' + ent_type + '</h5></div>' +
					'<div class="mui-col-xs-7 mui-text-left"><h5 class="mui-ellipsis"><span>所属地市：</span>' + item.CITY_CODE + '</h5></div>' +
					'<div class="mui-col-xs-5 mui-text-left"><h5 class="mui-ellipsis"><span>所属区县：</span>' + item.COUNTY_CODE + '</h5></div>' +
					'<div class="mui-col-xs-12 mui-text-left"><h5><span>街道：</span>' + (isNull(item.STREET) ? '不详' : item.STREET) + '</h5></div>' +
					'<div class="mui-col-xs-12 mui-text-left"><h5 class="mui-ellipsis"><span>地址：</span>' + item.ADDRESS + '</h5></div>' +
					'<div class="mui-col-xs-12 mui-text-left"><h5 class="mui-ellipsis"><span>联系人：</span>' + item.TEL_NAME + '</h5></div>' +
					'<div class="mui-col-xs-12 mui-text-left"><h5><span>联系方式：</span>' + (tel_way == '' ? '无' : tel_way.substring(1)) + '</h5></div>' +
					'<div class="mui-col-xs-12 shop_info_title">扩展信息</div>' +
					'<div class="mui-col-xs-12  shop_img_div"><h5><label>照片：</label>' + ent_img + '</h5></div>' +
					'<div class="mui-col-xs-12 mui-text-left"><h5><span>是否完成集团组网：</span>' + (item.ENT_NETWORK == 'Y' ? '是' : '否') + '</h5></div>' +
					'<div class="mui-col-xs-6 mui-text-left"><h5><span>宽带资源是否覆盖：</span>' + item.BROADBAND + '</h5></div>' +
					'<div class="mui-col-xs-6 mui-text-left"><h5 class="mui-ellipsis"><span>是否维护：</span>' + item.FLAG + '</h5></div>' +
					'<div class="mui-col-xs-6 mui-text-left"><h5 class="mui-ellipsis"><span>集团编码：</span>' + (item.ENT_280 == '' ? '无' : item.ENT_280) + '</h5></div>' +
					'<div class="mui-col-xs-6 mui-text-left"><h5 class="mui-ellipsis"><span>集团成员数:</span>' + item.ENT_MEMBERS + '</h5></div>' +
					'<div class="mui-col-xs-6 mui-text-left"><h5 class="mui-ellipsis"><span>商务动力座机:</span>' + item.BUSINESS_TEL + '</h5></div>' +
					'<div class="mui-col-xs-6 mui-text-left"><h5 class="mui-ellipsis"><span>网格编码：</span>' + (item.GRID_CODE == ''? '无' : item.GRID_CODE) + '</h5></div>' +
					'<div class="mui-col-xs-6 mui-text-left"><h5 class="mui-ellipsis"><span>宽带号码:</span>' + item.BUSINESS_SCALE + '</h5></div>'+
					'<div class="mui-col-xs-6 mui-text-left"><h5 class="mui-ellipsis"><span>网格名称:</span>' + item.GRID_NAME+ '</h5></div>';
				div_html += '<div class="mui-col-xs-12 mui-text-left"><h5><span>备注：</span>' + (item.REMARK == '' ? '无' : item.REMARK) + '</h5></div>';
				div_shop.innerHTML = div_html;
				shop_detail.appendChild(div_shop);
			}
		},
		function() {

		},
		function() {
			plus.nativeUI.closeWaiting();
			getExpandInfo(shopCode);
		});
}

function getExpandInfo(shopCode) {
	setTimeout(function() {
		var type_code = mui('#shop_type_code')[0].innerText;
		if(!isNull(type_code)) {
			var para = {
				'entCode': shopCode,
				'typeId': type_code
			};
			ai.ajax("cust/getExpandShopInfo", para, function(data) {
				if(data.state && JSON.stringify(data.info).length > 0) {
					var div_html = mui('div.mui-card')[0].innerHTML;
					div_html += '<div class="mui-col-xs-12 shop_info_title ">个性化信息</div>';
					var item_count = 0;
					mui.each(data.info, function(index, item) {
						div_html += '<div class="mui-col-xs-6 mui-text-left"><h5 class="mui-ellipsis"><span id="' + item.K_ID + '">' + item.K_NAME + '：</span>' + (isNull(item.K_VALUE) ? '不详' : item.K_VALUE) + '</h5></div>';
						item_count = index;
					});
					//如果是奇数个选项，增加一列补全显示
					if(item_count % 2 == 0) {
						div_html += '<div class="mui-col-xs-6 mui-text-left"><h5 class="mui-ellipsis"><span></span></h5></div>';
					}
					mui('div.mui-card')[0].innerHTML = div_html;
				}
			}, function() {

			}, function() {

			});
		}
	}, 500);
}

/**
 * 判断值是否为空（如果等于例外的字符串，也为空）
 * @param {Object} 要判断的值
 * @param {Object} 例外的字符串
 */
function isNull(str, eqstr) {
	if(str == "" || str == "undefined") return true;
	if(typeof(str) == "undefined") return true;
	if(eqstr && str == eqstr) return true;
	var regu = "^[ ]+$";
	var re = new RegExp(regu);
	return re.test(str);
}