mui.init({

});
mui.plusReady(function() {
	setCharts();
});

function setCharts() {

	var yAxis_data = [];
	var data_state_0=[];
	var data_state_1=[];
	var data_state_2=[];
	var city_info = document.getElementById("city_list");
	//获取地市，或者区县数据
	ai.ajax("cust/getShopGroupByArea", {}, function(data) {
		if(data.state) {
			mui.each(data.info, function(index, item) {
				yAxis_data.push(item.CODE);
				data_state_0.push(item.ENT_STATE0);
				data_state_1.push(item.ENT_STATE1);
				data_state_2.push(item.ENT_STATE2);
			});
		}
		var myChart = echarts.init(city_info);
		var option = {
			tooltip: {
				trigger: 'axis',
				axisPointer: { // 坐标轴指示器，坐标轴触发有效
					type: 'shadow' // 默认为直线，可选为：'line' | 'shadow'
				}
			},
			legend: {
				data: ['已拓展', '已管理', '未管理']
			},
			grid: {
				top:'30px',
				left: '3%',
				right: '4%',
				bottom: '3%',
				containLabel: true
			},
			xAxis: {
				type: 'value',
				position:'top'
			},
			yAxis: {
				type: 'category',
				data: yAxis_data
			},
			series: [{
				name: '已拓展',
				type: 'bar',
				stack: '总量',
				label: {
					normal: {
						show: true,
						position: 'insideRight'
					}
				},
				data: data_state_2
			}, {
				name: '已管理',
				type: 'bar',
				stack: '总量',
				label: {
					normal: {
						show: true,
						position: 'insideRight'
					}
				},
				data: data_state_1
			}, {
				name: '未管理',
				type: 'bar',
				stack: '总量',
				label: {
					normal: {
						show: true,
						position: 'insideRight'
					}
				},
				data: data_state_0
			}]
		};
		myChart.setOption(option);
	}, function() {
		city_info.innerHTML="数据请求失败，请联系管理员！";
	}, function() {
		
	});

}