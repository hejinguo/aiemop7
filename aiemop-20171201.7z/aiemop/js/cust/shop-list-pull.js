mui.init({
	pullRefresh: {
		container: '#pullrefresh',
		up: {
			callback: pullupRefresh
		},
		down: {
			callback: pulldownRefresh
		}
	},
	gestureConfig: {
		tap: true, //默认为true
		doubletap: true, //默认为false
		longtap: true, //默认为false
		swipe: true, //默认为true
		drag: true, //默认为true
		hold: false, //默认为false， 不监听
		release: false //默认为false，不监听
	}
});
var para = {
	'pageNo': 1,
	'pageSize': 10,
	'orderCol': 'ent_state',
	'orderDesc': 'DESC'
};
mui.plusReady(function() {
	//政策文档
	window.addEventListener('showInfoPopover', function(event) {
		mui('#info_popover').popover('show');
	});
	mui("#select_info_popover").on('tap', '#shop_zc', function(e) {
		ai.openWindow({
			url: 'shop-article-2.html',
			id: 'page-shop-article-2'
		});
		mui('#info_popover').popover('hide');
	});
	mui("#select_info_popover").on('tap', '#shop_taocan', function(e) {
		ai.openWindow({
			url: 'shop-article-1.html',
			id: 'page-shop-article-1'
		});
		mui('#info_popover').popover('hide');
	});
	mui("#select_info_popover").on('tap', '#shop_showcity', function(e) {
		ai.openWindow({
			url: 'shop-city.html',
			id: 'page-shop-city'
		});
		mui('#info_popover').popover('hide');
	});
	//初始加载商铺信息列表
	initShopList();
	//商铺数据搜索
	searchShop();
	//设置行业数据
	setTypeCount();
	//筛选栏-行业筛选
	mui('.top_select').on('tap', '.selectType', function(e) {
		document.getElementById("select_type_popover").className = "mui-table-view shop_detail_show";
		document.getElementById("select_area_popover").className = "mui-row shop_detail_hide";
		document.getElementById("select_order_popover").className = "mui-table-view shop_detail_hide";
		mui('#select_popover').popover('show');
	});
	//商铺排序
	mui('.top_select').on('tap', '.selectOrder', function(e) {
		document.getElementById("select_type_popover").className = "mui-table-view shop_detail_hide";
		document.getElementById("select_area_popover").className = "mui-row shop_detail_hide";
		document.getElementById("select_order_popover").className = "mui-table-view shop_detail_show";
		mui('#select_popover').popover('show');
	});
	//行政区域筛选
	mui('.top_select').on('tap', '.selectArea', function(e) {
		document.getElementById("select_type_popover").className = "mui-table-view shop_detail_hide";
		document.getElementById("select_area_popover").className = "mui-row shop_detail_show";
		document.getElementById("select_order_popover").className = "mui-table-view shop_detail_hide";
		mui('#select_popover').popover('show');
		//禁止滚动刷新
		//mui('#pullrefresh').pullRefresh().setStopped(true);
	});
	//商铺排序
	mui('.top_select').on('tap', '.selectClose', function(e) {
		mui('#select_popover').popover('hide');
		//禁止滚动刷新
		mui('#pullrefresh').pullRefresh().setStopped(false);
	});
	searchByType();
	//展开点击事件
	mui('.mui-scroll>.mui-table-view').on('tap', 'h5', function(e) {

		var shop_detail = document.getElementById("shop_detail_" + this.getAttribute("entCode"));
		if(shop_detail.className.indexOf('shop_detail_hide') > 0) {
			shop_detail.className = 'mui-row shop_detail_show';
			this.innerHTML = '<a>收起<span class="mui-icon mui-icon-arrowup"></span></a>';
		} else {
			shop_detail.className = 'mui-row shop_detail_hide';
			this.innerHTML = '<a>展开<span class="mui-icon mui-icon-arrowdown"></span></a>';
		}
	});
	//商铺单击事件
	mui('.mui-scroll>.mui-table-view').on('tap', 'li div.mui-row', function(e) {
		ai.openWindow({
			url: "shop-detail.html",
			id: "page-shop-detail",
			extras: {
				ent_code: this.getAttribute("ent_code"),
				ent_imgtype: this.getAttribute("ent_imgtype")
			}
		});
	});
	//商铺长按事件
	mui('.mui-scroll>.mui-table-view').on('longtap', 'li', function(e) {
		ai.openWindow({
			url: "shop-map.html",
			id: "page-shop-map",
			extras: {
				map_x: this.dataset.map_x,
				map_y: this.dataset.map_y,
				ent_name: this.dataset.ent_name,
				ent_code: this.dataset.ent_code
			}
		});
	});
	//右滑后，点击编辑按钮
	mui("#shop_list").on("tap", 'a.mui-btn-green', function(e) {
		ai.openWindow({
			url: "shop-edit.html",
			id: "page-shop-edit",
			extras: {
				ent_code: this.getAttribute("ent_code"),
				ent_imgtype: this.getAttribute("ent_imgtype")
			}
		});
	});
	//右滑后，点击删除按钮
	mui("#shop_list").on("tap", 'a.mui-btn-red', function(e) {
		var shop_code=this.getAttribute("ent_code");
		mui.confirm("请确认是否删除该商铺？", "删除商铺", ['否', '是'], function(e) {
			if(e.index == 1) {
				ai.ajax("cust/delShopInfo",{'shopCode':shop_code},function(data){
					if(data.state&&data.info=='1'){
						mui.toast("删除成功！");
						initShopList();
					}else{
						mui.toast("删除失败！");
					}
				},function(){
					
				},function(){
					
				});
			}
		});
	});
	//右滑后，点击查看按钮
	mui("#shop_list").on("tap", 'a.mui-btn-blue', function(e) {
		ai.openWindow({
			url: "shop-detail.html",
			id: "page-shop-detail",
			extras: {
				ent_code: this.getAttribute("ent_code"),
				ent_imgtype: this.getAttribute("ent_imgtype")
			}
		});
	});
});
/**
 * 初始化搜索事件
 */
function searchShop() {
	mui('#shop_search_box')[0].addEventListener('tap', function(e) {
		mui('.mui-input-clear')[0].focus();
	});
	document.querySelector('form').addEventListener('submit', function(e) {
		e.preventDefault(); // 阻止默认事件
		var searchInputBox = mui('.mui-input-clear')[0];
		searchInputBox.blur();
		para.entName = searchInputBox.value;
		mui('#pullrefresh').pullRefresh().refresh(true); //重置上拉加载
		initShopList();
	});
}

/**
 * 筛选功能
 */
function searchByType() {
	//行业筛选
	mui("#select_type_popover").on("tap", ".mui-table-view-cell", function(e) {
		var old_type_id = para.typeId;
		if(!old_type_id) {
			old_type_id = '全部行业';
		}
		var type_id = this.getAttribute("type_id");
		mui('#select_type_popover .mui-table-view-cell[type_id="' + old_type_id + '"] span')[0].className = "";
		var old_html = this.innerHTML;
		this.innerHTML = old_html.substring(0, old_html.indexOf("<span")) + '<span class="mui-icon mui-pull-right mui-icon-checkmarkempty"></span>';
		if(type_id == 1) {
			type_id = '';
		}
		para.typeId = type_id;
		initShopList();
		//修改提示内容
		mui(".selectType")[0].innerHTML = "<h5>" + this.getAttribute("type_name") + '<span class="mui-icon mui-icon-arrowdown"></span></h5>';
		mui(".selectType")[1].innerHTML = "<h5>" + this.getAttribute("type_name") + '<span class="mui-icon mui-icon-arrowdown"></span></h5>';
	});
	//商铺排序
	mui("#select_order_popover").on("tap", ".mui-table-view-cell", function(e) {
		var old_order = para.orderCol;
		if(!old_order) {
			old_order = 'type_id';
		}
		mui('#select_order_popover .mui-table-view-cell[order_col="' + old_order + '"] span')[0].className = "";
		var old_order_html = this.innerHTML;
		this.innerHTML = old_order_html.substring(0, old_order_html.indexOf("<span")) + '<span class="mui-icon mui-pull-right mui-icon-checkmarkempty"></span>';
		var orderColumn=this.getAttribute("order_col");
		var orderState=this.getAttribute("order_desc");
		para.orderCol = orderColumn;
		para.orderDesc = orderState;
		initShopList();
		//修改状态排序的顺序
		if(orderColumn=="ent_state"){
			if(orderState=="desc"){
				this.setAttribute("order_desc","asc");
			}else{
				this.setAttribute("order_desc","desc");
			}
		}
		//修改提示内容
		mui(".selectOrder")[0].innerHTML = "<h5>" + this.getAttribute("order_name") + '<span class="mui-icon mui-icon-arrowdown"></span></h5>';
		mui(".selectOrder")[1].innerHTML = "<h5>" + this.getAttribute("order_name") + '<span class="mui-icon mui-icon-arrowdown"></span></h5>';
	});
	//加载行政区域
	var para_city = {};
	/*setTimeout(function(){	
	ai.ajax("cust/getShopCity",para_city,function(data){
		if(data.state){			
			var div_city=mui('#shop_city')[0];
			var ul_city=document.createElement('ul');
			ul_city.className="mui-table-view";
			ul_city.innerHTML='<li class="mui-table-view-cell">四川移动</li>';
			mui.each(data.info,function(index,item){
				var li_city=document.createElement('li');
				li_city.className="mui-table-view-cell"
				li_city.dataset.esop_code=item.ESOP_CODE;
				li_city.innerHTML=item.CITY_NAME;
				ul_city.appendChild(li_city);
			});
			div_city.appendChild(ul_city);
		}
	},function(){
		
	},function(){
		
	})},1500);*/
}

function pulldownRefresh(){
	initShopList();
	mui('#pullrefresh').pullRefresh().endPulldownToRefresh();
}

/**
 * 加载商铺信息列表
 */
function initShopList() {
	plus.nativeUI.showWaiting("正在加载数据,请稍等.");
	document.body.querySelector(".mui-scroll>.mui-table-view").innerHTML = "";
	para.pageNo = 1;
	pullupRefresh();
}
/**
 * 上拉刷新
 */
function pullupRefresh() {
	setTimeout(function() {
		ai.ajax("cust/getAllShopInfo", para, function(data) {
			if(data.state) {
				var shop_list = document.body.querySelector(".mui-scroll>.mui-table-view");
				mui.each(data.info.rows, function(index, item) {
					var li_shop = document.createElement("li");
					li_shop.className = "mui-card mui-table-view-cell";
					li_shop.dataset.ent_code = item.ENT_CODE;
					li_shop.dataset.map_x = item.LONGITUDE;
					li_shop.dataset.map_y = item.LATITUDE;
					li_shop.dataset.ent_name = item.ENT_NAME;
					li_shop.dataset.ent_imgtype = item.ENT_IMGTYPE;
					//联系方式
					var tel_way = "";
					if(!isNull(item.TEL1) && item.TEL1 != '') {
						tel_way += '、' + item.TEL1;
					}
					if(!isNull(item.TEL2) && item.TEL2 != '') {
						tel_way += '、' + item.TEL2;
					}
					//是否具有删除权限
					var del_html = "";
					if(item.EDIT_FLAG && item.EDIT_FLAG == '1') {
						del_html = '<a class="mui-btn mui-btn-red" ent_code="' + item.ENT_CODE + '">删除</a>';
					}
					//添加右滑编辑按钮（客户经理才有权限)
					var edit_html='<a class="mui-btn mui-btn-blue" style="background-color:#0085D0" ent_imgtype="' + item.ENT_IMGTYPE + '" ent_code="' + item.ENT_CODE + '">查看</a>';
					if(ai.user.roles[0].roleId=='2'){
						edit_html='<a class="mui-btn mui-btn-green" ent_imgtype="' + item.ENT_IMGTYPE + '" ent_code="' + item.ENT_CODE + '">编辑</a>';
					}
					li_shop.innerHTML = '<div class="mui-slider-right mui-disabled">'+edit_html + del_html + '</div>' +
						'<div class="mui-slider-handle" ><div class="mui-row shop_state_' + item.ENT_STATE + '" ent_code="' + item.ENT_CODE + '">' +
						'<div class="mui-col-xs-9 mui-text-left"><h4 class="mui-ellipsis">' + item.ENT_NAME + '</h4></div>' +
						'<div class="mui-col-xs-3 mui-text-right"><h6 class="mui-ellipsis">' + item.CITY_CODE + item.COUNTY_CODE + '</h6></div>' +
						'<div class="mui-col-xs-7 mui-text-left"><h6><span>行业：</span>' + item.TYPE_ID + '</h6></div>' +
						'<div class="mui-col-xs-5 mui-text-left"><h6><span>街道：</span>' + (isNull(item.STREET) ? '不详' : item.STREET) + '</h6></div>' +
						'<div class="mui-col-xs-12 mui-text-left"><h6 class="mui-ellipsis"><span>地址：</span>' + item.ADDRESS + '</h6></div>' +
						'<div class="mui-col-xs-12 mui-text-left"><h6><span>联系方式：</span>' + (tel_way == '' ? '无' : tel_way.substring(1)) + '</h6></div>' +
						'</div><div id="shop_detail_' + item.ENT_CODE + '" ent_code="' + item.ENT_CODE + '" class="mui-row shop_detail_hide">' +
						'<div class="mui-col-xs-7 mui-text-left"><h6><span>集团编码：</span>' + (item.ENT_280 == '' ? '无' : item.ENT_280) + '</h6></div>' +
						'<div class="mui-col-xs-5 mui-text-left"><h6><span>集团成员数：</span>' + (item.ENT_MEMBERS == '' ? '无' : item.ENT_MEMBERS) + '</h6></div>' +
						'<div class="mui-col-xs-7 mui-text-left"><h6><span>宽带号码：</span>' + (item.BROADBAND_NUMBER == '' ? '无' : item.BROADBAND_NUMBER) + '</h6></div>' +
						'<div class="mui-col-xs-5 mui-text-left"><h6><span>宽带资源是否覆盖：</span>' + item.BROADBAND  + '</h6></div>' +
						'<div class="mui-col-xs-7 mui-text-left"><h6><span>商务动力座机：</span>' + (item.BUSINESS_TEL == '' ? '无' : item.BUSINESS_TEL) + '</h6></div>' +
						'<div class="mui-col-xs-5 mui-text-left"><h6><span>是否完成集团组网：</span>' + (item.ENT_NETWORK == 'Y' ? '是' : '否') + '</h6></div>' +
						'<div class="mui-col-xs-7 mui-text-left"><h6><span>网格编码：</span>' + (item.GRID_CODE == '' ? '无' : item.GRID_CODE) + '</h6></div>' +
						'<div class="mui-col-xs-5 mui-text-left"><h6><span>网格名称：</span>' + (item.GRID_NAME == '' ? '无' : item.GRID_NAME) + '</h6></div>' +
						'<div class="mui-col-xs-12 mui-text-left"><h6><span>备注：</span>' + (item.REMARK == '' ? '无' : item.REMARK) + '</h6></div>' +
						'</div><h5 id="shop_show_' + item.ENT_CODE + '" class="mui-text-center" entCode="' + item.ENT_CODE + '" ><a>展开<span class="mui-icon mui-icon-arrowdown"></span></a></h5></div>';
					shop_list.appendChild(li_shop);
					//'<div class="mui-col-xs-12 mui-text-left"><h6><span>是否完成集团组网：</span>' + (item.ENT_NETWORK == 'Y' ? '是' : '否') + '</h6></div>' +
					//'<div class="mui-col-xs-7 mui-text-left"><h6><span>商务动力规模数：</span>' + (item.BUSINESS_SCALE == '' ? '无' : item.BUSINESS_SCALE) + '</h6></div>' +
				});
				mui.toast('共' + data.info.total + '条记录,已加载' + (para.pageNo * para.pageSize > data.info.total ? '完毕' : para.pageNo * para.pageSize + '条'));
				if(++para.pageNo > Math.ceil(data.info.total / para.pageSize)) {
					mui('#pullrefresh').pullRefresh().endPullupToRefresh(true); //加载完毕
					mui('#pullrefresh').pullRefresh().endPulldownToRefresh();
				} else {
					mui('#pullrefresh').pullRefresh().endPullupToRefresh(false); //还有更多数据
					mui('#pullrefresh').pullRefresh().endPulldownToRefresh();
				}
			}
		}, function() {
			mui('#pullrefresh').pullRefresh().endPullupToRefresh(false);
			mui('#pullrefresh').pullRefresh().endPulldownToRefresh();
			mui('#select_popover').popover('hide');
		}, function() {
			plus.nativeUI.closeWaiting();
			mui('#select_popover').popover('hide');
		});
	}, 1500);
}
/*
 * 修改行政区域的显示内容
 */
function loadByArea(city_code, county_code, city_name, county_name) {
	para.cityCode = city_name;
	para.countyCode = county_name;
	initShopList();
	//修改提示内容
	mui(".selectArea")[0].innerHTML = '<h5 class="mui-ellipsis">' + city_name + county_name + '<span class="mui-icon mui-icon-arrowdown"></span></h5>';
	mui(".selectArea")[1].innerHTML = '<h5 class="mui-ellipsis">' + city_name + county_name + '<span class="mui-icon mui-icon-arrowdown"></span></h5>';
	//禁止滚动刷新
	mui('#pullrefresh').pullRefresh().setStopped(false);
}

function setTypeCount(){
	//加载数据
	setTimeout(function(){
		ai.ajax("/cust/getShopGroupByType", {}, function(data) {
			if (data.state) {
				var total = 0;
				var div_html="";
				mui.each(data.info, function(index, item) {
					div_html+='<li class="mui-table-view-cell" type_id="'+item.TYPE_ID+'" type_name="'+item.TYPE_ID+'">'+item.TYPE_ID+'<label id="typecount_2">【'+item.TYPE_COUNT+'】</label><span></span></li>';
					total += item.TYPE_COUNT;
					
				});
				div_html='<li class="mui-table-view-cell" type_id="全部行业" type_name="全部行业">全部行业<label id="typecount_1">【'+total+'】</label><span class="mui-icon mui-pull-right mui-icon-checkmarkempty"></span></li>'+div_html;
				mui('#select_type_popover')[0].innerHTML=div_html;
			}
		}, function() {
	
		}, function() {
	
		});
	},500);
}

/**
 * 判断值是否为空（如果等于例外的字符串，也为空）
 * @param {Object} 要判断的值
 * @param {Object} 例外的字符串
 */
function isNull(str, eqstr) {
	if(str == ""||str == "undefined") return true;
	if(typeof(str)=="undefined") return true;
	if(eqstr && str == eqstr) return true;
	var regu = "^[ ]+$";
	var re = new RegExp(regu);
	return re.test(str);
}