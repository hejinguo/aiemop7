mui.init({

});
mui.plusReady(function() {
	var self = plus.webview.currentWebview();
	var add_x = self.add_x;
	var add_y = self.add_y;

	document.getElementById("shopadd_resetbutton").addEventListener('tap', function() {
		mui('.mui-input-group')[0].reset();
	});

	document.getElementById("shoplocation_button").addEventListener('tap', function() {
		getLocation();
	});
	document.getElementById("shop_add").addEventListener('tap', function() {
		addShopInfo();
	});
	if(add_x && add_y) {
		//mui.alert("add_x"+add_x+","+add_y);
		var point = new plus.maps.Point(add_x, add_y);
		plus.maps.Map.reverseGeocode(point, {}, function(event) {
			//mui.alert("d"+JSON.stringify(event));
			var address = event.address; //转换后的地理位置
			var point = event.coord.longitude; //latitude 转换后的坐标信息
			var coordType = event.coordType; // 转换后的坐标系类型
			mui('#ent_address')[0].value = event.address;
			mui('#longitude')[0].innerText = event.coord.longitude;
			mui('#latitude')[0].innerText = event.coord.latitude;
			//alert("Address:" + address + event.coord.longitude + event.coord.latitude);
		}, function(e) {

		});
	} else {
		getLocation();
	}
	//初始化区域选择事件
	mui('.shop_area').on('tap', 'span', function(e) {
		setCityCounty();
	});
	//初始化行业选择
	mui('.shop_typeid').on('tap', 'span', function(e) {
		setTypeId();
	});
	//var map = new plus.maps.Map("map_box",{center:new plus.maps.Point(104.06326999999999,30.66074)});
	//var marker=new plus.maps.Marker(new plus.maps.Point(104.06326999999999,30.66074));
	//marker.setIcon("/logo.png");
	//marker.setLabel("天府广场地标");
	//var bubble = new plus.maps.Bubble("地址打标");
	//marker.setBubble(bubble);
	//map.addOverlay(marker);
});

function getLocation() {
	plus.geolocation.getCurrentPosition(function(p) {
		mui('#ent_city_county')[0].innerText = p.address.city + " " + p.address.district;
		mui('#ent_address')[0].value = p.addresses;
		mui('#ent_street')[0].value = p.address.street;
		mui('#longitude')[0].innerText = p.coords.longitude;
		mui('#latitude')[0].innerText = p.coords.latitude;
		// "Geolocation\nLatitude:" + p.coords.latitude + "\nLongitude:" + p.coords.longitude + "\nAltitude:" + p.coords.altitude
	}, function(e) {
		mui.alert("位置获取失败，请手动填写！");
		//console.log("Gelocation Error: code - "+e.code+"; message - "+e.message);
	}, {
		timeout: 10000
	}); //10s超时
}

function setCityCounty() {
	var cityPicker = new mui.PopPicker({
		layer: 2
	});
	cityPicker.setData(cityData);
	var city_c = document.getElementById("ent_city_county").innerText;
	//console.log(city_c.split(' ').toString());
	cityPicker.setValue(city_c.split(' '));
	cityPicker.show(function(items) {
		document.getElementById("ent_city_county").innerText = items[0].text + " " + items[1].text;
	});
}

function setTypeId() {
	var userPicker = new mui.PopPicker();
	userPicker.setData(typeData);
	userPicker.setValue(document.getElementById("ent_typeid").innerText);
	userPicker.show(function(items) {
		document.getElementById("ent_typeid").innerText = items[0].text;
		//返回 false 可以阻止选择框的关闭
		//return false;
	});
}

function addShopInfo() {
	var ent_name = document.getElementById("ent_name").value;
	var ent_city_county = document.getElementById("ent_city_county").innerText;
	var ent_city = ent_city_county.split(' ')[0];
	var ent_county = ent_city_county.split(' ')[1];
	var ent_typeid = document.getElementById("ent_typeid").innerText;
	var ent_street = document.getElementById("ent_street").value;
	var ent_address = document.getElementById("ent_address").value;
	var ent_tel1 = document.getElementById("ent_tel1").value;
	var ent_tel2 = document.getElementById("ent_tel2").value;
	var longitude = document.getElementById("longitude").innerText;
	var latitude = document.getElementById("latitude").innerText;
	var shopInfo = '{"ent_name":"' + ent_name + '","city":"' +
		ent_city + '","county":"' + ent_county + '","typeid":"' + ent_typeid + '","street":"' +
		ent_street + '","address":"' + ent_address + '","tel1":"' + ent_tel1 + '","tel2":"' +
		ent_tel2 + '","longitude":"' + longitude + '","latitude":"' + latitude + '"}';
	var para = {
		'shopInfo': shopInfo
	};
	if(isNull(ent_name)) {
		//mui.alert("请输入");
		setTimeout(function() {
			document.getElementById("ent_name").value = "";
			document.getElementById("ent_name").focus();
		}, 100);
	} else if(isNull(ent_city, '请选择')) {
		setCityCounty();
	} else if(isNull(ent_typeid, '请选择')) {
		setTypeId();
	} else if(isNull(ent_address)) {
		document.getElementById("ent_address").value = "";
		document.getElementById("ent_address").focus();
	} else if(isNull(longitude) || isNull(latitude)) {
		mui.toast("请重新定位！");
	} else if(!isNull(ent_name) && !isNull(ent_city, '请选择') && !isNull(ent_typeid, '请选择') && !isNull(ent_address) && !isNull(longitude) && !isNull(latitude)) {
		plus.nativeUI.showWaiting("正在处理,请稍等.");
		ai.ajax("cust/addShopInfo", para, function(data) {
			if(data.state) {
				//console.log(data.info.toString());
				/*mui.alert('添加成功！', function() {
					mui.back();
				});*/
				mui.toast("添加成功！");
			}
		}, function() {

		}, function() {
			plus.nativeUI.closeWaiting();
			mui.back();
		});
	}
}

function isNull(str, eqstr) {
	if(str == "") return true;
	if(eqstr && str == eqstr) return true;
	var regu = "^[ ]+$";
	var re = new RegExp(regu);
	return re.test(str);
}