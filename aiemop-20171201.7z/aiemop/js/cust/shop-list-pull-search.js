mui.init({
	swipeBack: true
});
var para = {
	'cityCode': 1
};

mui.ready(function() {
	mui('.mui-scroll-wrapper').scroll();
	//加载地市
	loadCityCode();
	//绑定地市点击事件
	mui('#shop_city').on('tap', 'a', function(e) {
		mui('#segmentedContent').scroll().scrollTo(0,0);
	});
	//加载区县	
	loadCountyCode();

	//区县点击事 件
	mui('#shop_county').on('tap', 'li', function(e) {
		var city_code = this.getAttribute("esop_code");
		var county_code = this.getAttribute("county_code");
		var city_name = this.getAttribute("city_name");
		var county_name = this.getAttribute("county_name");
		//mui.alert(city_code+","+county_code);
		window.parent.loadByArea(city_code, county_code,city_name,county_name);
	});
});
function loadCityCode(){
	setTimeout(function() {
		ai.ajax("cust/getShopCity",{},function(data){
			if(data.state){
				var shop_city=mui('#segmentedControls')[0];
				var total=0;
				var html_city="";
				mui.each(data.info,function(index,item){
					/*cityc+="{value:'"+item.CITY_NAME+"',text:'"+item.CITY_NAME+"',children:[";
					if(item.ESOP_CODE>18){
					ai.ajax("cust/getShopCounty",{'cityCode': item.ESOP_CODE},function(data1){
						if(data1.state){
							mui.each(data1.info,function(index,item){
								cityc+="{value:'"+item.COUNTY_NAME+"',text:'"+item.COUNTY_NAME+"'},";
							});
						}
					},function(){},function(){});
					cityc+="]},";
					}*/
					html_city+='<a class="mui-control-item" href="#county_'+item.ESOP_CODE+'">'+item.CITY_NAME+'<label>【'+item.ENT_COUNT+'】</label></a>';
					total+=item.ENT_COUNT;
				});
				if(data.info.length>2){
					html_city='<a class="mui-control-item" href="#county_1">四川移动<label>【'+total+'】</label></a>'+html_city;
				}
				shop_city.innerHTML=html_city;
			}
		},function(){
			
		},function(){
			var controls = document.getElementById("segmentedControls");
			if(controls.querySelector('.mui-control-item')){
				controls.querySelector('.mui-control-item').classList.add('mui-active');
			}
		});
	},1500);
}

//加载区县
function loadCountyCode() {
	var shop_county = mui('#shop_county')[0];
	setTimeout(function() {
		var html_county = '';
		ai.ajax("cust/getShopCounty", para, function(data) {
			if (data.state) {
				//加载全省区县(如果区县数量大于50,加载全省)
				if(data.info.length>50){
					html_county += '<div id="county_1" class="mui-control-content mui-active"><ul>'+
					'<li class="mui-table-view-cell" esop_code="1" county_code="1" city_name="全省" county_name="">全省</li>';
					mui.each(data.info, function(index, item) {
						html_county += '<li class="mui-table-view-cell" esop_code="' + item.ESOP_CODE + '" county_code="' + item.COUNTY_CODE + '" city_name="' + item.CITY_NAME + '" county_name="' + item.COUNTY_NAME + '">' + item.COUNTY_NAME + '<label>【'+item.ENT_COUNT+'】</label></li>';
					});
					html_county += "</ul></div>";
					var curr_city=2;
					html_county += '<div id="county_2" class="mui-control-content"><ul>'+
					'<li class="mui-table-view-cell" esop_code="2" county_code="1" city_name="成都市" county_name="">全市</li>';
					mui.each(data.info, function(index, item) {
						if(curr_city==item.ESOP_CODE){
							html_county += '<li class="mui-table-view-cell" esop_code="' + item.ESOP_CODE + '" county_code="' + item.COUNTY_CODE + '" city_name="' + item.CITY_NAME + '" county_name="' + item.COUNTY_NAME + '">' + item.COUNTY_NAME + '<label>【'+item.ENT_COUNT+'】</label></li>';
						}else{
							curr_city=item.ESOP_CODE;
							html_county += '</ul></div><div id="county_'+item.ESOP_CODE+'" class="mui-control-content"><ul>'+
							'<li class="mui-table-view-cell" esop_code="' +item.ESOP_CODE + '" county_code="1" city_name="' + item.CITY_NAME + '" county_name="">全市</li>';
							html_county +='<li class="mui-table-view-cell" esop_code="' + item.ESOP_CODE + '" county_code="' + item.COUNTY_CODE + '" city_name="' + item.CITY_NAME + '" county_name="' + item.COUNTY_NAME + '">' + item.COUNTY_NAME + '<label>【'+item.ENT_COUNT+'】</label></li>';
						}
					});
					//console.log(html_county);
					html_county += "</ul></div>";
				}else{//按照地市加载
					html_county='<div id="county_'+data.info[0].ESOP_CODE+'" class="mui-control-content mui-active"><ul>'+
					'<li class="mui-table-view-cell" esop_code="' +data.info[0].ESOP_CODE + '" county_code="1" city_name="' + data.info[0].CITY_NAME + '" county_name="">全市</li>';
					mui.each(data.info, function(index, item) {
						html_county += '<li class="mui-table-view-cell" esop_code="' + item.ESOP_CODE + '" county_code="' + item.COUNTY_CODE + '" city_name="' + item.CITY_NAME + '" county_name="' + item.COUNTY_NAME + '">' + item.COUNTY_NAME +'<label>【'+item.ENT_COUNT+'】</label></li>';
					});
					html_county += "</ul></div>";
				}
				//console.log(html_county);
				shop_county.innerHTML = html_county;
			}
		}, function() {

		}, function() {
			
		});
	}, 1500);
	//console.log(html_all);		
}