mui.init({
	swipeBack: true
});

mui.plusReady(function() {
	var self = plus.webview.currentWebview();
	//判断本地是否有该商铺照片
	var img_url = "_downloads/" +self.ent_code+"."+self.ent_imgtype;
	plus.io.resolveLocalFileSystemURL(img_url, function(entry) {
		setShopInfo(self.ent_code,'Y',entry.fullPath);
	},function(){
		setShopInfo(self.ent_code,'N','');
	});
	//初始化开关操作事件
	mui('.mui-table-view-cell .mui-switch').each(function() {
		this.addEventListener('toggle', function(event) {
			//event.detail.isActive 可直接获取当前状态
			this.parentNode.querySelector('label').innerText = event.detail.isActive ? '是' : '否';
		});
	});
	//保存按钮事件
	mui('.mui-content').on('tap', '.mui-btn-red', function(e) {
		updateShopInfo();
	});
	//取消按钮事件
	mui('.mui-content').on('tap', '.mui-btn-green', function(e) {
		mui.back();
	});
	mui('.mui-bar').on('tap', '.mui-btn-link', function() {
		updateShopInfo();
	});
	//初始化区域选择事件
	mui('.shop_area').on('tap', 'span', function(e) {
		setCityCounty();
	});
	//初始化行业选择
	mui('.shop_typeid').on('tap', 'span', function(e) {
		setTypeid();
	});
	//商铺门头照片上传
	mui('.shop_image').on('tap', 'img', function(e) {
		var btnArray = [{
			title: "拍照上传"
		}, {
			title: "从相册选择"
		}, {
			title: "清空已选择"
		}];
		plus.nativeUI.actionSheet({
			title: "选择照片",
			cancel: "取消",
			buttons: btnArray
		}, function(e) {
			var index = e.index;
			switch(index) {
				case 0:
					break;
				case 1:
					cameraimages();
					break;
				case 2:
					galleryImg();
					break;
				case 3:
					mui('#ent_image')[0].innerHTML = '<img width="200px" height="90px" src="../../images/cust/shop-icon.png"/>';
					break;
			}
		});
	});
});

/**
 * 初始化商铺信息
 * @param {Object} shopCode
 */
function setShopInfo(shopCode,haveImage,imgURL) {
	var para = {
		'shopCode': shopCode,
		'haveImage':haveImage
	};
	ai.ajax("cust/getShopInfoByCode", para, function(data) {
		if(data.state) {
			var shopdata = data.info[0];
			document.getElementById("shopCode").innerText = shopdata.ENT_CODE;
			document.getElementById("shop_typecode").innerText = shopdata.TYPE_CODE;
			//基础属性赋值
			document.getElementById("ent_name").value = shopdata.ENT_NAME;
			document.getElementById("ent_city_county").innerText = shopdata.CITY_CODE + " " + shopdata.COUNTY_CODE;
			document.getElementById("ent_typeid").innerText = shopdata.TYPE_ID;
			if(!isNull(shopdata.MARKET_NAME)){
				document.getElementById("ent_market_name").value=shopdata.MARKET_NAME;
				document.getElementById("ent_market_name").className="";
			}else{
				document.getElementById("ent_market_name").className="mui-hidden";
			}
			document.getElementById("ent_street").value = shopdata.STREET;
			document.getElementById("ent_address").value = shopdata.ADDRESS;
			document.getElementById("ent_tel_name").value = shopdata.TEL_NAME;
			document.getElementById("ent_tel1").value = shopdata.TEL1;
			document.getElementById("ent_tel2").value = shopdata.TEL2;
			//扩展属性赋值
			var network = document.getElementById("ent_network");
			var n_value = document.getElementById("network");
			if(shopdata.ENT_NETWORK == 'Y') {
				n_value.innerText = "是";
				network.className = "mui-switch mui-switch-blue mui-active";
			} else {
				n_value.innerText = "否";
				network.className = "mui-switch mui-switch-blue";
			}
			var boradband = document.getElementById("ent_broadband");
			var b_value = document.getElementById("broadband");
			if(shopdata.BROADBAND == '是') {
				b_value.innerText = "是";
				boradband.className = "mui-switch mui-switch-blue mui-active";
			} else {
				b_value.innerText = "否";
				boradband.className = "mui-switch mui-switch-blue";
			}
			var isflag = document.getElementById("ent_isflag");
			var i_value = document.getElementById("isflag");
			if(shopdata.FLAG == '是') {
				i_value.innerText = "是";
				isflag.className = "mui-switch mui-switch-blue mui-active";
			} else {
				i_value.innerText = "否";
				isflag.className = "mui-switch mui-switch-blue";
			}
			document.getElementById("ent_280").value = shopdata.ENT_280;
			document.getElementById("ent_membernums").value = shopdata.ENT_MEMBERS;
			//document.getElementById("ent_business").value = shopdata.BUSINESS_SCALE;
			document.getElementById("ent_broadbandnum").value = shopdata.BROADBAND_NUMBER;
			document.getElementById("ent_business_tel").value = shopdata.BUSINESS_TEL;
			document.getElementById("ent_gridcode").value = shopdata.GRID_CODE;
			document.getElementById("ent_gridname").value = shopdata.GRID_NAME;
			document.getElementById("ent_remark").value = shopdata.REMARK;
			//加载图片
			if(haveImage=='Y'){
				mui('#ent_image')[0].innerHTML = '<img width="200px" height="90px" src="' + imgURL+ '"/>';
			}else if(!isNull(shopdata.ENT_IMAGE)){
				mui('#ent_image')[0].innerHTML = '<img width="200px" height="90px" src="'+ai.appPathObject.emop+'cust/getShopImage?entCode='+ shopdata.ENT_IMAGE+'&version='+new Date().getTime()+'"/>';
			}
		}
	}, function() {

	}, function() {
		//个性化信息
		setExpandInfo();
	});
}

function setCityCounty() {
	var cityPicker = new mui.PopPicker({
		layer: 2
	});
	cityPicker.setData(cityData);
	var city_c = document.getElementById("ent_city_county").innerText;
	//console.log(city_c.split(' ').toString());
	cityPicker.setValue(city_c.split(' '));
	cityPicker.show(function(items) {
		document.getElementById("ent_city_county").innerText = items[0].text + " " + items[1].text;
	});
}

function setTypeid() {
	var userPicker = new mui.PopPicker();
	userPicker.setData(typeData);
	userPicker.setValue(document.getElementById("ent_typeid").innerText);
	userPicker.show(function(items) {
		document.getElementById("ent_typeid").innerText = items[0].text;
		if (items[0].text=="楼宇市场"||items[0].text=="园区市场"||items[0].text=="聚类市场") {
			document.getElementById("ent_market_name").className="";
		}else{
			document.getElementById("ent_market_name").className="mui-hidden";
		}
		//返回 false 可以阻止选择框的关闭
		//return false;
	});
}
/**
 * 设置星级
 */
function setEntStar() {
	var userPicker = new mui.PopPicker();
	userPicker.setData(hotelExpandData);
	userPicker.setValue(document.getElementById("ent_star").innerText);
	userPicker.show(function(items) {
		document.getElementById("ent_star").innerText = items[0].text;
		//返回 false 可以阻止选择框的关闭
		//return false;
	});
}

/**
 * 获取扩展信息
 * @param 商铺编码 entCode
 */
function setExpandInfo() {
	var type_code = document.getElementById("shop_typecode").innerText;
	var shopCode = mui('#shopCode')[0].innerText;
	if(!isNull(type_code)) {
		var para = {
			'entCode': shopCode,
			'typeId': type_code
		};
		ai.ajax("cust/getExpandShopInfo", para, function(data) {
			if(data.state && JSON.stringify(data.info).length > 2) {
				var div_html = '<div class="mui-col-xs-12 shop_info_title ">个性化信息</div>';
				mui.each(data.info, function(index, item) {
					if(item.K_NAME == "星级数") {
						div_html += '<div class="mui-text-left mui-input-row shop_star"><label>' + item.K_NAME + '：</label>';
						div_html += '<span id="ent_star">' + (isNull(item.K_VALUE) ? '请选择' : item.K_VALUE) + '</span><span class="mui-icon mui-icon-arrowdown"></span></div>';
					} else {
						div_html += '<div class="mui-text-left mui-input-row"><label>' + item.K_NAME + '：</label>';
						div_html += '<input id="ent_' + item.K_ID + '" k_id="' + item.K_ID + '" type="text" value="' + (isNull(item.K_VALUE) ? '' : item.K_VALUE) + '" placeholder="请输入' + item.K_NAME + '"></div>';
					}
				});
				mui('div#expandShopInfo')[0].innerHTML = div_html;
				mui('div#expandShopInfo')[0].className = "";
			}
		}, function() {

		}, function() {
			if(mui('div#expandShopInfo')[0].innerHTML.indexOf("ent_star", 0) > 0) {
				mui('.shop_star').on('tap', 'span', function(e) {
					setEntStar();
				});
			}
		});
	}
}

function updateShopInfo() {
	var ent_code = document.getElementById("shopCode").innerText;
	var ent_name = document.getElementById("ent_name").value;
	var ent_city_county = document.getElementById("ent_city_county").innerText;
	var ent_city = ent_city_county.split(' ')[0];
	var ent_county = ent_city_county.split(' ')[1];
	var ent_typeid = document.getElementById("ent_typeid").innerText;
	var ent_market_name=document.getElementById("ent_market_name").value;
	var type_code = document.getElementById("shop_typecode").innerText;
	var ent_street = document.getElementById("ent_street").value;
	var ent_address = document.getElementById("ent_address").value;
	var ent_tel_name = document.getElementById("ent_tel_name").value;
	var ent_tel1 = document.getElementById("ent_tel1").value;
	var ent_tel2 = document.getElementById("ent_tel2").value;

	var ent_280 = document.getElementById("ent_280").value;
	var ent_membernums = document.getElementById("ent_membernums").value;
	var ent_broadband_num = document.getElementById("ent_broadbandnum").value;
	var ent_business_tel = document.getElementById("ent_business_tel").value;
	var ent_gridcode = document.getElementById("ent_gridcode").value;
	var ent_gridname = document.getElementById("ent_gridname").value;
	var ent_remark = document.getElementById("ent_remark").value;
	//照片数据获取
	var ent_image = mui('#shop_base64')[0].innerText;
	var ent_imgtype=mui('#shop_imgtype')[0].innerText;
	//个性化数据获取
	var expand_info = "";
	//处理特殊数据（星级数）
	if(mui('div#expandShopInfo')[0].innerHTML.indexOf("ent_star", 0) > 0 && !isNull(mui('#ent_star')[0].innerText, '请选择')) {
		expand_info += '{"KID":"31","KValue":"' + mui('#ent_star')[0].innerText + '"},';
	}
	mui('div#expandShopInfo input').each(function() {
		if(!isNull(this.value)) {
			var kid = this.getAttribute("k_id");
			expand_info += '{"KID":"' + kid + '","KValue":"' + this.value + '"},';
		}
	});
	var shopInfo = '{"ent_code":"' + ent_code + '","ent_name":"' + ent_name + '","city":"' +
		ent_city + '","county":"' + ent_county + '","typeid":"' + ent_typeid+'","marketname":"'+ent_market_name+ '","street":"' +
		ent_street + '","address":"' + ent_address +'","telname":"'+ ent_tel_name+'","tel1":"' + ent_tel1 + '","tel2":"' +
		ent_tel2 + '","ent_280":"' + ent_280 + '","membernums":"' + ent_membernums + '","broadnum":"' +
		ent_broadband_num + '","business_tel":"' + ent_business_tel +'","gridcode":"'+ent_gridcode+'","gridname":"'+ent_gridname+ '","remark":"' + ent_remark + '","typeCode":"' +
		type_code + '","ent_image":"' + ent_image + '","ent_imgtype":"' + ent_imgtype + '"';
	if(!isNull(expand_info)) {
		shopInfo += ',"expandInfo":[' + expand_info.substring(0, expand_info.length - 1) + ']}';
	} else {
		shopInfo += ',"expandInfo":""}';
	}
	var para = {
		'shopInfo': shopInfo
	};
	//mui.alert(shopInfo);
	if(isNull(ent_name)) {
		//mui.alert("请输入");
		setTimeout(function() {
			document.getElementById("ent_name").value = "";
			document.getElementById("ent_name").focus();
		}, 200);
	} else if(isNull(ent_city, '请选择')) {
		setCityCounty();
	} else if(isNull(ent_typeid, '请选择')) {
		setTypeId();
	} else if(isNull(ent_address)) {
		document.getElementById("ent_address").value = "";
		document.getElementById("ent_address").focus();
	} else if(!isNumber(ent_280)) {
		mui.toast("商务动力规模为数字!");
		document.getElementById("ent_280").value = "";
		document.getElementById("ent_280").focus();
	} else if(!isNumber(ent_membernums)) {
		mui.toast("成员数为数字！");
		document.getElementById("ent_membernums").value = "";
		document.getElementById("ent_membernums").focus();
	} else if(!isNumber(ent_broadband_num)) {
		mui.toast("宽带号码为数字！");
		document.getElementById("ent_broadbandnum").value = "";
		document.getElementById("ent_broadbandnum").focus();
	} else if(!isNull(ent_name) && !isNull(ent_city, '请选择') && !isNull(ent_typeid, '请选择') && !isNull(ent_address) && isNumber(ent_280) && isNumber(ent_membernums) && isNumber(ent_broadband_num)) {
		plus.nativeUI.showWaiting("正在处理,请稍等.");
//		alert(JSON.stringify(para));
		ai.ajax("cust/updateShopInfo", para, function(data) {
			if(data.state) {
				//console.log(data.info.toString());
				/*mui.alert('修改成功', function() {
					mui.back();
				});*/
				mui.toast("修改成功！");
			}
		}, function() {

		}, function() {
			plus.nativeUI.closeWaiting();
			mui.back();
		});
	}
}

// 全局数组对象，添加文件,用于压缩上传使用
var shop_img = new Array();
/**
 * 从相册中选择单张照片
 */
function galleryImg() {
	//每次拍摄或选择图片前清空数组对象
	shop_img.splice(0, shop_img.length);

	// 从相册中选择图片
	mui.toast("从相册中选择一张图片");
	plus.gallery.pick(function(path) {
		showImg(path);
	}, function(e) {
		//mui.toast("取消选择图片");
	}, {
		filter: "image",
		multiple: false
	});
}

/**
 * 通过拍照上传照片
 */
function cameraimages() {
	var cmr = plus.camera.getCamera();
	cmr.captureImage(function(p) {
		plus.io.resolveLocalFileSystemURL(p, function(entry) {
			var localurl = entry.toLocalURL(); //把拍照的目录路径，变成本地url路径，例如file:///........之类的。
			showImg(localurl);
		});
	}, function(e) {
		mui.toast("拍照上传失败！");
	});
}

/**
 * 处理照片
 * @param {Object} url
 */
function showImg(url) {
	//alert(url);
	//文件名为商铺编码
	var arr_url = url.split(".");
	var img_type=arr_url[arr_url.length - 1];
	if(img_type.toLowerCase()=="png"||img_type.toLowerCase()=="jpg"){
	var img_url = "_downloads/" + mui('#shopCode')[0].innerText + "." + arr_url[arr_url.length - 1];
	plus.io.resolveLocalFileSystemURL(url, function(entry) {
		// 可通过entry对象操作文件 
		entry.file(function(file) {
			if(file.size / 1024 > 2200) {
				mui.toast("文件大小不能超过2M!");
			} else {
				//压缩保存文件
				plus.zip.compressImage({
						src: url,
						dst: img_url,
						overwrite: true,
						quality: 20
					},
					function(e) {
						var url = e.target.toString();
						getBase64Code(url);
						mui('#ent_image')[0].innerHTML = '<img width="200px" height="90px" src="' + e.target + '?' + Math.random() + '"/>';
					},
					function(error) {
						mui.toast("照片选择失败！");
					});
			}
		});
	}, function(e) {
		mui.toast("照片选择失败！");
	});
	}else{
		mui.toast("只能上传JPEG或者PNG格式照片！")
	}
};
/**
 * 判断值是否为空（如果等于例外的字符串，也为空）
 * @param {Object} 要判断的值
 * @param {Object} 例外的字符串
 */
function isNull(str, eqstr) {
	if(str == "" || str == "undefined") return true;
	if(typeof(str) == "undefined") return true;
	if(eqstr && str == eqstr) return true;
	var regu = "^[ ]+$";
	var re = new RegExp(regu);
	return re.test(str);
}

/**
 * 判断是否为数字
 * @param {Object} s
 */
function isNumber(s) {
	var regu = "^[0-9]+$";
	var re = new RegExp(regu);
	if(isNull(s, '无')) {
		return true;
	}
	if(s.search(re) != -1) {
		return true;
	} else {
		return false;
	}
}
/**
 * 获取图片的base64编码
 * @param {Object} url
 */
function getBase64Code(url) {
	//文件类型
	var arr_url = url.split(".");
	mui('#shop_imgtype')[0].innerText= arr_url[arr_url.length - 1];
	//base64编码
	var bitmap = new plus.nativeObj.Bitmap();
	bitmap.load(url.replace("///", "//"), function() {
		var base64 = bitmap.toBase64Data();
		mui('#shop_base64')[0].innerText = base64;
	}, function() {
		return null;
	});
}