mui.init({
	swipeBack: false
	//,statusBarBackground: '#3BAEE7'
});

mui.plusReady(function(){
//	添加商铺信息
//	document.getElementById("showaddshop_button").addEventListener('tap', function() {
//		mui.openWindow({
//			url:'shop-add.html',
//			id:'page-shop-add'
//			//,styles:{top:immersed+'px',bottom:'0px'}//窗口参数
//		});
//	});
});