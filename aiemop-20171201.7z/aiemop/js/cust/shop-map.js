mui.init({

});
var ws = null;
var em = null,
	map = null,
	pcenter = null;
mui.plusReady(function() {

	//定位当前位置
	mui(".mui-bar").on("tap", ".mui-icon-location", function() {
		map.showUserLocation(true);
		map.getUserLocation(function(state, pos) {
			if(0 == state) {
				map.setCenter(pos);
			}
		});
	});
});

function plusReady() {
	// 确保DOM解析完成
	if(!em || ws) {
		return
	};
	// 获取窗口对象
	ws = plus.webview.currentWebview();
	wo = ws.opener();
	if(isNull(ws.map_x) || isNull(ws.map_y)) {
		mui.toast("坐标不明确");
		pcenter = new plus.maps.Point(104.072204, 30.663484);
	}else{
		//高德地图坐标为(116.3974357341,39.9085574220), 百度地图坐标为(116.3975,39.9074)
		pcenter = new plus.maps.Point(ws.map_x, ws.map_y);
	}
	setTimeout(function() {
		map = new plus.maps.Map("map");
		map.centerAndZoom(pcenter, 18);
		createMark(ws.map_x, ws.map_y, ws.ent_name, ws.ent_code);
		map.showZoomControls(true);
		map.onclick = function(point) {
			mui.confirm('是否在此添加商铺?', '添加商铺', ['否', '是'], function(e) {
				if(e.index == 1) {
					ai.openWindow({
						url: 'shop-add.html',
						id: 'page-shop-add',
						extras: {
							add_x: point.getLng(),
							add_y: point.getLat()
						}
					});
				}
			});
		}
	}, 300);

}
if(window.plus) {
	plusReady();
} else {
	document.addEventListener("plusready", plusReady, false);
}
// DOMContentloaded事件处理
document.addEventListener("DOMContentLoaded", function() {
	em = document.getElementById("map");
	window.plus && plusReady();
}, false);

//创建定位图标
function createMark(shop_x, shop_y, shop_name, shop_code) {
	var marker = new plus.maps.Marker(new plus.maps.Point(shop_x, shop_y));
	marker.setIcon("../../images/shop/local.png");
	//marker.setLabel("政企营销");
	var bubble = new plus.maps.Bubble(shop_name);
	bubble.onclick = function(bubble) {
		ai.openWindow({
			url: "shop-edit.html",
			id: "page-shop-edit",
			extras: {
				ent_code: shop_code
			}
		});
	};
	marker.setBubble(bubble, true);
	marker.onclick = function(marker) {
		ai.openWindow({
			url: "shop-edit.html",
			id: "page-shop-edit",
			extras: {
				ent_code: shop_code
			}
		});
	}
	map.addOverlay(marker);
}

/**
 * 判断值是否为空（如果等于例外的字符串，也为空）
 * @param {Object} 要判断的值
 * @param {Object} 例外的字符串
 */
function isNull(str, eqstr) {
	if(str == "" || str == "undefined") return true;
	if(typeof(str) == "undefined") return true;
	if(eqstr && str == eqstr) return true;
	var regu = "^[ ]+$";
	var re = new RegExp(regu);
	return re.test(str);
}