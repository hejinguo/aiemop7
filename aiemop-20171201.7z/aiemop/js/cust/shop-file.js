mui.init({

});
var ws = null,
	wc = null;
mui.plusReady(function() {
	//mui('#file_popover').popover('show');
	ws = plus.webview.currentWebview();
	// 用户点击后
	ws.addEventListener("maskClick", function() {
		wc.close("auto");
	}, false);
	//点击选择文件
	mui('#files').on('tap', 'p', function() {
		//getAndroidFile('');
		//mui('.mui-scroll-wrapper').scroll();
		//mui('#file_popover').popover('show');
		showSide();
	});
	// 点击打开文件夹或者选中文件
	mui('#list').on('tap', 'li', function() {
		var data_type = this.getAttribute("data-type");
		var name = this.getAttribute("name");
		var par_path = this.getAttribute("par_path");
		var filepath = par_path + '/' + name;
		//打开文件夹
		if(data_type == "Folder") {
			var File = plus.android.importClass("java.io.File");
			var subRoot = new File(filepath);
			getAndroidFile(subRoot);
			//路径中增加选择的路径
			var list_path = document.getElementById("list_path");
			list_path.innerHTML += '<li class="mui-table-cell mui-media">' + name + '<span class="mui-icon mui-pull-right mui-icon-arrowright"></span></li>';
		} else if(data_type == "File") {
			//点击文件，选中文件
			var li = document.createElement("li")
			li.setAttribute("file_path", filepath);
			li.innerText = name;
			var check_file = document.getElementById("files");
			check_file.innerHTML = "";
			check_file.appendChild(li);
			mui('#file_popover').popover('hide');
		}
		mui('.mui-scroll-wrapper').scroll().scrollTo(0, 0, 100);
	});
	//点击上传文件
	mui('#file_upload')[0].addEventListener('tap', function() {
		uploadFile();
	});
	//点击清空已选择文件
	mui('#file_clear')[0].addEventListener('tap', function() {
		localStorage.setItem("filename","");
		localStorage.setItem("filepath","");
		document.getElementById("files").innerHTML = '<p id="empty" style="font-size:14px;color:#17AAEB;">点击选择文件</p>';
	});
});

/**
 * 列出文件夹和文件目录
 * @param {文件目录} fileForder
 */
function getAndroidFile(fileForder) {
	var sdRoot;
	if(fileForder == '') {
		sdRoot = getSDRoot();
	} else {
		sdRoot = fileForder;
	}
	var files = plus.android.invoke(sdRoot, "listFiles");
	var len = files.length;

	var list = document.getElementById("list");
	var fragFolder = document.createDocumentFragment();
	var fragFile = document.createDocumentFragment();
	//显示遮罩
	var mask = mui.createMask();
	mask.show();
	plus.nativeUI.showWaiting("正在查找文件，请稍候...");
	//处理当前目录下的文件夹和文件
	for(var i = 0; i < len; i++) {
		var file = files[i];
		//判断是否隐藏文件
		if(!plus.android.invoke(file, "isHidden")) {
			var name = plus.android.invoke(file, "getName");
			var li = document.createElement("li");
			li.className = "mui-table-cell mui-media";
			li.setAttribute("name", name);
			li.setAttribute("par_path", sdRoot);
			//判断是文件夹还是文件
			if(plus.android.invoke(file, "isDirectory")) {
				//列表中列出文件夹
				li.setAttribute('data-type', 'Folder');
				var obj = readSonFilenum(file);
				li.innerHTML = '<a class="mui-navigate-right">' +
					'<img class="mui-media-object mui-pull-left" src="../../images/cust/folder.png">' +
					'<div class="mui-media-body mui-ellipsis">' + name +
					'<p class="mui-ellipsis">文件夹数量：' + obj.subFolderNum + ' 文件数量：' + obj.subFileNum + '</p></div></a>';
				fragFolder.appendChild(li);
			} else if(name.indexOf("xlsx") > -1) {
				li.setAttribute('data-type', 'File');
				// 读文件大小
				var fileSizeString = readFileSize(file);
				li.innerHTML = '<a class="mui-navigate-right">' +
					'<img class="mui-media-object mui-pull-left" src="../../images/cust/file.png">' +
					'<div class="mui-media-body mui-ellipsis">' + name +
					'<p class="mui-ellipsis">' + fileSizeString + '</p></div></a>';
				fragFile.appendChild(li);
			}
		}
	}
	mask.close();
	plus.nativeUI.closeWaiting();
	//清空原来内容
	list.innerHTML = "";
	list.appendChild(fragFolder);
	list.appendChild(fragFile);
	//console.log(list.innerHTML);
}
/**
 * 以递归的方式获取符合格式的
 * @param {文件目录} fileForder
 */
function getExcelFile(fileForder) {
	var sdRoot;
	if(fileForder == '') {
		sdRoot = getSDRoot();

	} else {
		sdRoot = fileForder;
	}
	//console.log(sdRoot);
	var files = plus.android.invoke(sdRoot, "listFiles");
	var len = files.length;

	var list = document.getElementById("list");
	var fragFile = document.createDocumentFragment();
	var li;
	for(var i = 0; i < len; i++) {
		var file = files[i];
		//判断是否隐藏文件
		if(!plus.android.invoke(file, "isHidden")) {
			var name = plus.android.invoke(file, "getName");
			li = document.createElement("li");
			li.className = "mui-table-cell mui-media";
			li.setAttribute("name", name);
			//判断是文件夹还是文件;如果是文件夹循环获取符合条件的文件
			if(plus.android.invoke(file, "isDirectory")) {
				var filepath = sdRoot + '/' + name;
				var File = plus.android.importClass("java.io.File");
				var subRoot = new File(filepath);
				getExcelFile(subRoot);
			} else if(name.indexOf("xlsx") > 0) {
				li.setAttribute('data-type', 'File');
				// 读文件大小
				var fileSizeString = readFileSize(file);
				li.innerHTML = '<a class="mui-navigate-right">' +
					'<img class="mui-media-object mui-pull-left" src="../../images/cust/folder.png">' +
					'<div class="mui-media-body mui-ellipsis">' + name +
					'<p class="mui-ellipsis">' + fileSizeString + '</p></div></a>';
				fragFile.appendChild(li);
			}
			list.appendChild(fragFile);
		}
	}
}

/**
 * 上传文件
 */
function uploadFile() {
	if(mui('#files>li').length < 1) {
		mui.toast("请先选择文件");
	} else {
		var filepath = "file:///" + mui('#files>li')[0].getAttribute("file_path");
		var up_url = ai.appPathObject.emop + "cust/file/uploadfile";
		console.log(filepath);
		var task = plus.uploader.createUpload(up_url, {
			method: "POST"
		}, function(upload, status) {
			if(status == 200) {
				mui.toast("上传成功");
			} else {
				mui.toast("上传失败！");
			}
		});
		task.addFile(filepath, {
			key: 'shopdata'
		});
		task.start();
	}
}

// 显示侧滑页面
function showSide() {
	// 防止快速点击可能导致多次创建
	if(wc) {
		return;
	}
	// 开启遮罩
	ws.setStyle({
		mask: "rgba(0,0,0,0.5)"
	});
	// 创建侧滑页面
	wc = plus.webview.create("shop-file-choose.html", "side", {
		left: "10%",
		width: "90%",
		top: "44px",
		popGesture: "close"
	});
	wc.addEventListener('popGesture', function(e) {
		console.log(e.title);
	});
	// 侧滑页面关闭后关闭遮罩
	wc.addEventListener('close', function() {
		var c_path=localStorage.getItem("filepath");
		var c_name=localStorage.getItem("filename");
		if(!isNull(c_path)&&!isNull(c_name)){
			chooseFile(c_path,c_name);
		}
		ws.setStyle({
			mask: "none"
		});
		wc = null;
	}, false);
	// 侧滑页面加载后显示（避免白屏）
	wc.addEventListener("loaded", function() {
		wc.show("slide-in-right", 200);
	}, false);
}
//侧滑页面关闭后更新文件显示
function chooseFile(filepath,name) {
	//点击文件，选中文件
	var li = document.createElement("li")
	li.setAttribute("file_path", filepath);
	li.innerText = name;
	var check_file = document.getElementById("files");
	check_file.innerHTML = "";
	check_file.appendChild(li);
}
/**
 * 判断值是否为空（如果等于例外的字符串，也为空）
 * @param {Object} 要判断的值
 * @param {Object} 例外的字符串
 */
function isNull(str, eqstr) {
	if(str == ""||str == "undefined") return true;
	if(typeof(str)=="undefined") return true;
	if(eqstr && str == eqstr) return true;
	var regu = "^[ ]+$";
	var re = new RegExp(regu);
	return re.test(str);
}