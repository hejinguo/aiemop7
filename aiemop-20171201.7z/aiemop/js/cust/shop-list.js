mui.init({
	subpages: [{
		url: 'shop-list-pull.html',
		id: 'page-shop-list-pull',
		styles: {
			top: '44px',
			bottom: '0px',
		}
	}],
	gesturesConfig:{
		tap:true,
		doubletap:true
	}
});

mui.plusReady(function(){
	//	添加商铺信息
	//	document.getElementById("showaddshop_button").addEventListener('tap', function() {
	//		mui.openWindow({
	//			url:'shop-add.html',
	//			id:'page-shop-add'
	//			//,styles:{top:immersed+'px',bottom:'0px'}//窗口参数
	//		});
	//	});
	mui(".mui-bar").on("tap",".mui-icon-more-filled",function(){
		mui.fire(plus.webview.getWebviewById("page-shop-list-pull"),"showInfoPopover");
		/*mui.openWindow({
			url:'shop-info.html',
			id:'page-shop-info'
		});*/
	});
	mui('.mui-bar').on("tap",".mui-icon-plusempty",function(){
		ai.openWindow({
			url:'shop-add.html',
			id:'page-shop-add'
		});
	})
	//客户经理工号才有添加权限
	if(ai.user.roles[0].roleId=='2'){
		mui('#add-shopinfo')[0].className="mui-icon mui-icon-plusempty";
	}
	//双击标题进入数据上传
	mui('.mui-bar').on('tap','.mui-title',function(){
		/*ai.openWindow({
			url:'shop-file.html',
			id:'page-shop-file'
		});*/
	});
});