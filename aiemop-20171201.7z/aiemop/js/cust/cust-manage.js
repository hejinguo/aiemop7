mui.init({
	gestureConfig:{
		hold:true,//按住屏幕
		release:true//离开屏幕
	},
	pullRefresh: {
		container: '#refreshContainer',
		down: {
			callback: initData
		}
	}

});

mui.plusReady(function() {
	//集团管理点击事件
	var unit_manage = document.getElementById("unit_manage");
	unit_manage.addEventListener("tap", function() {
		mui.toast("功能开发中...");
	});
	//集团成员管理点击事件
	var mbr_manage = document.getElementById("mbr_manage");
	mbr_manage.addEventListener("tap", function() {
		mui.toast("功能开发中...");
	});
	//商铺管理点击事件
	var shop_manage = document.getElementById("shop_manage");
	shop_manage.addEventListener("tap", function() {
		ai.openWindow({
			url: "shop-list.html",
			id: "page-shop-list",
			styles: {
				bounce: 'vertical',
				popGesture: 'close'
			}
		});
	});
	
	initData();
});

function initData(){
	setTimeout(function() {
		document.getElementById("shop_total").innerText="";
		document.getElementById("shop_mebnum").innerText="";
		//加载数据
		ai.ajax("/cust/getShopGroupByType", {}, function(data) {
			if (data.state) {
				var total = 0;
				var total_state2=0
				var meb_num = 0;
				var shop_manage = mui('#shop_info_detail')[0];
				shop_manage.innerHTML="";
				mui.each(data.info, function(index, item) {
					var shop_div = document.createElement('div');
					shop_div.className = "mui-col-xs-6 mui-text-left";
					shop_div.innerHTML = '<h5 class="mui-ellipsis">' + item.TYPE_ID + '：'+item.ENT_STATE2+'/' + item.TYPE_COUNT + '</h5>';
					shop_manage.appendChild(shop_div);
					total += item.TYPE_COUNT;
					total_state2+=item.ENT_STATE2;
					meb_num += item.MEB_NUM;
				});
				document.getElementById("shop_total").innerText = total_state2+'/'+total+'(已拓展数/商铺总数)';
				document.getElementById("shop_mebnum").innerText = meb_num;
			}
			mui('#refreshContainer').pullRefresh().endPulldownToRefresh();
		}, function() {
			mui('#refreshContainer').pullRefresh().endPulldownToRefresh();
		}, function() {
			mui('#refreshContainer').pullRefresh().endPulldownToRefresh();
		});
	}, 1500);
}
